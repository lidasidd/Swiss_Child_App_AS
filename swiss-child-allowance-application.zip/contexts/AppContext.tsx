
import React, { createContext, useState, useEffect, ReactNode } from 'react';
import { Language, Theme, User, Translations, ApplicationData, Notification } from '../types';
import { DEFAULT_LANGUAGE, DEFAULT_THEME, TEXTS, MOCK_NOTIFICATIONS } from '../constants';
import { getMockSFUserData } from '../services/mockSuccessFactorsService'; // Mock SF user data

interface AppContextType {
  theme: Theme;
  setTheme: (theme: Theme) => void;
  language: Language;
  setLanguage: (language: Language) => void;
  translate: (key: string, fallback?: string) => string;
  user: User | null;
  sfUserData: ReturnType<typeof getMockSFUserData> | null;
  isLoadingSFData: boolean;
  activeApplication: ApplicationData | null; // For editing or viewing an existing application
  setActiveApplication: (app: ApplicationData | null) => void; 
  isFormDirty: boolean;
  setIsFormDirty: (dirty: boolean) => void;
  notifications: Notification[];
  markNotificationAsRead: (notificationId: string) => void;
  markAllNotificationsAsRead: () => void;
}

export const AppContext = createContext<AppContextType | undefined>(undefined);

interface AppProviderProps {
  children: ReactNode;
}

export const AppProvider: React.FC<AppProviderProps> = ({ children }) => {
  const [theme, setThemeState] = useState<Theme>(() => {
    return (localStorage.getItem('app-theme') as Theme) || DEFAULT_THEME;
  });
  const [language, setLanguageState] = useState<Language>(() => {
    return (localStorage.getItem('app-language') as Language) || DEFAULT_LANGUAGE;
  });
  const [user, setUser] = useState<User | null>(null); // Mock user
  const [sfUserData, setSfUserData] = useState<ReturnType<typeof getMockSFUserData> | null>(null);
  const [isLoadingSFData, setIsLoadingSFData] = useState<boolean>(true);
  const [activeApplication, setActiveApplication] = useState<ApplicationData | null>(null);
  const [isFormDirty, setIsFormDirty] = useState<boolean>(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);

  useEffect(() => {
    // Simulate fetching user and SF data
    const mockUser: User = { id: 'employee123', name: 'Max Muster', role: 'admin', hrManagerName: 'Erika Mustermann' };
    setUser(mockUser);
    
    const data = getMockSFUserData(mockUser.id);
    setSfUserData(data);
    setIsLoadingSFData(false);

    // Load mock notifications
    const storedNotifications = localStorage.getItem('app-notifications');
    if (storedNotifications) {
      setNotifications(JSON.parse(storedNotifications));
    } else {
      setNotifications(MOCK_NOTIFICATIONS);
      localStorage.setItem('app-notifications', JSON.stringify(MOCK_NOTIFICATIONS));
    }
  }, []);

  const setTheme = (newTheme: Theme) => {
    setThemeState(newTheme);
    localStorage.setItem('app-theme', newTheme);
  };

  const setLanguage = (newLanguage: Language) => {
    setLanguageState(newLanguage);
    localStorage.setItem('app-language', newLanguage);
  };

  const translate = (key: string, fallback?: string): string => {
    const keyParts = key.split('.');
    let currentLevel: any = TEXTS;
    for (const part of keyParts) {
        if (currentLevel && typeof currentLevel === 'object' && part in currentLevel) {
            currentLevel = currentLevel[part];
        } else {
            currentLevel = undefined;
            break;
        }
    }
    if (currentLevel && typeof currentLevel === 'object' && language in currentLevel) {
        return currentLevel[language];
    }
    return fallback || key;
  };

  const updateStoredNotifications = (updatedNotifications: Notification[]) => {
    setNotifications(updatedNotifications);
    localStorage.setItem('app-notifications', JSON.stringify(updatedNotifications));
  };

  const markNotificationAsRead = (notificationId: string) => {
    const updatedNotifications = notifications.map(n =>
      n.id === notificationId ? { ...n, isRead: true } : n
    );
    updateStoredNotifications(updatedNotifications);
  };

  const markAllNotificationsAsRead = () => {
    const updatedNotifications = notifications.map(n => ({ ...n, isRead: true }));
    updateStoredNotifications(updatedNotifications);
  };


  return (
    <AppContext.Provider value={{ 
        theme, setTheme, 
        language, setLanguage, 
        translate, 
        user, sfUserData, isLoadingSFData,
        activeApplication, setActiveApplication,
        isFormDirty, setIsFormDirty,
        notifications, markNotificationAsRead, markAllNotificationsAsRead
    }}>
      {children}
    </AppContext.Provider>
  );
};