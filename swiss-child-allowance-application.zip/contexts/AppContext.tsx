
import React, { createContext, useState, useEffect, ReactNode } from 'react';
import { Language, Theme, User, Translations, ApplicationData, Notification, UserQuestionnaire, UploadedFile, UserQuestionnaireStatus, ApplicationStatus, NotificationType, SFUserData } from '../types';
import { DEFAULT_LANGUAGE, DEFAULT_THEME, TEXTS, MOCK_NOTIFICATIONS } from '../constants';
import { getMockSFUserData } from '../services/mockSuccessFactorsService'; 
import { getAllUserQuestionnairesForUser, saveUserQuestionnaire as saveUserQuestionnaireToService, getUserQuestionnaireById } from '../services/questionnaireService';
import { getApplicationById as getApplicationByIdFromDB, saveApplication as saveApplicationToDB, getAllApplications as getAllSystemApplicationsForContext } from '../services/applicationPersistenceService';


interface AppContextType {
  theme: Theme;
  setTheme: (theme: Theme) => void;
  language: Language;
  setLanguage: (language: Language) => void;
  translate: (key: string, fallback?: string) => string;
  user: User | null;
  sfUserData: ReturnType<typeof getMockSFUserData> | null;
  isLoadingSFData: boolean;
  activeApplication: ApplicationData | null; 
  setActiveApplication: (app: ApplicationData | null) => void; 
  isFormDirty: boolean;
  setIsFormDirty: (dirty: boolean) => void;
  notifications: Notification[];
  markNotificationAsRead: (notificationId: string) => void;
  markAllNotificationsAsRead: () => void;
  userQuestionnaires: UserQuestionnaire[];
  sendUserQuestionnaire: (recipientUserId: string, file: UploadedFile, comments?: string, relatedApplicationId?: string) => void;
  submitQuestionnaireResponse: (questionnaireId: string, responseFile: UploadedFile, responseComments?: string) => void;
  processAdminQuestionnaireAction: (questionnaireId: string, action: 'approve' | 'reject', adminComments?: string) => void;
  allSFUsers: SFUserData[]; 
  allSystemApplications: ApplicationData[]; // For admin to link questionnaires
}

export const AppContext = createContext<AppContextType | undefined>(undefined);

interface AppProviderProps {
  children: ReactNode;
}

export const AppProvider: React.FC<AppProviderProps> = ({ children }) => {
  const [theme, setThemeState] = useState<Theme>(() => {
    return (localStorage.getItem('app-theme') as Theme) || DEFAULT_THEME;
  });
  const [language, setLanguageState] = useState<Language>(() => {
    return (localStorage.getItem('app-language') as Language) || DEFAULT_LANGUAGE;
  });
  const [user, setUser] = useState<User | null>(null); 
  const [sfUserData, setSfUserData] = useState<ReturnType<typeof getMockSFUserData> | null>(null);
  const [allSFUsers, setAllSFUsers] = useState<SFUserData[]>([]);
  const [isLoadingSFData, setIsLoadingSFData] = useState<boolean>(true);
  const [activeApplication, setActiveApplication] = useState<ApplicationData | null>(null);
  const [isFormDirty, setIsFormDirty] = useState<boolean>(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [userQuestionnaires, setUserQuestionnaires] = useState<UserQuestionnaire[]>([]);
  const [allSystemApplications, setAllSystemApplications] = useState<ApplicationData[]>([]);


  useEffect(() => {
    const mockUser: User = { id: 'employee123', name: 'Max Muster', role: 'admin', hrManagerName: 'Erika Mustermann' };
    setUser(mockUser);
    
    const data = getMockSFUserData(mockUser.id);
    setSfUserData(data);

    const sfUserKeys = ['employee123', 'employee456']; 
    const allUsersData = sfUserKeys.map(id => getMockSFUserData(id)).filter(u => u !== null) as SFUserData[];
    setAllSFUsers(allUsersData);

    setIsLoadingSFData(false);

    const storedNotificationsRaw = localStorage.getItem('app-notifications');
    if (storedNotificationsRaw) {
      const storedNotifications = JSON.parse(storedNotificationsRaw);
      // Filter notifications for the current mock user or if no recipientUserId (global)
      setNotifications(storedNotifications.filter((n: Notification) => !n.recipientUserId || n.recipientUserId === mockUser.id || mockUser.role === 'admin'));
    } else {
      // For initial load, MOCK_NOTIFICATIONS might not have recipientUserId, treat as global or for employee123
      const initialNotifications = MOCK_NOTIFICATIONS.filter(n => !n.recipientUserId || n.recipientUserId === mockUser.id || mockUser.role === 'admin');
      setNotifications(initialNotifications);
      localStorage.setItem('app-notifications', JSON.stringify(MOCK_NOTIFICATIONS)); // Store all mocks initially
    }
    

    if (mockUser) { 
        const storedQuestionnaires = getAllUserQuestionnairesForUser(mockUser.id);
        setUserQuestionnaires(storedQuestionnaires);
        if (mockUser.role === 'admin') {
          setAllSystemApplications(getAllSystemApplicationsForContext(undefined)); // Fetch all for admin
        }
    }
  }, []);

  const setTheme = (newTheme: Theme) => {
    setThemeState(newTheme);
    localStorage.setItem('app-theme', newTheme);
  };

  const setLanguage = (newLanguage: Language) => {
    setLanguageState(newLanguage);
    localStorage.setItem('app-language', newLanguage);
  };

  const translate = (key: string, fallback?: string): string => {
    const keyParts = key.split('.');
    let currentLevel: any = TEXTS;
    for (const part of keyParts) {
        if (currentLevel && typeof currentLevel === 'object' && part in currentLevel) {
            currentLevel = currentLevel[part];
        } else {
            currentLevel = undefined;
            break;
        }
    }
    if (currentLevel && typeof currentLevel === 'object' && language in currentLevel) {
        return currentLevel[language];
    }
    return fallback || key;
  };

  const updateAndStoreNotifications = (newNotification?: Notification, updatedList?: Notification[]) => {
    let currentNotifications = JSON.parse(localStorage.getItem('app-notifications') || '[]');
    if (updatedList) {
        currentNotifications = updatedList;
    } else if (newNotification) {
        currentNotifications.push(newNotification);
    }
    localStorage.setItem('app-notifications', JSON.stringify(currentNotifications));
    // Update context state only with notifications relevant to the current user
    if (user) {
        setNotifications(currentNotifications.filter((n: Notification) => !n.recipientUserId || n.recipientUserId === user.id || user.role === 'admin'));
    }
  };


  const markNotificationAsRead = (notificationId: string) => {
    let allNotifications = JSON.parse(localStorage.getItem('app-notifications') || '[]');
    allNotifications = allNotifications.map((n: Notification) =>
      n.id === notificationId ? { ...n, isRead: true } : n
    );
    updateAndStoreNotifications(undefined, allNotifications);
  };

  const markAllNotificationsAsRead = () => {
    let allNotifications = JSON.parse(localStorage.getItem('app-notifications') || '[]');
    allNotifications = allNotifications.map((n: Notification) => 
        (user && (n.recipientUserId === user.id || (user.role === 'admin' && !n.recipientUserId))) ? { ...n, isRead: true } : n
    );
    updateAndStoreNotifications(undefined, allNotifications);
  };

  const sendUserQuestionnaire = (recipientUserId: string, file: UploadedFile, comments?: string, relatedApplicationId?: string) => {
    if (!user) return; 

    const newQuestionnaire: UserQuestionnaire = {
      id: `questionnaire-${Date.now()}-${Math.random().toString(16).slice(2)}`,
      recipientUserId,
      senderUserId: user.id,
      questionnaireFile: file,
      title: file.name, 
      adminComments: comments,
      sentDate: new Date().toISOString(),
      status: UserQuestionnaireStatus.PENDING_EMPLOYEE_RESPONSE,
      relatedApplicationId,
    };
    saveUserQuestionnaireToService(newQuestionnaire);
    
    // Update local state for immediate feedback if admin views a list of sent items
    if (user.role === 'admin') {
      setUserQuestionnaires(prev => [...prev, newQuestionnaire].sort((a,b) => new Date(b.sentDate).getTime() - new Date(a.sentDate).getTime()));
    }

    if (relatedApplicationId) {
        const appToUpdate = getApplicationByIdFromDB(relatedApplicationId);
        if (appToUpdate) {
            appToUpdate.status = ApplicationStatus.QUESTIONNAIRE_SENT_TO_EMPLOYEE;
            appToUpdate.lastModifiedDate = new Date().toISOString().split('T')[0];
            saveApplicationToDB(appToUpdate);
            if (user.role === 'admin') { // Refresh admin's list of all apps
              setAllSystemApplications(getAllSystemApplicationsForContext(undefined));
            }
        }
    }
    
    // Create notification for employee
    const notificationForEmployee: Notification = {
      id: `notif-q-new-${Date.now()}`,
      type: 'questionnaire_new',
      messageKey: 'notificationQuestionnaireReceived',
      defaultMessage: `You have received a new questionnaire from ${user.name}.`,
      timestamp: new Date().toISOString(),
      isRead: false,
      link: `/`, // Link to dashboard
      recipientUserId: recipientUserId,
      senderName: user.name,
    };
    updateAndStoreNotifications(notificationForEmployee);
  };

  const submitQuestionnaireResponse = (questionnaireId: string, responseFile: UploadedFile, responseComments?: string) => {
    if (!user) return;
    const questionnaire = getUserQuestionnaireById(questionnaireId);
    if (!questionnaire || questionnaire.recipientUserId !== user.id) return;

    questionnaire.employeeResponseFile = responseFile;
    questionnaire.employeeResponseComments = responseComments;
    questionnaire.status = UserQuestionnaireStatus.SUBMITTED_BY_EMPLOYEE;
    questionnaire.employeeSubmissionDate = new Date().toISOString();
    saveUserQuestionnaireToService(questionnaire);

    setUserQuestionnaires(prev => prev.map(q => q.id === questionnaireId ? questionnaire : q)
                                   .sort((a,b) => new Date(b.sentDate).getTime() - new Date(a.sentDate).getTime()));
    
    // Create notification for admin
    const adminToNotify = getMockSFUserData(questionnaire.senderUserId); // Or fetch admin details
    const notificationForAdmin: Notification = {
        id: `notif-q-resp-${Date.now()}`,
        type: 'questionnaire_response',
        messageKey: 'notificationQuestionnaireResponded',
        defaultMessage: `${user.name} has responded to questionnaire '${questionnaire.title}'.`,
        timestamp: new Date().toISOString(),
        isRead: false,
        link: `/admin`, // Link to admin dashboard, potentially to specific questionnaire
        recipientUserId: questionnaire.senderUserId, // Notify the original sender (admin)
        senderName: user.name
    };
    updateAndStoreNotifications(notificationForAdmin);
  };

  const processAdminQuestionnaireAction = (questionnaireId: string, action: 'approve' | 'reject', adminReviewComments?: string) => {
    if (!user || user.role !== 'admin') return;
    const questionnaire = getUserQuestionnaireById(questionnaireId);
    if (!questionnaire) return;

    questionnaire.status = action === 'approve' ? UserQuestionnaireStatus.APPROVED_BY_ADMIN : UserQuestionnaireStatus.REJECTED_BY_ADMIN;
    questionnaire.adminReviewComments = adminReviewComments; // For rejection
    saveUserQuestionnaireToService(questionnaire);
    
    setUserQuestionnaires(prev => prev.map(q => q.id === questionnaireId ? questionnaire : q)
                                   .sort((a,b) => new Date(b.sentDate).getTime() - new Date(a.sentDate).getTime()));

    if (questionnaire.relatedApplicationId && questionnaire.status === UserQuestionnaireStatus.APPROVED_BY_ADMIN) {
        const appToUpdate = getApplicationByIdFromDB(questionnaire.relatedApplicationId);
        if (appToUpdate) {
            appToUpdate.status = ApplicationStatus.QUESTIONNAIRE_COMPLETED;
            // Optionally, move app status further if questionnaire was the last step, e.g., to UNDER_REVIEW or COMPLETED
            appToUpdate.lastModifiedDate = new Date().toISOString().split('T')[0];
            saveApplicationToDB(appToUpdate);
             if (user.role === 'admin') { 
              setAllSystemApplications(getAllSystemApplicationsForContext(undefined));
            }
        }
    }

    // Notify employee
    const notificationForEmployee: Notification = {
        id: `notif-q-action-${Date.now()}`,
        type: action === 'approve' ? 'questionnaire_approved' : 'questionnaire_rejected',
        messageKey: 'notificationQuestionnaireActionTaken',
        defaultMessage: `Your response to questionnaire '${questionnaire.title}' has been ${action === 'approve' ? 'approved' : 'rejected'}.`,
        timestamp: new Date().toISOString(),
        isRead: false,
        link: `/`, // Link to their dashboard
        recipientUserId: questionnaire.recipientUserId,
        senderName: user.name // Admin's name
    };
    updateAndStoreNotifications(notificationForEmployee);
  };


  return (
    <AppContext.Provider value={{ 
        theme, setTheme, 
        language, setLanguage, 
        translate, 
        user, sfUserData, isLoadingSFData, allSFUsers,
        activeApplication, setActiveApplication,
        isFormDirty, setIsFormDirty,
        notifications, markNotificationAsRead, markAllNotificationsAsRead,
        userQuestionnaires, sendUserQuestionnaire,
        submitQuestionnaireResponse, processAdminQuestionnaireAction,
        allSystemApplications
    }}>
      {children}
    </AppContext.Provider>
  );
};