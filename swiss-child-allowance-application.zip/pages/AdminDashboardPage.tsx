
import React, { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { ApplicationData, ApplicationStatus, User, UploadedFile, SelectOption, SFUserData, UserQuestionnaire, UserQuestionnaireStatus } from '../types';
import { useAppContext } from '../hooks/useAppContext';
import { translateApplicationStatus, APPLICATION_STATUS_OPTIONS, ALLOWED_QUESTIONNAIRE_FILE_TYPES, translateUserQuestionnaireStatus } from '../constants';
import { saveApplication as saveApplicationToDB, getAllApplications as getAllSystemApplicationsFromDB } from '../services/applicationPersistenceService';
import Button from '../components/ui/Button';
import FormField from '../components/ui/FormField';
import Modal from '../components/ui/Modal';
import FileUpload from '../components/ui/FileUpload';
import LoadingSpinner from '../components/ui/LoadingSpinner';

// Helper function to download file from base64
const downloadFileFromBase64 = (base64String: string | undefined, fileName: string, mimeType: string) => {
  if (!base64String) {
    alert('File data is not available for download.');
    return;
  }
  const linkSource = `data:${mimeType};base64,${base64String}`;
  const downloadLink = document.createElement("a");
  downloadLink.href = linkSource;
  downloadLink.download = fileName;
  document.body.appendChild(downloadLink); // Required for Firefox
  downloadLink.click();
  document.body.removeChild(downloadLink);
};


const AdminDashboardPage: React.FC = () => {
  const { 
    translate, theme, user, allSFUsers, 
    sendUserQuestionnaire, userQuestionnaires, 
    processAdminQuestionnaireAction, allSystemApplications 
  } = useAppContext();
  
  const [applications, setApplications] = useState<ApplicationData[]>([]);
  const [displayedQuestionnaires, setDisplayedQuestionnaires] = useState<UserQuestionnaire[]>([]);

  const [isLoading, setIsLoading] = useState(true);
  const [filterName, setFilterName] = useState('');
  const [filterDateStart, setFilterDateStart] = useState('');
  const [filterDateEnd, setFilterDateEnd] = useState('');
  const [filterStatus, setFilterStatus] = useState('');

  const [showAppActionModal, setShowAppActionModal] = useState(false);
  const [currentActionApp, setCurrentActionApp] = useState<ApplicationData | null>(null);
  const [currentActionType, setCurrentActionType] = useState<'sendBack' | 'reject' | null>(null);
  const [adminCommentForApp, setAdminCommentForApp] = useState('');

  const [showNewQuestionnaireModal, setShowNewQuestionnaireModal] = useState(false);
  const [selectedRecipientId, setSelectedRecipientId] = useState<string>('');
  const [questionnaireFile, setQuestionnaireFile] = useState<UploadedFile | null>(null);
  const [questionnaireAdminComments, setQuestionnaireAdminComments] = useState('');
  const [selectedRelatedAppId, setSelectedRelatedAppId] = useState<string>('');
  const [employeeOptions, setEmployeeOptions] = useState<SelectOption[]>([]);
  const [relatedAppOptions, setRelatedAppOptions] = useState<SelectOption[]>([]);

  const [showReviewQuestionnaireModal, setShowReviewQuestionnaireModal] = useState(false);
  const [currentReviewQuestionnaire, setCurrentReviewQuestionnaire] = useState<UserQuestionnaire | null>(null);
  const [adminReviewCommentForQ, setAdminReviewCommentForQ] = useState('');
  const [showRejectQuestionnaireModal, setShowRejectQuestionnaireModal] = useState(false);


  useEffect(() => {
    const options = allSFUsers.map((sfUser: SFUserData) => ({
        value: sfUser.employeeId,
        label: `${sfUser.firstName} ${sfUser.lastName} (${sfUser.employeeId})`
    }));
    setEmployeeOptions(options);
  }, [allSFUsers]);

  useEffect(() => {
    if (selectedRecipientId) {
        const userApps = allSystemApplications.filter(app => 
            app.userId === selectedRecipientId && 
            (app.status === ApplicationStatus.SUBMITTED || app.status === ApplicationStatus.UNDER_REVIEW || app.status === ApplicationStatus.PENDING_EMPLOYEE_ACTION)
        );
        setRelatedAppOptions(userApps.map(app => ({
            value: app.id,
            label: `App ID: ${app.id.substring(0,8)}... (Status: ${translateApplicationStatus(app.status, translate)})`
        })));
    } else {
        setRelatedAppOptions([]);
    }
    setSelectedRelatedAppId('');
  }, [selectedRecipientId, allSystemApplications, translate]);


  const fetchAllData = () => {
    setIsLoading(true);
    const fetchedApplications = getAllSystemApplicationsFromDB(undefined);
    fetchedApplications.sort((a,b) => {
        const dateA = a.submissionDate || a.lastModifiedDate;
        const dateB = b.submissionDate || b.lastModifiedDate;
        return new Date(dateB).getTime() - new Date(dateA).getTime();
    });
    setApplications(fetchedApplications);
    
    setDisplayedQuestionnaires(userQuestionnaires.sort((a,b) => new Date(b.sentDate).getTime() - new Date(a.sentDate).getTime()));

    setIsLoading(false);
  }

  useEffect(() => {
    fetchAllData();
  }, [userQuestionnaires, allSystemApplications]);

  const filteredApplications = useMemo(() => {
    return applications.filter(app => {
      const nameMatch = filterName ? 
        (app.employeeFirstName?.toLowerCase().includes(filterName.toLowerCase()) || 
         app.employeeLastName?.toLowerCase().includes(filterName.toLowerCase())) 
        : true;
      
      const appDateStr = app.submissionDate || app.lastModifiedDate;
      let dateMatch = true;
      if (appDateStr) {
        if (filterDateStart && appDateStr < filterDateStart) dateMatch = false;
        if (filterDateEnd && appDateStr > filterDateEnd) dateMatch = false;
      } else if (filterDateStart || filterDateEnd) {
        dateMatch = false;
      }

      const statusMatch = filterStatus ? app.status === filterStatus : true;
      return nameMatch && dateMatch && statusMatch;
    });
  }, [applications, filterName, filterDateStart, filterDateEnd, filterStatus]);

  const handleAppAction = (app: ApplicationData, newStatus: ApplicationStatus, requiresComment: boolean = false, actionType?: 'sendBack' | 'reject') => {
    if (requiresComment && actionType) {
        setCurrentActionApp(app);
        setCurrentActionType(actionType);
        setAdminCommentForApp(app.adminComments || '');
        setShowAppActionModal(true);
    } else {
        const updatedApp = { ...app, status: newStatus, lastModifiedDate: new Date().toISOString().split('T')[0] };
        if (!requiresComment) updatedApp.adminComments = undefined;
        saveApplicationToDB(updatedApp);
        fetchAllData(); 
    }
  };
  
  const handleReviewClick = (app: ApplicationData) => {
    if (app.status === ApplicationStatus.SUBMITTED) {
      handleAppAction(app, ApplicationStatus.UNDER_REVIEW);
    }
  };

  const submitAppCommentAndAction = () => {
    if (currentActionApp && currentActionType) {
        const newStatus = currentActionType === 'sendBack' ? ApplicationStatus.PENDING_EMPLOYEE_ACTION : ApplicationStatus.REJECTED;
        const updatedApp = { 
            ...currentActionApp, 
            status: newStatus, 
            adminComments: adminCommentForApp,
            lastModifiedDate: new Date().toISOString().split('T')[0]
        };
        saveApplicationToDB(updatedApp);
        fetchAllData();
        setShowAppActionModal(false);
        setAdminCommentForApp('');
        setCurrentActionApp(null);
        setCurrentActionType(null);
    }
  };
  
  const clearFilters = () => {
    setFilterName('');
    setFilterDateStart('');
    setFilterDateEnd('');
    setFilterStatus('');
  };

  const openNewQuestionnaireModal = () => {
    setSelectedRecipientId('');
    setQuestionnaireFile(null);
    setQuestionnaireAdminComments('');
    setSelectedRelatedAppId('');
    setShowNewQuestionnaireModal(true);
  };

  const handleSendQuestionnaire = () => {
    if (!selectedRecipientId || !questionnaireFile || !user) {
      alert(translate('pleaseSelectEmployeeAndFile', "Please select an employee and upload a questionnaire file."));
      return;
    }
    sendUserQuestionnaire(selectedRecipientId, questionnaireFile, questionnaireAdminComments, selectedRelatedAppId || undefined);
    setShowNewQuestionnaireModal(false);
    alert(translate('questionnaireSent'));
  };

  const openReviewQuestionnaireModal = (q: UserQuestionnaire) => {
    setCurrentReviewQuestionnaire(q);
    setShowReviewQuestionnaireModal(true);
  };

  const handleApproveQuestionnaire = (questionnaireId: string) => {
    processAdminQuestionnaireAction(questionnaireId, 'approve');
    setShowReviewQuestionnaireModal(false); 
  };

  const openRejectQuestionnaireModal = (q: UserQuestionnaire) => {
    setCurrentReviewQuestionnaire(q); 
    setAdminReviewCommentForQ(''); 
    setShowReviewQuestionnaireModal(false); 
    setShowRejectQuestionnaireModal(true); 
  };

  const handleRejectQuestionnaire = () => {
    if (currentReviewQuestionnaire) {
        processAdminQuestionnaireAction(currentReviewQuestionnaire.id, 'reject', adminReviewCommentForQ);
        setShowRejectQuestionnaireModal(false);
    }
  };

  const handleDownloadEmployeeResponse = () => {
    if (currentReviewQuestionnaire?.employeeResponseFile?.base64) {
        downloadFileFromBase64(
            currentReviewQuestionnaire.employeeResponseFile.base64,
            currentReviewQuestionnaire.employeeResponseFile.name,
            currentReviewQuestionnaire.employeeResponseFile.type
        );
    } else {
        alert(translate('fileNotAvailableForDownload', 'Employee response file is not available for download.'));
    }
  };
  
  const handleDownloadAdminQuestionnaire = () => {
     if (currentReviewQuestionnaire?.questionnaireFile?.base64) {
        downloadFileFromBase64(
            currentReviewQuestionnaire.questionnaireFile.base64,
            currentReviewQuestionnaire.questionnaireFile.name,
            currentReviewQuestionnaire.questionnaireFile.type
        );
    } else {
        alert(translate('fileNotAvailableForDownload', 'Admin questionnaire file is not available for download.'));
    }
  }


  let cardBgClass = 'bg-white';
  let textColorClass = 'text-gray-700';
  let headingColorClass = 'text-gray-900';
  let tableDivideClass = 'divide-gray-200';
  let tableHeaderBgClass = 'bg-gray-50';
  
    const getStatusBadgeStyle = (status: ApplicationStatus | UserQuestionnaireStatus, isQuestionnaireStatus: boolean = false) => {
        let bg = ''; let text = '';
        if (theme === 'theme4') { 
            bg = 'bg-slate-600'; text = 'text-slate-300'; 
            if (isQuestionnaireStatus) {
                switch (status as UserQuestionnaireStatus) {
                    case UserQuestionnaireStatus.PENDING_EMPLOYEE_RESPONSE: bg = 'bg-yellow-700/40'; text = 'text-yellow-300'; break;
                    case UserQuestionnaireStatus.SUBMITTED_BY_EMPLOYEE: bg = 'bg-blue-700/40'; text = 'text-blue-300'; break;
                    case UserQuestionnaireStatus.APPROVED_BY_ADMIN: bg = 'bg-green-700/40'; text = 'text-green-300'; break;
                    case UserQuestionnaireStatus.REJECTED_BY_ADMIN: bg = 'bg-red-700/40'; text = 'text-red-300'; break;
                }
            } else {
                 switch (status as ApplicationStatus) {
                    case ApplicationStatus.DRAFT: bg = 'bg-slate-600'; text = 'text-slate-300'; break;
                    case ApplicationStatus.SUBMITTED: bg = 'bg-sky-700/80'; text = 'text-sky-200'; break;
                    case ApplicationStatus.UNDER_REVIEW: bg = 'bg-yellow-600/80'; text = 'text-yellow-200'; break;
                    case ApplicationStatus.PENDING_EMPLOYEE_ACTION: bg = 'bg-orange-600/80'; text = 'text-orange-200'; break;
                    case ApplicationStatus.QUESTIONNAIRE_SENT_TO_EMPLOYEE: bg = 'bg-purple-600/80'; text = 'text-purple-200'; break;
                    case ApplicationStatus.QUESTIONNAIRE_COMPLETED: bg = 'bg-teal-600/80'; text = 'text-teal-200'; break;
                    case ApplicationStatus.COMPLETED: bg = 'bg-green-600/80'; text = 'text-green-200'; break;
                    case ApplicationStatus.REJECTED: bg = 'bg-red-600/80'; text = 'text-red-200'; break;
                }
            }
        } else { 
            bg = 'bg-gray-100'; text = 'text-gray-700'; 
             if (isQuestionnaireStatus) {
                switch (status as UserQuestionnaireStatus) {
                    case UserQuestionnaireStatus.PENDING_EMPLOYEE_RESPONSE: bg = 'bg-yellow-100'; text = 'text-yellow-800'; break;
                    case UserQuestionnaireStatus.SUBMITTED_BY_EMPLOYEE: bg = 'bg-blue-100'; text = 'text-blue-800'; break;
                    case UserQuestionnaireStatus.APPROVED_BY_ADMIN: bg = 'bg-green-100'; text = 'text-green-800'; break;
                    case UserQuestionnaireStatus.REJECTED_BY_ADMIN: bg = 'bg-red-100'; text = 'text-red-800'; break;
                }
            } else {
                switch (status as ApplicationStatus) {
                    case ApplicationStatus.DRAFT: bg = 'bg-gray-100'; text = 'text-gray-700'; break;
                    case ApplicationStatus.SUBMITTED: bg = 'bg-blue-100'; text = 'text-blue-700'; break;
                    case ApplicationStatus.UNDER_REVIEW: bg = 'bg-yellow-100'; text = 'text-yellow-700'; break;
                    case ApplicationStatus.PENDING_EMPLOYEE_ACTION: bg = 'bg-orange-100'; text = 'text-orange-700'; break;
                    case ApplicationStatus.QUESTIONNAIRE_SENT_TO_EMPLOYEE: bg = 'bg-purple-100'; text = 'text-purple-700'; break;
                    case ApplicationStatus.QUESTIONNAIRE_COMPLETED: bg = 'bg-teal-100'; text = 'text-teal-700'; break;
                    case ApplicationStatus.COMPLETED: bg = 'bg-green-100'; text = 'text-green-700'; break;
                    case ApplicationStatus.REJECTED: bg = 'bg-red-100'; text = 'text-red-700'; break;
                }
            }
        }
        return `${bg} ${text}`;
    };


  if (theme === 'theme2') {
    cardBgClass = 'bg-theme2-secondary-bg'; textColorClass = 'text-theme2-text'; headingColorClass = 'text-theme2-text';
    tableDivideClass = 'divide-gray-200'; tableHeaderBgClass = 'bg-gray-50'; 
  } else if (theme === 'theme3') {
    cardBgClass = 'bg-theme3-secondary-bg'; textColorClass = 'text-theme3-text-on-light'; headingColorClass = 'text-theme3-text-on-light';
    tableDivideClass = 'divide-gray-300'; tableHeaderBgClass = 'bg-slate-100';
  } else if (theme === 'theme4') {
    cardBgClass = 'bg-theme4-secondary-bg'; textColorClass = 'text-theme4-text-on-dark'; headingColorClass = 'text-theme4-text-on-dark';
    tableDivideClass = 'divide-theme4-border'; tableHeaderBgClass = 'bg-theme4-bg'; 
  }


  if (isLoading) return <LoadingSpinner text={translate('loadingApplications')} />;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className={`text-3xl font-bold ${headingColorClass}`}>{translate('adminDashboardTitle')}</h1>
        <Button onClick={openNewQuestionnaireModal} variant="primary">
            {translate('newQuestionnaire')}
        </Button>
      </div>

      <div className={`p-4 rounded-md shadow ${cardBgClass} grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4 items-end`}>
        <FormField id="filterName" label={translate('filterByEmployeeName')} value={filterName} onChange={(e) => setFilterName(e.target.value)} placeholder={translate('employeeName')} />
        <FormField id="filterDateStart" label={translate('filterBySubmissionDateFrom')} type="date" value={filterDateStart} onChange={(e) => setFilterDateStart(e.target.value)} />
        <FormField id="filterDateEnd" label={translate('filterBySubmissionDateTo')} type="date" value={filterDateEnd} onChange={(e) => setFilterDateEnd(e.target.value)} />
        <FormField id="filterStatus" label={translate('filterByStatus')} as="select" options={[{ value: "", labelKey: "allStatuses" }, ...APPLICATION_STATUS_OPTIONS]} value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} />
        <Button onClick={clearFilters} variant="secondary">{translate('clearFilters')}</Button>
      </div>
      
      <h2 className={`text-2xl font-semibold mt-6 ${headingColorClass}`}>{translate('applicationHistory')}</h2>
      {filteredApplications.length > 0 ? (
        <div className="overflow-x-auto shadow-md rounded-lg">
          <table className={`min-w-full divide-y ${tableDivideClass} ${cardBgClass}`}>
            <thead className={`${tableHeaderBgClass}`}>
              <tr>
                <th scope="col" className={`px-4 py-3 text-left text-xs font-medium ${headingColorClass} uppercase tracking-wider`}>{translate('applicationId')}</th>
                <th scope="col" className={`px-4 py-3 text-left text-xs font-medium ${headingColorClass} uppercase tracking-wider`}>{translate('employeeName')}</th>
                <th scope="col" className={`px-4 py-3 text-left text-xs font-medium ${headingColorClass} uppercase tracking-wider`}>{translate('submissionDate')}</th>
                <th scope="col" className={`px-4 py-3 text-left text-xs font-medium ${headingColorClass} uppercase tracking-wider`}>{translate('status')}</th>
                <th scope="col" className={`px-4 py-3 text-left text-xs font-medium ${headingColorClass} uppercase tracking-wider`}>{translate('actions')}</th>
              </tr>
            </thead>
            <tbody className={`divide-y ${tableDivideClass}`}>
              {filteredApplications.map((app) => (
                <tr key={app.id}>
                  <td className={`px-4 py-4 whitespace-nowrap text-sm ${textColorClass}`}>{app.id.substring(0,8)}...</td>
                  <td className={`px-4 py-4 whitespace-nowrap text-sm ${textColorClass}`}>{app.employeeFirstName} {app.employeeLastName}</td>
                  <td className={`px-4 py-4 whitespace-nowrap text-sm ${textColorClass}`}>{app.submissionDate || translate('na', 'N/A')}</td>
                  <td className={`px-4 py-4 whitespace-nowrap text-sm ${textColorClass}`}>
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusBadgeStyle(app.status)}`}>
                      {translateApplicationStatus(app.status, translate)}
                    </span>
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm font-medium space-x-1 space-y-1">
                    <Link to={`/application/view/${app.id}`} state={{ fromAdmin: true }} onClick={() => handleReviewClick(app)}>
                        <Button variant="ghost" size="sm">{translate('review')}</Button>
                    </Link>
                    { (app.status === ApplicationStatus.SUBMITTED || app.status === ApplicationStatus.UNDER_REVIEW || app.status === ApplicationStatus.PENDING_EMPLOYEE_ACTION || app.status === ApplicationStatus.QUESTIONNAIRE_COMPLETED) &&
                        <Button variant="primary" size="sm" onClick={() => handleAppAction(app, ApplicationStatus.COMPLETED)}>{translate('approve')}</Button>
                    }
                     { (app.status !== ApplicationStatus.COMPLETED && app.status !== ApplicationStatus.REJECTED && app.status !== ApplicationStatus.DRAFT) &&
                        <Button variant="danger" size="sm" onClick={() => handleAppAction(app, ApplicationStatus.REJECTED, true, 'reject')}>{translate('reject')}</Button>
                    }
                    { (app.status === ApplicationStatus.SUBMITTED || app.status === ApplicationStatus.UNDER_REVIEW) &&
                        <Button variant="secondary" size="sm" onClick={() => handleAppAction(app, ApplicationStatus.PENDING_EMPLOYEE_ACTION, true, 'sendBack')}>{translate('sendBack')}</Button>
                    }
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <p className={textColorClass}>{translate('noApplicationsSystem')}</p>
      )}

      <h2 className={`text-2xl font-semibold mt-8 ${headingColorClass}`}>{translate('questionnaireDetails')}</h2>
      {displayedQuestionnaires.length > 0 ? (
          <div className="overflow-x-auto shadow-md rounded-lg">
              <table className={`min-w-full divide-y ${tableDivideClass} ${cardBgClass}`}>
                  <thead className={`${tableHeaderBgClass}`}>
                      <tr>
                          <th scope="col" className={`px-4 py-3 text-left text-xs font-medium ${headingColorClass} uppercase tracking-wider`}>{translate('title')}</th>
                          <th scope="col" className={`px-4 py-3 text-left text-xs font-medium ${headingColorClass} uppercase tracking-wider`}>{translate('questionnaireSentTo')}</th>
                          <th scope="col" className={`px-4 py-3 text-left text-xs font-medium ${headingColorClass} uppercase tracking-wider`}>{translate('questionnaireSentOn')}</th>
                           <th scope="col" className={`px-4 py-3 text-left text-xs font-medium ${headingColorClass} uppercase tracking-wider`}>Emp. Submitted</th>
                          <th scope="col" className={`px-4 py-3 text-left text-xs font-medium ${headingColorClass} uppercase tracking-wider`}>{translate('status')}</th>
                          <th scope="col" className={`px-4 py-3 text-left text-xs font-medium ${headingColorClass} uppercase tracking-wider`}>{translate('actions')}</th>
                      </tr>
                  </thead>
                  <tbody className={`divide-y ${tableDivideClass}`}>
                      {displayedQuestionnaires.map(q => {
                          const recipient = allSFUsers.find(u => u.employeeId === q.recipientUserId);
                          return (
                              <tr key={q.id}>
                                  <td className={`px-4 py-4 whitespace-nowrap text-sm ${textColorClass}`}>{q.title}</td>
                                  <td className={`px-4 py-4 whitespace-nowrap text-sm ${textColorClass}`}>{recipient ? `${recipient.firstName} ${recipient.lastName}` : q.recipientUserId}</td>
                                  <td className={`px-4 py-4 whitespace-nowrap text-sm ${textColorClass}`}>{new Date(q.sentDate).toLocaleDateString()}</td>
                                  <td className={`px-4 py-4 whitespace-nowrap text-sm ${textColorClass}`}>{q.employeeSubmissionDate ? new Date(q.employeeSubmissionDate).toLocaleDateString() : translate('na')}</td>
                                  <td className={`px-4 py-4 whitespace-nowrap text-sm ${textColorClass}`}>
                                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusBadgeStyle(q.status, true)}`}>
                                          {translateUserQuestionnaireStatus(q.status, translate)}
                                      </span>
                                  </td>
                                  <td className="px-4 py-4 whitespace-nowrap text-sm font-medium space-x-1">
                                      {q.status === UserQuestionnaireStatus.SUBMITTED_BY_EMPLOYEE && (
                                          <>
                                              <Button variant="ghost" size="sm" onClick={() => openReviewQuestionnaireModal(q)}>{translate('review')}</Button>
                                              <Button variant="primary" size="sm" onClick={() => handleApproveQuestionnaire(q.id)}>{translate('approveQuestionnaire')}</Button>
                                              <Button variant="danger" size="sm" onClick={() => openRejectQuestionnaireModal(q)}>{translate('rejectQuestionnaire')}</Button>
                                          </>
                                      )}
                                      {(q.status === UserQuestionnaireStatus.APPROVED_BY_ADMIN || q.status === UserQuestionnaireStatus.REJECTED_BY_ADMIN || q.status === UserQuestionnaireStatus.PENDING_EMPLOYEE_RESPONSE) && (
                                           <Button variant="ghost" size="sm" onClick={() => openReviewQuestionnaireModal(q)}>{translate('view')}</Button>
                                      )}
                                  </td>
                              </tr>
                          );
                      })}
                  </tbody>
              </table>
          </div>
      ) : (
          <p className={textColorClass}>{translate('noQuestionnairesFound')}</p>
      )}


      <p className={`mt-4 text-xs ${textColorClass}`}>
        {translate('adminNote')}
      </p>

      <Modal isOpen={showAppActionModal} onClose={() => setShowAppActionModal(false)} title={translate('commentsForEmployee')} onOk={submitAppCommentAndAction} okText={translate('submitComment')} showCancelButton={true}>
        <FormField id="adminCommentTextApp" label={translate('commentsForEmployee')} as="textarea" rows={4} value={adminCommentForApp} onChange={(e) => setAdminCommentForApp(e.target.value)} placeholder={translate('enterComments')} />
      </Modal>

      <Modal isOpen={showNewQuestionnaireModal} onClose={() => setShowNewQuestionnaireModal(false)} title={translate('sendQuestionnaireTitle')} onOk={handleSendQuestionnaire} okText={translate('send')} showCancelButton={true} size="lg">
        <div className="space-y-4">
            <FormField id="selectEmployeeForQuestionnaire" label={translate('selectEmployee')} as="select" options={employeeOptions} value={selectedRecipientId} onChange={(e) => setSelectedRecipientId(e.target.value)} placeholder={translate('selectEmployeePlaceholder')} required />
            <FormField id="selectRelatedApp" label={translate('selectRelatedApplication')} as="select" options={[{value: '', label: translate('pleaseSelect')}, ...relatedAppOptions]} value={selectedRelatedAppId} onChange={(e) => setSelectedRelatedAppId(e.target.value)} disabled={!selectedRecipientId || relatedAppOptions.length === 0} helpText={relatedAppOptions.length === 0 && selectedRecipientId ? translate('noApplicableApplications') : ''}/>
            <FileUpload id="questionnaireUpload" label={translate('questionnaireFileLabel')} onFilesChange={(files) => setQuestionnaireFile(files.length > 0 ? files[0] : null)} multiple={false} required allowedFileTypes={ALLOWED_QUESTIONNAIRE_FILE_TYPES} helpText={`Allowed: ${ALLOWED_QUESTIONNAIRE_FILE_TYPES.map(t => t.split('/')[1].toUpperCase()).join(', ')}`} />
            <FormField id="questionnaireAdminComments" label={translate('commentsForQuestionnaire')} as="textarea" rows={3} value={questionnaireAdminComments} onChange={(e) => setQuestionnaireAdminComments(e.target.value)} placeholder={translate('enterComments')} />
        </div>
      </Modal>

       {currentReviewQuestionnaire && (
        <Modal 
            isOpen={showReviewQuestionnaireModal} 
            onClose={() => setShowReviewQuestionnaireModal(false)} 
            title={translate('adminReviewQuestionnaireTitle')} 
            showOkButton={false} 
            showCancelButton={true} 
            cancelText={translate('close')} 
            size="lg"
        >
            <div className="space-y-4">
                <div>
                    <h4 className={`font-semibold ${headingColorClass}`}>{translate('questionnaireDetails')} (Sent by Admin)</h4>
                    <p className={textColorClass}><span className="font-medium">{translate('title')}:</span> {currentReviewQuestionnaire.title}</p>
                    <p className={textColorClass}>
                        <span className="font-medium">{translate('questionnaireFileLabel')}:</span> {currentReviewQuestionnaire.questionnaireFile.name}
                         <Button 
                            variant="ghost" 
                            size="sm"
                            className="ml-2"
                            onClick={handleDownloadAdminQuestionnaire} 
                            disabled={!currentReviewQuestionnaire.questionnaireFile?.base64}
                         >
                           ({translate('download')})
                         </Button>
                    </p>
                    {currentReviewQuestionnaire.adminComments && <p className={textColorClass}><span className="font-medium">{translate('adminComments')}:</span> {currentReviewQuestionnaire.adminComments}</p>}
                </div>
                <hr className={tableDivideClass} />
                <div>
                    <h4 className={`font-semibold ${headingColorClass}`}>{translate('employeeResponse')}</h4>
                    {currentReviewQuestionnaire.employeeResponseFile ? (
                        <>
                            <p className={textColorClass}>
                                <span className="font-medium">{translate('employeeUploadedFile')}:</span> {currentReviewQuestionnaire.employeeResponseFile.name}
                                <Button 
                                    variant="ghost" 
                                    size="sm"
                                    className="ml-2"
                                    onClick={handleDownloadEmployeeResponse}
                                    disabled={!currentReviewQuestionnaire.employeeResponseFile?.base64}
                                >
                                    ({translate('download')})
                                </Button>
                            </p>
                            {currentReviewQuestionnaire.employeeResponseComments && <p className={textColorClass}><span className="font-medium">{translate('employeeComments')}:</span> {currentReviewQuestionnaire.employeeResponseComments}</p>}
                            <p className={textColorClass}><span className="font-medium">Submitted on:</span> {currentReviewQuestionnaire.employeeSubmissionDate ? new Date(currentReviewQuestionnaire.employeeSubmissionDate).toLocaleString() : 'N/A'}</p>
                        </>
                    ) : (
                        <p className={`italic ${textColorClass}`}>{translate('noResponseSubmittedYet', 'No response submitted by employee yet.')}</p>
                    )}
                </div>
                 {currentReviewQuestionnaire.adminReviewComments && (
                    <div>
                        <hr className={tableDivideClass} />
                        <h4 className={`font-semibold ${headingColorClass}`}>Admin Review Comments ({translateUserQuestionnaireStatus(currentReviewQuestionnaire.status, translate)}):</h4>
                        <p className={`italic ${textColorClass}`}>{currentReviewQuestionnaire.adminReviewComments}</p>
                    </div>
                )}

                {currentReviewQuestionnaire.status === UserQuestionnaireStatus.SUBMITTED_BY_EMPLOYEE && (
                    <div className="flex justify-end space-x-2 pt-3">
                        <Button variant="danger" onClick={() => openRejectQuestionnaireModal(currentReviewQuestionnaire!)}>{translate('rejectQuestionnaire')}</Button>
                        <Button variant="primary" onClick={() => handleApproveQuestionnaire(currentReviewQuestionnaire!.id)}>{translate('approveQuestionnaire')}</Button>
                    </div>
                )}
            </div>
        </Modal>
      )}
      
      <Modal isOpen={showRejectQuestionnaireModal} onClose={() => setShowRejectQuestionnaireModal(false)} title={translate('rejectQuestionnaire')} onOk={handleRejectQuestionnaire} okText={translate('submitComment')} showCancelButton={true}>
            <FormField id="adminReviewCommentForQ" label={translate('commentsForRejection')} as="textarea" rows={3} value={adminReviewCommentForQ} onChange={(e) => setAdminReviewCommentForQ(e.target.value)} placeholder={translate('enterComments')} required />
      </Modal>

    </div>
  );
};

export default AdminDashboardPage;