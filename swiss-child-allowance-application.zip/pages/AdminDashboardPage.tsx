import React, { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { ApplicationData, ApplicationStatus } from '../types';
import { useAppContext } from '../hooks/useAppContext';
import { translateApplicationStatus, APPLICATION_STATUS_OPTIONS } from '../constants';
import { saveApplication as saveApplicationToDB } from '../services/applicationPersistenceService';
import Button from '../components/ui/Button';
import FormField from '../components/ui/FormField';
import Modal from '../components/ui/Modal';

const getAllSystemApplications = (): ApplicationData[] => {
  const stored = localStorage.getItem('childAllowanceApplications');
  return stored ? JSON.parse(stored) : [];
};


const AdminDashboardPage: React.FC = () => {
  const { translate, theme } = useAppContext();
  const [allApplications, setAllApplications] = useState<ApplicationData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [filterName, setFilterName] = useState('');
  const [filterDateStart, setFilterDateStart] = useState(''); // Changed from filterDate
  const [filterDateEnd, setFilterDateEnd] = useState('');     // New state for end date
  const [filterStatus, setFilterStatus] = useState('');

  const [showCommentModal, setShowCommentModal] = useState(false);
  const [currentActionApp, setCurrentActionApp] = useState<ApplicationData | null>(null);
  const [currentActionType, setCurrentActionType] = useState<'sendBack' | 'reject' | null>(null);
  const [adminComment, setAdminComment] = useState('');


  const fetchApplications = () => {
    const fetchedApplications = getAllSystemApplications();
    fetchedApplications.sort((a,b) => {
        const dateA = a.submissionDate || a.lastModifiedDate;
        const dateB = b.submissionDate || b.lastModifiedDate;
        return new Date(dateB).getTime() - new Date(dateA).getTime();
    });
    setAllApplications(fetchedApplications);
    setIsLoading(false);
  }

  useEffect(() => {
    fetchApplications();
  }, []);

  const filteredApplications = useMemo(() => {
    return allApplications.filter(app => {
      const nameMatch = filterName ? 
        (app.employeeFirstName?.toLowerCase().includes(filterName.toLowerCase()) || 
         app.employeeLastName?.toLowerCase().includes(filterName.toLowerCase())) 
        : true;
      
      const appDateStr = app.submissionDate || app.lastModifiedDate;
      let dateMatch = true;
      if (appDateStr) { // Ensure the application has a date
        if (filterDateStart && appDateStr < filterDateStart) {
          dateMatch = false;
        }
        if (filterDateEnd && appDateStr > filterDateEnd) {
          dateMatch = false;
        }
      } else {
        // If the application doesn't have a date, it cannot match if any date filter is set
        if (filterDateStart || filterDateEnd) {
            dateMatch = false;
        }
      }

      const statusMatch = filterStatus ? app.status === filterStatus : true;
      return nameMatch && dateMatch && statusMatch;
    });
  }, [allApplications, filterName, filterDateStart, filterDateEnd, filterStatus]);

  const handleAction = (app: ApplicationData, newStatus: ApplicationStatus, requiresComment: boolean = false, actionType?: 'sendBack' | 'reject') => {
    if (requiresComment && actionType) {
        setCurrentActionApp(app);
        setCurrentActionType(actionType);
        setAdminComment(app.adminComments || '');
        setShowCommentModal(true);
    } else {
        const updatedApp = { ...app, status: newStatus, lastModifiedDate: new Date().toISOString().split('T')[0] };
        if (!requiresComment) updatedApp.adminComments = undefined; // Clear comments if not a comment-based action
        saveApplicationToDB(updatedApp);
        fetchApplications(); // Re-fetch to update the list
    }
  };
  
  const handleReviewClick = (app: ApplicationData) => {
    if (app.status === ApplicationStatus.SUBMITTED) {
      handleAction(app, ApplicationStatus.UNDER_REVIEW);
    }
    // Navigation will be handled by the Link component
  };

  const submitCommentAndAction = () => {
    if (currentActionApp && currentActionType) {
        const newStatus = currentActionType === 'sendBack' ? ApplicationStatus.PENDING_EMPLOYEE_ACTION : ApplicationStatus.REJECTED;
        const updatedApp = { 
            ...currentActionApp, 
            status: newStatus, 
            adminComments: adminComment,
            lastModifiedDate: new Date().toISOString().split('T')[0]
        };
        saveApplicationToDB(updatedApp);
        fetchApplications(); // Re-fetch
        setShowCommentModal(false);
        setAdminComment('');
        setCurrentActionApp(null);
        setCurrentActionType(null);
    }
  };
  
  const clearFilters = () => {
    setFilterName('');
    setFilterDateStart(''); // Reset start date
    setFilterDateEnd('');   // Reset end date
    setFilterStatus('');
  };

  let cardBgClass = 'bg-white';
  let textColorClass = 'text-gray-700';
  let headingColorClass = 'text-gray-900';
  let tableDivideClass = 'divide-gray-200';
  let tableHeaderBgClass = 'bg-gray-50';
  let statusBadgeSubmittedBg = 'bg-yellow-100';
  let statusBadgeSubmittedText = 'text-yellow-800';
  let statusBadgeReviewBg = 'bg-purple-100';
  let statusBadgeReviewText = 'text-purple-800';
  let statusBadgePendingBg = 'bg-pink-100';
  let statusBadgePendingText = 'text-pink-800';
  let statusBadgeCompletedBg = 'bg-green-100';
  let statusBadgeCompletedText = 'text-green-800';
  let statusBadgeRejectedBg = 'bg-red-100';
  let statusBadgeRejectedText = 'text-red-800';
  let statusBadgeDefaultBg = 'bg-gray-100';
  let statusBadgeDefaultText = 'text-gray-800';


  if (theme === 'theme2') {
    cardBgClass = 'bg-theme2-secondary-bg';
    textColorClass = 'text-theme2-text';
    headingColorClass = 'text-theme2-text';
    tableDivideClass = 'divide-gray-200';
    tableHeaderBgClass = 'bg-gray-50'; // Light for theme2
    statusBadgeSubmittedBg = 'bg-blue-100'; statusBadgeSubmittedText = 'text-blue-800';
    statusBadgeReviewBg = 'bg-indigo-100'; statusBadgeReviewText = 'text-indigo-800';
    statusBadgePendingBg = 'bg-orange-100'; statusBadgePendingText = 'text-orange-800';
    // Green, Red, Gray can be fairly standard
  } else if (theme === 'theme3') {
    cardBgClass = 'bg-theme3-secondary-bg';
    textColorClass = 'text-theme3-text-on-light';
    headingColorClass = 'text-theme3-text-on-light';
    tableDivideClass = 'divide-gray-300';
    tableHeaderBgClass = 'bg-slate-100';
  } else if (theme === 'theme4') {
    cardBgClass = 'bg-theme4-secondary-bg';
    textColorClass = 'text-theme4-text-on-dark';
    headingColorClass = 'text-theme4-text-on-dark';
    tableDivideClass = 'divide-theme4-border';
    tableHeaderBgClass = 'bg-theme4-bg'; // Darker header for dark theme table
    statusBadgeSubmittedBg = 'bg-yellow-700/30'; statusBadgeSubmittedText = 'text-yellow-300';
    statusBadgeReviewBg = 'bg-purple-700/30'; statusBadgeReviewText = 'text-purple-300';
    statusBadgePendingBg = 'bg-pink-700/30'; statusBadgePendingText = 'text-pink-300';
    statusBadgeCompletedBg = 'bg-green-700/30'; statusBadgeCompletedText = 'text-green-300';
    statusBadgeRejectedBg = 'bg-red-700/30'; statusBadgeRejectedText = 'text-red-300';
    statusBadgeDefaultBg = 'bg-slate-600'; statusBadgeDefaultText = 'text-slate-300';
  }


  if (isLoading) {
    return <div className={`p-4 ${textColorClass}`}>{translate('loadingApplications')}</div>;
  }

  return (
    <div className="space-y-6">
      <h1 className={`text-3xl font-bold ${headingColorClass}`}>{translate('adminDashboardTitle')}</h1>

      <div className={`p-4 rounded-md shadow ${cardBgClass} grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4 items-end`}>
        <FormField
          id="filterName"
          label={translate('filterByEmployeeName')}
          value={filterName}
          onChange={(e) => setFilterName(e.target.value)}
          placeholder={translate('employeeName')}
        />
        <FormField
          id="filterDateStart"
          label={translate('filterBySubmissionDateFrom')} // Use new translation key
          type="date"
          value={filterDateStart}
          onChange={(e) => setFilterDateStart(e.target.value)}
        />
        <FormField
          id="filterDateEnd"
          label={translate('filterBySubmissionDateTo')} // Use new translation key
          type="date"
          value={filterDateEnd}
          onChange={(e) => setFilterDateEnd(e.target.value)}
        />
        <FormField
          id="filterStatus"
          label={translate('filterByStatus')}
          as="select"
          options={[{ value: "", labelKey: "allStatuses" }, ...APPLICATION_STATUS_OPTIONS]}
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value)}
        />
        <Button onClick={clearFilters} variant="secondary">{translate('clearFilters')}</Button>
      </div>
      
      {filteredApplications.length > 0 ? (
        <div className="overflow-x-auto shadow-md rounded-lg">
          <table className={`min-w-full divide-y ${tableDivideClass} ${cardBgClass}`}>
            <thead className={`${tableHeaderBgClass}`}>
              <tr>
                <th scope="col" className={`px-4 py-3 text-left text-xs font-medium ${headingColorClass} uppercase tracking-wider`}>{translate('applicationId')}</th>
                <th scope="col" className={`px-4 py-3 text-left text-xs font-medium ${headingColorClass} uppercase tracking-wider`}>{translate('employeeName')}</th>
                <th scope="col" className={`px-4 py-3 text-left text-xs font-medium ${headingColorClass} uppercase tracking-wider`}>{translate('submissionDate')}</th>
                <th scope="col" className={`px-4 py-3 text-left text-xs font-medium ${headingColorClass} uppercase tracking-wider`}>{translate('status')}</th>
                <th scope="col" className={`px-4 py-3 text-left text-xs font-medium ${headingColorClass} uppercase tracking-wider`}>{translate('actions')}</th>
              </tr>
            </thead>
            <tbody className={`divide-y ${tableDivideClass}`}>
              {filteredApplications.map((app) => (
                <tr key={app.id}>
                  <td className={`px-4 py-4 whitespace-nowrap text-sm ${textColorClass}`}>{app.id.substring(0,8)}...</td>
                  <td className={`px-4 py-4 whitespace-nowrap text-sm ${textColorClass}`}>{app.employeeFirstName} {app.employeeLastName}</td>
                  <td className={`px-4 py-4 whitespace-nowrap text-sm ${textColorClass}`}>{app.submissionDate || translate('na', 'N/A')}</td>
                  <td className={`px-4 py-4 whitespace-nowrap text-sm ${textColorClass}`}>
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        app.status === ApplicationStatus.SUBMITTED ? `${statusBadgeSubmittedBg} ${statusBadgeSubmittedText}` :
                        app.status === ApplicationStatus.UNDER_REVIEW ? `${statusBadgeReviewBg} ${statusBadgeReviewText}` :
                        app.status === ApplicationStatus.PENDING_EMPLOYEE_ACTION ? `${statusBadgePendingBg} ${statusBadgePendingText}` :
                        app.status === ApplicationStatus.COMPLETED ? `${statusBadgeCompletedBg} ${statusBadgeCompletedText}` :
                        app.status === ApplicationStatus.REJECTED ? `${statusBadgeRejectedBg} ${statusBadgeRejectedText}` :
                        `${statusBadgeDefaultBg} ${statusBadgeDefaultText}`
                    }`}>
                      {translateApplicationStatus(app.status, translate)}
                    </span>
                  </td>
                  <td className="px-4 py-4 whitespace-nowrap text-sm font-medium space-x-1 space-y-1">
                    <Link to={`/application/view/${app.id}`} onClick={() => handleReviewClick(app)}>
                        <Button variant="ghost" size="sm">{translate('review')}</Button>
                    </Link>
                    { (app.status === ApplicationStatus.SUBMITTED || app.status === ApplicationStatus.UNDER_REVIEW || app.status === ApplicationStatus.PENDING_EMPLOYEE_ACTION) &&
                        <Button variant="primary" size="sm" onClick={() => handleAction(app, ApplicationStatus.COMPLETED)}>{translate('approve')}</Button>
                    }
                     { (app.status === ApplicationStatus.SUBMITTED || app.status === ApplicationStatus.UNDER_REVIEW || app.status === ApplicationStatus.PENDING_EMPLOYEE_ACTION) &&
                        <Button variant="danger" size="sm" onClick={() => handleAction(app, ApplicationStatus.REJECTED, true, 'reject')}>{translate('reject')}</Button>
                    }
                    { (app.status === ApplicationStatus.SUBMITTED || app.status === ApplicationStatus.UNDER_REVIEW) &&
                        <Button variant="secondary" size="sm" onClick={() => handleAction(app, ApplicationStatus.PENDING_EMPLOYEE_ACTION, true, 'sendBack')}>{translate('sendBack')}</Button>
                    }
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <p className={textColorClass}>{translate('noApplicationsSystem')}</p>
      )}
      <p className={`mt-4 text-xs ${textColorClass}`}>
        {translate('adminNote')}
      </p>

      <Modal
        isOpen={showCommentModal}
        onClose={() => {
            setShowCommentModal(false);
            setAdminComment('');
            setCurrentActionApp(null);
            setCurrentActionType(null);
        }}
        title={translate('commentsForEmployee')}
        onOk={submitCommentAndAction}
        okText={translate('submitComment')}
        showCancelButton={true}
      >
        <FormField
          id="adminCommentText"
          label={translate('commentsForEmployee')}
          as="textarea"
          rows={4}
          value={adminComment}
          onChange={(e) => setAdminComment(e.target.value)}
          placeholder={translate('enterComments')}
        />
      </Modal>

    </div>
  );
};

export default AdminDashboardPage;