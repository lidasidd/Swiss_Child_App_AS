import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ApplicationData, ChildDetails, UploadedFile, ApplicationStatus, MaritalStatus, IncomeComparison, SpouseEmploymentStatus, LegalParentEmploymentStatus, CarerRelationshipType } from '../types';
import { getApplicationById } from '../services/applicationPersistenceService';
import { useAppContext } from '../hooks/useAppContext';
import Button from '../components/ui/Button';
import LoadingSpinner from '../components/ui/LoadingSpinner';
import { translateApplicationStatus, EU_EFTA_FREE_MOVEMENT_COUNTRIES, YES_NO_OPTIONS, SWISS_CANTONS } from '../constants';


const DetailSection: React.FC<{ titleKey: string; children: React.ReactNode; defaultTitle: string;}> = ({ titleKey, children, defaultTitle }) => {
  const { translate, theme } = useAppContext();
  let cardBgClass = 'bg-white';
  let headingColorClass = 'text-gray-900';
  let borderColor = 'border-gray-200';

  if (theme === 'theme2') {
    cardBgClass = 'bg-theme2-secondary-bg/70';
    headingColorClass = 'text-theme2-text';
    borderColor = 'border-gray-200';
  } else if (theme === 'theme3') {
    cardBgClass = 'bg-theme3-secondary-bg/70';
    headingColorClass = 'text-theme3-text-on-light';
    borderColor = 'border-gray-300';
  } else if (theme === 'theme4') {
    cardBgClass = 'bg-theme4-secondary-bg/70'; // Slightly transparent
    headingColorClass = 'text-theme4-text-on-dark';
    borderColor = 'border-theme4-border';
  }


  return (
    <div className={`mb-6 p-4 border rounded-md shadow ${cardBgClass} ${borderColor}`}>
      <h2 className={`text-lg font-semibold mb-3 ${headingColorClass}`}>{translate(titleKey, defaultTitle)}</h2>
      <div className="space-y-1">{children}</div>
    </div>
  );
};

const DetailItem: React.FC<{ labelKey: string; value?: string | number | null | boolean | ApplicationStatus | MaritalStatus | IncomeComparison | SpouseEmploymentStatus | LegalParentEmploymentStatus | CarerRelationshipType; defaultLabel: string; children?: React.ReactNode; isStatus?: boolean; isBoolean?: boolean; options?: {value: string, labelKey?: string, label?: string}[]; enumPrefix?: string; }> = ({ labelKey, value, defaultLabel, children, isStatus = false, isBoolean = false, options, enumPrefix }) => {
  const { translate, theme } = useAppContext();
  
  let textColor = 'text-gray-700'; // Default
  if (theme === 'theme2') textColor = 'text-theme2-text';
  else if (theme === 'theme3') textColor = 'text-theme3-text-on-light';
  else if (theme === 'theme4') textColor = 'text-theme4-text-on-dark';
  
  const labelColor = `${textColor} font-medium`;

  let displayValue: React.ReactNode = value;

  if (value === null || value === undefined || value === '') {
    displayValue = <span className="italic opacity-75">{translate('notProvided')}</span>;
  } else if (isStatus && typeof value === 'string') {
    displayValue = translateApplicationStatus(value as ApplicationStatus, translate);
  } else if (isBoolean) {
    displayValue = value ? translate('optionYes') : translate('optionNo');
  } else if (options && typeof value === 'string') {
    const selectedOption = options.find(opt => opt.value === value);
    if (selectedOption) {
        displayValue = selectedOption.labelKey ? translate(selectedOption.labelKey, selectedOption.label || value) : (selectedOption.label || value);
    }
  } else if (enumPrefix && typeof value === 'string') {
    displayValue = translate(`${enumPrefix}${value.replace(/\s+/g, '').replace(/[^a-zA-Z0-9]/g, '')}`, value);
  }


  if (children) {
    return (
        <div className="py-1">
            <p className={`${labelColor}`}>{translate(labelKey, defaultLabel)}:</p>
            <div className={`pl-2 ${textColor}`}>{children}</div>
        </div>
    );
  }

  return (
    <p className={`${textColor}`}>
      <span className={`${labelColor}`}>{translate(labelKey, defaultLabel)}:</span> {displayValue}
    </p>
  );
};

const ViewApplicationPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [application, setApplication] = useState<ApplicationData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { translate, theme, user } = useAppContext(); 

  useEffect(() => {
    if (id) {
      const app = getApplicationById(id);
      setApplication(app);
    }
    setIsLoading(false);
  }, [id]);

  let pageTitleColor = 'text-gray-900'; // Default
  if(theme === 'theme2') pageTitleColor = 'text-theme2-text';
  if(theme === 'theme3') pageTitleColor = 'text-theme3-text-on-light';
  if(theme === 'theme4') pageTitleColor = 'text-theme4-text-on-dark';


  if (isLoading) return <LoadingSpinner text={translate('loading', 'Loading...')} />;
  if (!application) return <p className={pageTitleColor}>{translate('applicationNotFound')}</p>;
  
  const getDocumentName = (doc: UploadedFile | undefined): string => {
    return doc ? doc.name : translate('notProvided', 'Not Provided');
  };

  const hasAnyChildBirthCertificate = application.children.some(c => c.birthCertificate);
  const hasOtherMainDocuments = application.marriageCertificate || application.divorceDecree || (application.educationConfirmations && application.educationConfirmations.length > 0);
  
  let childDetailCardBg = 'bg-gray-50';
  let childDetailCardBorder = 'border-gray-200';
  let childDetailCardTitleColor = 'text-gray-800';

  if(theme === 'theme2') {
    childDetailCardBg = 'bg-gray-50';
    childDetailCardBorder = 'border-gray-200';
    childDetailCardTitleColor = 'text-theme2-text';
  } else if(theme === 'theme3') {
    childDetailCardBg = 'bg-slate-100';
    childDetailCardBorder = 'border-gray-300';
    childDetailCardTitleColor = 'text-theme3-text-on-light';
  } else if(theme === 'theme4') {
    childDetailCardBg = 'bg-theme4-secondary-bg-hover'; // Slightly lighter than section bg
    childDetailCardBorder = 'border-theme4-border';
    childDetailCardTitleColor = 'text-theme4-text-on-dark';
  }


  return (
    <div className="max-w-3xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h1 className={`text-2xl font-bold ${pageTitleColor}`}>{translate('viewApplicationTitle')}</h1>
        <Link to={application.userId === user?.id ? "/" : "/admin"}>
          <Button variant="secondary">{translate('backToDashboard')}</Button>
        </Link>
      </div>

      <DetailSection titleKey="applicationSummary" defaultTitle="Application Summary">
        <DetailItem labelKey="applicationId" value={application.id.substring(0,12)+'...'} defaultLabel="Application ID" />
        <DetailItem labelKey="status" value={application.status} defaultLabel="Status" isStatus={true} />
        <DetailItem labelKey="submissionDate" value={application.submissionDate} defaultLabel="Submission Date" />
        <DetailItem labelKey="lastModifiedDate" value={application.lastModifiedDate} defaultLabel="Last Modified" />
        {application.adminComments && (
           <DetailItem labelKey="adminComments" defaultLabel="Admin Comments">
             <span className="italic">{application.adminComments}</span>
           </DetailItem>
        )}
      </DetailSection>
      
      <DetailSection titleKey="step1Title" defaultTitle="Residency Confirmation">
        <DetailItem labelKey="countryOfResidence" value={application.residencyCountry} defaultLabel="Country of Residence" options={EU_EFTA_FREE_MOVEMENT_COUNTRIES} />
      </DetailSection>

      <DetailSection titleKey="employeeInformation" defaultTitle="Employee Information">
        <DetailItem labelKey="firstName" value={application.employeeFirstName} defaultLabel="First Name" />
        <DetailItem labelKey="lastName" value={application.employeeLastName} defaultLabel="Last Name" />
        <DetailItem labelKey="dateOfBirth" value={application.employeeDateOfBirth} defaultLabel="Date of Birth" />
        <DetailItem labelKey="employeeId" value={application.employeeEmployeeId} defaultLabel="Employee ID" />
        <DetailItem labelKey="ahvNumber" value={application.employeeAhvNumber} defaultLabel="AHV Number" />
        <DetailItem labelKey="companyName" value={application.employeeCompanyName} defaultLabel="Company Name" />
        <DetailItem labelKey="contractStartDate" value={application.employeeContractStartDate} defaultLabel="Contract Start Date" />
        <DetailItem labelKey="contractEndDate" value={application.employeeContractEndDate} defaultLabel="Contract End Date" />
      </DetailSection>

      <DetailSection titleKey="step3Title" defaultTitle="Prior Application in Residence Country">
        <DetailItem labelKey="step3Question" value={application.appliedInResidenceCountry} defaultLabel="Applied in residence country?" isBoolean={true} />
      </DetailSection>

      <DetailSection titleKey="personalDetails" defaultTitle="Applicant's Personal Details">
        <DetailItem labelKey="address" value={`${application.addressStreet || ''} ${application.addressStreetNo || ''}, ${application.addressPostCode || ''} ${application.addressTown || ''}, ${application.addressCity || ''}`} defaultLabel="Address"/>
        <DetailItem labelKey="telephone" value={application.telephone} defaultLabel="Telephone"/>
        <DetailItem labelKey="email" value={application.email} defaultLabel="Email"/>
        <DetailItem labelKey="maritalStatus" value={application.maritalStatus} defaultLabel="Marital Status" enumPrefix="maritalStatus"/>
        <DetailItem labelKey="maritalStatusSince" value={application.maritalStatusSince} defaultLabel="Marital Status Since"/>
      </DetailSection>

      <DetailSection titleKey="otherEmployersSection" defaultTitle="Other Employers">
        <DetailItem labelKey="step5Question" value={application.hasOtherEmployers} defaultLabel="Working for other employers?" isBoolean={true} />
        {application.hasOtherEmployers && application.otherEmployers.length > 0 && (
            application.otherEmployers.map((emp, idx) => (
                <div key={emp.id || idx} className="mt-2 pt-2 border-t">
                    <p className='font-medium'>{translate('employer')} {idx + 1}</p>
                    <DetailItem labelKey="employerName" value={emp.name} defaultLabel="Employer Name" />
                    <DetailItem labelKey="employerAddress" value={emp.address} defaultLabel="Employer Address" />
                    <DetailItem labelKey="incomeAtOtherEmployer" value={emp.incomeComparedToViking} defaultLabel="Income higher than at Viking?" enumPrefix="incomeComparison" />
                </div>
            ))
        )}
         {application.hasOtherEmployers && application.otherEmployers.length === 0 && (
            <DetailItem labelKey="na" value={translate('noDetailsProvided', 'No employer details provided.')} defaultLabel=""/>
        )}
      </DetailSection>
      
      <DetailSection titleKey="employeeCashBenefitsSection" defaultTitle="Employee Cash Benefits">
        <DetailItem labelKey="step7Question" value={application.receivingCashBenefits} defaultLabel="Receiving cash benefits?" isBoolean={true} />
        {application.receivingCashBenefits && (
            <>
                <DetailItem labelKey="benefitType" value={application.benefitType} defaultLabel="Type of Benefit" />
                <DetailItem labelKey="benefitReceivedSince" value={application.benefitReceivedSince} defaultLabel="Benefit Received Since" />
                <DetailItem labelKey="paymentOffice" value={application.benefitPaymentOffice} defaultLabel="Payment Office" />
            </>
        )}
      </DetailSection>

      <DetailSection titleKey="spouseDetailsSection" defaultTitle="Spouse/Partner Details">
        <DetailItem labelKey="spouseLastName" value={application.spouseLastName} defaultLabel="Spouse Last Name" />
        <DetailItem labelKey="spouseFirstName" value={application.spouseFirstName} defaultLabel="Spouse First Name" />
        <DetailItem labelKey="spouseDateOfBirth" value={application.spouseDateOfBirth} defaultLabel="Spouse Date of Birth" />
        <DetailItem labelKey="spousePersonalId" value={application.spousePersonalId} defaultLabel="Spouse Personal ID" />
        <DetailItem labelKey="spouseMaritalStatus" value={application.spouseMaritalStatus} defaultLabel="Spouse Marital Status" enumPrefix="maritalStatus" />
      </DetailSection>

      <DetailSection titleKey="spouseEmploymentSection" defaultTitle="Spouse/Partner Employment">
        <DetailItem labelKey="step9Question" value={application.isSpouseGainfullyEmployed} defaultLabel="Spouse gainfully employed?" isBoolean={true} />
        {application.isSpouseGainfullyEmployed === false && (
            <DetailItem labelKey="spouseEmploymentStatusLabel" value={application.spouseEmploymentStatus} defaultLabel="Spouse Employment Status" enumPrefix="spouseEmploymentStatus" />
        )}
      </DetailSection>

      {application.isSpouseGainfullyEmployed === false && (
        <DetailSection titleKey="spouseCashBenefitsSection" defaultTitle="Spouse/Partner Cash Benefits">
            <DetailItem labelKey="step10Question" value={application.spouseReceivingCashBenefits} defaultLabel="Spouse receiving cash benefits?" isBoolean={true} />
            {application.spouseReceivingCashBenefits && (
            <>
                <DetailItem labelKey="benefitType" value={application.spouseBenefitType} defaultLabel="Benefit Type" />
                <DetailItem labelKey="benefitReceivedSince" value={application.spouseBenefitReceivedSince} defaultLabel="Benefit Received Since" />
                <DetailItem labelKey="paymentOffice" value={application.spouseBenefitPaymentOffice} defaultLabel="Payment Office" />
            </>
            )}
        </DetailSection>
      )}

      {application.isSpouseGainfullyEmployed === true && (
        <DetailSection titleKey="spouseEmployerSection" defaultTitle="Spouse/Partner Employer Details">
            <DetailItem labelKey="spouseEmployerName" value={application.spouseEmployerName} defaultLabel="Spouse Employer Name" />
            <DetailItem labelKey="spouseEmployerAddress" value={application.spouseEmployerAddress} defaultLabel="Spouse Employer Address" />
            <DetailItem labelKey="spouseEmployerCantonCountry" value={application.spouseEmployerCantonCountry} defaultLabel="Spouse Employment Canton/Country" />
            <DetailItem labelKey="spouseEmploymentExtent" value={application.spouseEmploymentExtent ? `${application.spouseEmploymentExtent}%` : undefined} defaultLabel="Spouse Employment Extent" />
            <DetailItem labelKey="spouseIncomeComparison" value={application.spouseIncomeComparedToApplicant} defaultLabel="Spouse Income vs Applicant" enumPrefix="incomeComparison" />
        </DetailSection>
      )}
      
      {application.children && application.children.length > 0 && (
        <DetailSection titleKey="childrenDetails" defaultTitle="Children Details">
          {application.children.map((child: ChildDetails, index: number) => (
            <div key={child.id || index} className={`p-3 my-2 rounded border ${childDetailCardBg} ${childDetailCardBorder}`}>
              <h4 className={`font-semibold ${childDetailCardTitleColor}`}>{translate('child')} {index + 1}: {child.firstName} {child.lastName}</h4>
              <DetailItem labelKey="dateOfBirth" value={child.dateOfBirth} defaultLabel="Date of Birth" />
              <DetailItem labelKey="gender" value={child.gender} defaultLabel="Gender" enumPrefix="gender" />
              <DetailItem labelKey="address" value={child.address} defaultLabel="Address" />
              <DetailItem labelKey="placeOfResidence" value={child.placeOfResidence} defaultLabel="Place of Residence" />
              <DetailItem labelKey="relationshipToApplicant" value={child.relationshipToApplicant} defaultLabel="Relationship" enumPrefix="relationshipToApplicant" />
              <DetailItem labelKey="birthCertificateLabel" defaultLabel="Birth Certificate" value={getDocumentName(child.birthCertificate)} />
            </div>
          ))}
        </DetailSection>
      )}

       <DetailSection titleKey="legalParentSection" defaultTitle="Legal Parent Details (if different)">
        <DetailItem labelKey="step14Question" value={application.hasDifferentLegalParent} defaultLabel="Other legal parent details different?" isBoolean={true}/>
        {application.hasDifferentLegalParent && (
            <>
                <DetailItem labelKey="legalParentAppliesToAllChildren" value={application.legalParentAppliesToAllChildren} defaultLabel="Applies to all children?" isBoolean={true} />
                {!application.legalParentAppliesToAllChildren && application.legalParentAppliesToChildIds && application.legalParentAppliesToChildIds.length > 0 && (
                    <DetailItem labelKey="selectApplicableChildren" defaultLabel="Applies to specific children:">
                        <ul>{application.legalParentAppliesToChildIds.map(id => {
                            const child = application.children.find(c => c.id === id);
                            return <li key={id}>{child ? `${child.firstName} ${child.lastName}`: id}</li>;
                        })}</ul>
                    </DetailItem>
                )}
                <DetailItem labelKey="legalParentLastName" value={application.legalParentLastName} defaultLabel="Last Name"/>
                <DetailItem labelKey="legalParentFirstName" value={application.legalParentFirstName} defaultLabel="First Name"/>
                <DetailItem labelKey="legalParentDob" value={application.legalParentDateOfBirth} defaultLabel="Date of Birth"/>
                <DetailItem labelKey="legalParentMaritalStatus" value={application.legalParentMaritalStatus} defaultLabel="Marital Status" enumPrefix="maritalStatus"/>
                <DetailItem labelKey="legalParentAddress" value={application.legalParentAddress} defaultLabel="Address"/>
                <DetailItem labelKey="legalParentTelephone" value={application.legalParentTelephone} defaultLabel="Telephone"/>
                <DetailItem labelKey="legalParentEmploymentDetail" value={application.legalParentEmploymentDetail} defaultLabel="Employment Detail" enumPrefix="legalParentEmploymentStatus"/>
                {application.legalParentEmploymentDetail === LegalParentEmploymentStatus.EMPLOYED && (
                    <>
                        <DetailItem labelKey="legalParentEmployerNameAddress" value={`${application.legalParentEmployerName || ''}, ${application.legalParentEmployerAddress || ''}`} defaultLabel="Employer Name & Address"/>
                        <DetailItem labelKey="legalParentEmployerCantonCountry" value={application.legalParentEmployerCantonCountry} defaultLabel="Canton/Country of Employment"/>
                    </>
                )}
                {application.legalParentEmploymentDetail === LegalParentEmploymentStatus.SELF_EMPLOYED && (
                    <DetailItem labelKey="legalParentSelfEmployedCantonCountry" value={application.legalParentSelfEmployedCantonCountry} defaultLabel="Canton/Country of Self-Employment"/>
                )}
            </>
        )}
       </DetailSection>

       <DetailSection titleKey="childCarerSection" defaultTitle="Child's Carer Details">
        <DetailItem labelKey="step15Question" value={application.childLivesWithOtherCarer} defaultLabel="Child lives with other carer (specific conditions)?" isBoolean={true}/>
         {application.childLivesWithOtherCarer && (
            <>
                <DetailItem labelKey="carerAppliesToAllChildren" value={application.carerAppliesToAllChildren} defaultLabel="Applies to all children?" isBoolean={true} />
                {!application.carerAppliesToAllChildren && application.carerAppliesToChildIds && application.carerAppliesToChildIds.length > 0 && (
                    <DetailItem labelKey="selectApplicableChildren" defaultLabel="Applies to specific children:">
                        <ul>{application.carerAppliesToChildIds.map(id => {
                            const child = application.children.find(c => c.id === id);
                            return <li key={id}>{child ? `${child.firstName} ${child.lastName}`: id}</li>;
                        })}</ul>
                    </DetailItem>
                )}
                <DetailItem labelKey="carerLastName" value={application.carerLastName} defaultLabel="Carer Last Name"/>
                <DetailItem labelKey="carerFirstName" value={application.carerFirstName} defaultLabel="Carer First Name"/>
                <DetailItem labelKey="carerTelephone" value={application.carerTelephone} defaultLabel="Carer Telephone"/>
                <DetailItem labelKey="carerRelationship" value={application.carerRelationship === CarerRelationshipType.OTHER ? `${translate('carerRelationshipTypeOther')} (${application.carerRelationshipOtherText || ''})` : application.carerRelationship} defaultLabel="Carer Relationship" enumPrefix="carerRelationshipType"/>
            </>
         )}
       </DetailSection>

       <DetailSection titleKey="previousAllowancesSection" defaultTitle="Previous Swiss Child Allowances">
        <DetailItem labelKey="step17Question" value={application.receivedSwissChildAllowancesBefore} defaultLabel="Received Swiss allowances before?" isBoolean={true}/>
        {application.receivedSwissChildAllowancesBefore && (
            <>
                <DetailItem labelKey="whichCanton" value={application.previousAllowanceCanton} defaultLabel="Canton" options={SWISS_CANTONS} />
                <DetailItem labelKey="untilWhen" value={application.previousAllowanceUntilDate} defaultLabel="Until When"/>
            </>
        )}
       </DetailSection>


      <DetailSection titleKey="uploadedDocuments" defaultTitle="Uploaded Documents (Excluding Birth Certificates shown with Child)">
        {application.marriageCertificate && <DetailItem labelKey="marriageCertificateLabel" defaultLabel="Marriage Certificate" value={getDocumentName(application.marriageCertificate)}/>}
        {application.divorceDecree && <DetailItem labelKey="divorceDecreeLabel" defaultLabel="Divorce Decree" value={getDocumentName(application.divorceDecree)}/>}
        {application.educationConfirmations && application.educationConfirmations.length > 0 && 
            <DetailItem labelKey="educationConfirmationsLabel" defaultLabel="Education Confirmation(s)">
                <ul>{application.educationConfirmations.map((f: UploadedFile) => <li key={f.id}>{f.name}</li>)}</ul>
            </DetailItem>
        }
        {!hasOtherMainDocuments && <p className={theme === 'theme4' ? 'text-theme4-text-on-dark' : (theme === 'theme3' ? 'text-theme3-text-on-light' : 'text-theme2-text') }>{translate('noDocumentsUploaded')}</p>}
      </DetailSection>

       <DetailSection titleKey="signature" defaultTitle="Signature & Confirmation">
            <DetailItem labelKey="signedBy" value={application.signatureName} defaultLabel="Signed By"/>
            <DetailItem labelKey="signatureDate" value={application.signatureDate} defaultLabel="Date of Signature"/>
            <DetailItem labelKey="informationConfirmationLabel" value={application.informationConfirmed ? translate('informationConfirmedTrue') : translate('informationConfirmedFalse')} defaultLabel="Information Confirmed"/>
        </DetailSection>

    </div>
  );
};

export default ViewApplicationPage;