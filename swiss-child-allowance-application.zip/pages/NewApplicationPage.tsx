
import React from 'react';
import NewApplicationForm from '../components/application/NewApplicationForm';

const NewApplicationPage: React.FC = () => {
  return (
    <div>
      <NewApplicationForm />
    </div>
  );
};

export default NewApplicationPage;
