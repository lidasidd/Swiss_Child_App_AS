import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAppContext } from '../hooks/useAppContext';
import Button from '../components/ui/Button';
import ApplicationListItem from '../components/application/ApplicationListItem';
import UserQuestionnaireListItem from '../components/questionnaire/UserQuestionnaireListItem'; // Import new component
import { ApplicationData, UserQuestionnaire, UserQuestionnaireStatus, UploadedFile } from '../types';
import { getAllApplications } from '../services/applicationPersistenceService'; 
import LoadingSpinner from '../components/ui/LoadingSpinner';
import { ALLOWED_QUESTIONNAIRE_FILE_TYPES } from '../constants';
import Modal from '../components/ui/Modal';
import FormField from '../components/ui/FormField';
import FileUpload from '../components/ui/FileUpload';

// Helper function to download file from base64
const downloadFileFromBase64 = (base64String: string | undefined, fileName: string, mimeType: string) => {
  if (!base64String) {
    alert('File data is not available for download.');
    return;
  }
  const linkSource = `data:${mimeType};base64,${base64String}`;
  const downloadLink = document.createElement("a");
  downloadLink.href = linkSource;
  downloadLink.download = fileName;
  document.body.appendChild(downloadLink); // Required for Firefox
  downloadLink.click();
  document.body.removeChild(downloadLink);
};


const DashboardPage: React.FC = () => {
  const { translate, user, sfUserData, setActiveApplication, isLoadingSFData, theme, userQuestionnaires, submitQuestionnaireResponse } = useAppContext();
  const [applications, setApplications] = useState<ApplicationData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  const [showRespondModal, setShowRespondModal] = useState(false);
  const [currentQuestionnaireToRespond, setCurrentQuestionnaireToRespond] = useState<UserQuestionnaire | null>(null);
  const [employeeResponseFile, setEmployeeResponseFile] = useState<UploadedFile | null>(null);
  const [employeeResponseComments, setEmployeeResponseComments] = useState('');


  useEffect(() => {
    if (user) {
      const fetchedApplications = getAllApplications(user.id);
      setApplications(fetchedApplications);
    }
    setIsLoading(false);
  }, [user]);

  const handleNewApplication = () => {
    if (!user || !sfUserData) return;
    setActiveApplication(null); 
  };
  
  let cardBgClass = 'bg-white';
  let textColorClass = 'text-gray-700';
  let headingColorClass = 'text-gray-900';
  // itemBorderClass and itemTitleColor are now handled within UserQuestionnaireListItem


  if (theme === 'theme2') {
    cardBgClass = 'bg-theme2-secondary-bg';
    textColorClass = 'text-theme2-text';
    headingColorClass = 'text-theme2-text';
  } else if (theme === 'theme3') {
    cardBgClass = 'bg-theme3-secondary-bg';
    textColorClass = 'text-theme3-text-on-light';
    headingColorClass = 'text-theme3-text-on-light';
  } else if (theme === 'theme4') {
    cardBgClass = 'bg-theme4-secondary-bg';
    textColorClass = 'text-theme4-text-on-dark';
    headingColorClass = 'text-theme4-text-on-dark';
  }


  if (isLoading || isLoadingSFData) {
    return <LoadingSpinner text={translate('loading', 'Loading...')} />;
  }
  
  const currentUserQuestionnaires = userQuestionnaires.filter(q => q.recipientUserId === user?.id);

  const openRespondModal = (questionnaire: UserQuestionnaire) => {
    setCurrentQuestionnaireToRespond(questionnaire);
    setEmployeeResponseFile(null); // Reset for new modal open
    setEmployeeResponseComments(questionnaire.status !== UserQuestionnaireStatus.PENDING_EMPLOYEE_RESPONSE ? questionnaire.employeeResponseComments || '' : '');
    setShowRespondModal(true);
  };

  const handleSubmitResponse = () => {
    if (!currentQuestionnaireToRespond || !employeeResponseFile) {
        alert(translate('pleaseUploadResponseFile', 'Please upload your response file.'));
        return;
    }
    submitQuestionnaireResponse(currentQuestionnaireToRespond.id, employeeResponseFile, employeeResponseComments);
    setShowRespondModal(false);
    alert(translate('questionnaireResponseSubmitted'));
  };
  
  const handleDownloadOriginalQuestionnaire = () => {
    if (currentQuestionnaireToRespond?.questionnaireFile?.base64) {
      downloadFileFromBase64(
        currentQuestionnaireToRespond.questionnaireFile.base64,
        currentQuestionnaireToRespond.questionnaireFile.name,
        currentQuestionnaireToRespond.questionnaireFile.type
      );
    } else {
      alert(translate('fileNotAvailableForDownload', 'Original questionnaire file is not available for download.'));
    }
  };

  const handleDownloadEmployeeResponse = () => {
    if (currentQuestionnaireToRespond?.employeeResponseFile?.base64) {
      downloadFileFromBase64(
        currentQuestionnaireToRespond.employeeResponseFile.base64,
        currentQuestionnaireToRespond.employeeResponseFile.name,
        currentQuestionnaireToRespond.employeeResponseFile.type
      );
    } else {
      alert(translate('fileNotAvailableForDownload', 'Your response file is not available for download.'));
    }
  };
  
  const isViewOnlyModal = currentQuestionnaireToRespond?.status !== UserQuestionnaireStatus.PENDING_EMPLOYEE_RESPONSE;


  return (
    <div className="space-y-8">
      <div className={`p-6 rounded-lg shadow-md ${cardBgClass}`}>
        <h1 className={`text-3xl font-bold ${headingColorClass}`}>{translate('welcome')}, {user?.name || translate('employee', 'Employee')}!</h1>
        {sfUserData?.hrManagerName && <p className={`mt-1 text-md ${textColorClass}`}>{translate('hrManager')}: {sfUserData.hrManagerName}</p>}
      </div>

      <div className={`p-6 rounded-lg shadow-md ${cardBgClass}`}>
        <div className="flex justify-between items-center mb-4">
          <h2 className={`text-2xl font-semibold ${headingColorClass}`}>{translate('applicationHistory')}</h2>
          <Link to="/application/new" onClick={handleNewApplication}>
            <Button variant="primary">
              {translate('newApplication')}
            </Button>
          </Link>
        </div>
        {applications.length > 0 ? (
          applications.map(app => <ApplicationListItem key={app.id} application={app} />)
        ) : (
          <p className={textColorClass}>{translate('noApplicationsFound', 'No applications found. Start a new one!')}</p>
        )}
      </div>

      <div className={`p-6 rounded-lg shadow-md ${cardBgClass}`}>
          <h2 className={`text-2xl font-semibold ${headingColorClass} mb-4`}>{translate('actions')}</h2>
          {currentUserQuestionnaires.length > 0 ? (
            currentUserQuestionnaires.map(q => (
              <UserQuestionnaireListItem 
                key={q.id} 
                questionnaire={q} 
                onOpenModal={openRespondModal} 
              />
            ))
          ) : (
            <p className={textColorClass}>{translate('noQuestionnairesFound', 'No questionnaires found.')}</p>
          )}
        </div>

      {/* Respond/View Questionnaire Modal */}
      {currentQuestionnaireToRespond && (
        <Modal
            isOpen={showRespondModal}
            onClose={() => setShowRespondModal(false)}
            title={`${isViewOnlyModal ? translate('viewDetails') : translate('respondToQuestionnaire')}: ${currentQuestionnaireToRespond.title}`}
            onOk={!isViewOnlyModal ? handleSubmitResponse : undefined}
            okText={!isViewOnlyModal ? translate('submitResponse') : undefined}
            showOkButton={!isViewOnlyModal}
            showCancelButton={true}
            size="lg"
        >
            <div className="space-y-4">
                <div>
                    <h4 className={`font-semibold text-md mb-1 ${headingColorClass}`}>{translate('questionnaireCommentsByAdmin')}:</h4>
                    <p className={`text-sm p-2 rounded ${theme === 'theme4' ? 'bg-theme4-bg text-theme4-text-on-dark' : 'bg-gray-100 text-gray-700'}`}>
                        {currentQuestionnaireToRespond.adminComments || translate('na', 'N/A')}
                    </p>
                </div>
                <Button 
                    variant="ghost"
                    onClick={handleDownloadOriginalQuestionnaire}
                    disabled={!currentQuestionnaireToRespond.questionnaireFile?.base64}
                    className="w-full"
                >
                    {translate('downloadQuestionnaire')} ({currentQuestionnaireToRespond.questionnaireFile.name})
                </Button>

                {isViewOnlyModal && currentQuestionnaireToRespond.employeeResponseFile && (
                    <Button 
                        variant="ghost"
                        onClick={handleDownloadEmployeeResponse}
                        disabled={!currentQuestionnaireToRespond.employeeResponseFile?.base64}
                        className="w-full mt-2"
                    >
                        {translate('downloadYourResponse')} ({currentQuestionnaireToRespond.employeeResponseFile.name})
                    </Button>
                )}

                <FileUpload
                    id="employeeResponseFileUpload"
                    label={translate('uploadResponseFile')}
                    onFilesChange={(files) => setEmployeeResponseFile(files.length > 0 ? files[0] : null)}
                    multiple={false}
                    required={!isViewOnlyModal}
                    allowedFileTypes={ALLOWED_QUESTIONNAIRE_FILE_TYPES}
                    disabled={isViewOnlyModal}
                    existingFiles={currentQuestionnaireToRespond.employeeResponseFile && isViewOnlyModal ? [currentQuestionnaireToRespond.employeeResponseFile] : []}
                />
                <FormField
                    id="employeeResponseComments"
                    label={translate('yourComments')}
                    as="textarea"
                    rows={3}
                    value={employeeResponseComments}
                    onChange={(e) => setEmployeeResponseComments(e.target.value)}
                    placeholder={isViewOnlyModal ? translate('na') : translate('enterComments')}
                    disabled={isViewOnlyModal}
                />
            </div>
        </Modal>
      )}

    </div>
  );
};

export default DashboardPage;