
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAppContext } from '../hooks/useAppContext';
import Button from '../components/ui/Button';
import ApplicationListItem from '../components/application/ApplicationListItem';
import { ApplicationData, Questionnaire } from '../types';
import { getAllApplications } from '../services/applicationPersistenceService'; 
import LoadingSpinner from '../components/ui/LoadingSpinner';

const DashboardPage: React.FC = () => {
  const { translate, user, sfUserData, setActiveApplication, isLoadingSFData, theme } = useAppContext();
  const [applications, setApplications] = useState<ApplicationData[]>([]);
  const [questionnaires, setQuestionnaires] = useState<Questionnaire[]>([]); 
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (user) {
      const fetchedApplications = getAllApplications(user.id);
      setApplications(fetchedApplications);
      // Mock questionnaires (example)
      // setQuestionnaires([
      //   { id: 'q1', title: translate('annualIncomeVerificationTitle', 'Annual Income Verification'), deadline: '2024-12-31', instructions: translate('annualIncomeVerificationInstructions', 'Please update your income details.'), status: 'Pending' },
      // ]);
    }
    setIsLoading(false);
  }, [user, translate]); // Added translate to dependencies for questionnaire example

  const handleNewApplication = () => {
    if (!user || !sfUserData) return;
    setActiveApplication(null); 
  };
  
  let cardBgClass = 'bg-white';
  let textColorClass = 'text-gray-700';
  let headingColorClass = 'text-gray-900';
  let questionnaireBorderClass = 'border-gray-200';


  if (theme === 'theme2') {
    cardBgClass = 'bg-theme2-secondary-bg';
    textColorClass = 'text-theme2-text';
    headingColorClass = 'text-theme2-text';
    questionnaireBorderClass = 'border-gray-200';
  } else if (theme === 'theme3') {
    cardBgClass = 'bg-theme3-secondary-bg';
    textColorClass = 'text-theme3-text-on-light';
    headingColorClass = 'text-theme3-text-on-light';
    questionnaireBorderClass = 'border-gray-300';
  } else if (theme === 'theme4') {
    cardBgClass = 'bg-theme4-secondary-bg';
    textColorClass = 'text-theme4-text-on-dark';
    headingColorClass = 'text-theme4-text-on-dark';
    questionnaireBorderClass = 'border-theme4-border';
  }


  if (isLoading || isLoadingSFData) {
    return <LoadingSpinner text={translate('loading', 'Loading...')} />;
  }

  return (
    <div className="space-y-8">
      <div className={`p-6 rounded-lg shadow-md ${cardBgClass}`}>
        <h1 className={`text-3xl font-bold ${headingColorClass}`}>{translate('welcome')}, {user?.name || translate('employee', 'Employee')}!</h1>
        {sfUserData?.hrManagerName && <p className={`mt-1 text-md ${textColorClass}`}>{translate('hrManager')}: {sfUserData.hrManagerName}</p>}
      </div>

      <div className={`p-6 rounded-lg shadow-md ${cardBgClass}`}>
        <div className="flex justify-between items-center mb-4">
          <h2 className={`text-2xl font-semibold ${headingColorClass}`}>{translate('applicationHistory')}</h2>
          <Link to="/application/new" onClick={handleNewApplication}>
            <Button variant="primary">
              {translate('newApplication')}
            </Button>
          </Link>
        </div>
        {applications.length > 0 ? (
          applications.map(app => <ApplicationListItem key={app.id} application={app} />)
        ) : (
          <p className={textColorClass}>{translate('noApplicationsFound', 'No applications found. Start a new one!')}</p>
        )}
      </div>

      {questionnaires.length > 0 && (
         <div className={`p-6 rounded-lg shadow-md ${cardBgClass}`}>
          <h2 className={`text-2xl font-semibold ${headingColorClass} mb-4`}>{translate('actions')}</h2>
          {questionnaires.map(q => (
            <div key={q.id} className={`p-4 mb-3 border rounded-md ${questionnaireBorderClass}`}>
              <h3 className={`font-semibold ${headingColorClass}`}>{q.title}</h3>
              <p className={`text-sm ${textColorClass}`}>{translate('deadline', 'Deadline')}: {q.deadline}</p>
              <p className={`text-sm mt-1 ${textColorClass}`}>{q.instructions}</p>
              <Button size="sm" variant="secondary" className="mt-2">{translate('respond')}</Button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default DashboardPage;