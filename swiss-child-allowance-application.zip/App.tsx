
import React, { useEffect } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useAppContext } from './hooks/useAppContext';
import Header from './components/layout/Header';
import PageContainer from './components/layout/PageContainer';
import DashboardPage from './pages/DashboardPage';
import NewApplicationPage from './pages/NewApplicationPage';
// ViewApplicationPage is no longer directly used for this route, NewApplicationPage will handle it.
// import ViewApplicationPage from './pages/ViewApplicationPage'; 
import AdminDashboardPage from './pages/AdminDashboardPage'; 

const App: React.FC = () => {
  const { theme, language } = useAppContext();

  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.className = ''; 
    
    const body = document.body;
    const html = document.documentElement;

    html.classList.remove('theme2-html', 'theme3-html', 'theme4-html');
    body.classList.remove('theme2-body', 'theme3-body', 'theme4-body');

    if (theme === 'theme2') {
      html.classList.add('theme2-html');
      body.classList.add('theme2-body', 'bg-theme2-bg', 'text-theme2-text');
    } else if (theme === 'theme3') {
      html.classList.add('theme3-html');
      body.classList.add('theme3-body', 'bg-theme3-bg', 'text-theme3-text-on-light');
    } else if (theme === 'theme4') {
      html.classList.add('theme4-html');
      body.classList.add('theme4-body', 'bg-theme4-bg', 'text-theme4-text-on-dark');
    }


  }, [theme, language]);

  const { user } = useAppContext();
  const isAdmin = user?.role === 'admin';

  return (
    <HashRouter>
      <div className="flex flex-col min-h-screen">
        <Header />
        <PageContainer>
          <Routes>
            <Route path="/" element={<DashboardPage />} />
            <Route path="/application/new" element={<NewApplicationPage />} />
            <Route path="/application/edit/:id" element={<NewApplicationPage />} /> 
            <Route path="/application/view/:id" element={<NewApplicationPage />} /> {/* Changed to NewApplicationPage */}
            {isAdmin && <Route path="/admin" element={<AdminDashboardPage />} />}
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </PageContainer>
      </div>
    </HashRouter>
  );
};

export default App;