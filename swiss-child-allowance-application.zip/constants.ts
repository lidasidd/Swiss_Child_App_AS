import { SelectOption, MaritalStatus, Gender, RelationshipToApplicant, SpouseEmploymentStatus, LegalParentEmploymentStatus, IncomeComparison, CarerRelationshipType, ApplicationStatus, Notification, NotificationType, UserQuestionnaireStatus } from './types';

export const APP_NAME = "Swiss Child Allowance Portal"; // This could also be a translation key if app name needs to change per language

export const EU_EFTA_FREE_MOVEMENT_COUNTRIES: SelectOption[] = [
  // Labels for countries are typically proper nouns and might have official translations
  // or are kept in their common English form. For this exercise, keeping them as direct labels.
  { value: "Austria", label: "Austria" },
  { value: "Belgium", label: "Belgium" },
  { value: "Bulgaria", label: "Bulgaria" },
  { value: "Croatia", label: "Croatia" },
  { value: "Cyprus", label: "Cyprus" },
  { value: "Czech Republic", label: "Czech Republic" },
  { value: "Denmark", label: "Denmark" },
  { value: "Estonia", label: "Estonia" },
  { value: "Finland", label: "Finland" },
  { value: "France", label: "France" },
  { value: "Germany", label: "Germany" },
  { value: "Great Britain", label: "Great Britain (until 31.12.2020)" },
  { value: "Greece", label: "Greece" },
  { value: "Hungary", label: "Hungary" },
  { value: "Ireland", label: "Ireland" },
  { value: "Italy", label: "Italy" },
  { value: "Latvia", label: "Latvia" },
  { value: "Lithuania", label: "Lithuania" },
  { value: "Luxembourg", label: "Luxembourg" },
  { value: "Malta", label: "Malta" },
  { value: "Netherlands", label: "Netherlands" },
  { value: "Poland", label: "Poland" },
  { value: "Portugal", label: "Portugal" },
  { value: "Romania", label: "Romania" },
  { value: "Slovakia", label: "Slovakia" },
  { value: "Slovenia", label: "Slovenia" },
  { value: "Spain", label: "Spain" },
  { value: "Sweden", label: "Sweden" },
  { value: "Not-in-the-list", labelKey: "countryNotInList" }, // Translatable
];

export const SWISS_CANTONS: SelectOption[] = [
    // Canton names are proper nouns. Kept as direct labels.
    { value: "AG", label: "Aargau (AG)" },
    { value: "AI", label: "Appenzell Innerrhoden (AI)" },
    { value: "AR", label: "Appenzell Ausserrhoden (AR)" },
    { value: "BE", label: "Bern (BE)" },
    { value: "BL", label: "Basel-Landschaft (BL)" },
    { value: "BS", label: "Basel-Stadt (BS)" },
    { value: "FR", label: "Fribourg (FR)" },
    { value: "GE", label: "Geneva (GE)" },
    { value: "GL", label: "Glarus (GL)" },
    { value: "GR", label: "Graubünden (GR)" },
    { value: "JU", label: "Jura (JU)" },
    { value: "LU", label: "Lucerne (LU)" },
    { value: "NE", label: "Neuchâtel (NE)" },
    { value: "NW", label: "Nidwalden (NW)" },
    { value: "OW", label: "Obwalden (OW)" },
    { value: "SG", label: "St. Gallen (SG)" },
    { value: "SH", label: "Schaffhausen (SH)" },
    { value: "SO", label: "Solothurn (SO)" },
    { value: "SZ", label: "Schwyz (SZ)" },
    { value: "TG", label: "Thurgau (TG)" },
    { value: "TI", label: "Ticino (TI)" },
    { value: "UR", label: "Uri (UR)" },
    { value: "VD", label: "Vaud (VD)" },
    { value: "VS", label: "Valais (VS)" },
    { value: "ZG", label: "Zug (ZG)" },
    { value: "ZH", label: "Zürich (ZH)" },
];

export const MARITAL_STATUS_OPTIONS: SelectOption[] = Object.values(MaritalStatus).map(status => ({ value: status, labelKey: `maritalStatus${status.replace(/\s+/g, '')}` }));
export const GENDER_OPTIONS: SelectOption[] = Object.values(Gender).map(gender => ({ value: gender, labelKey: `gender${gender}` }));
export const RELATIONSHIP_OPTIONS: SelectOption[] = Object.values(RelationshipToApplicant).map(rel => ({ value: rel, labelKey: `relationshipToApplicant${rel.replace(/\s+/g, '').replace(/[^a-zA-Z0-9]/g, '')}` }));
export const SPOUSE_EMPLOYMENT_STATUS_OPTIONS: SelectOption[] = Object.values(SpouseEmploymentStatus).map(status => ({ value: status, labelKey: `spouseEmploymentStatus${status.replace(/\s+/g, '').replace(/[^a-zA-Z0-9]/g, '')}` }));
export const LEGAL_PARENT_EMPLOYMENT_OPTIONS: SelectOption[] = Object.values(LegalParentEmploymentStatus).map(status => ({ value: status, labelKey: `legalParentEmploymentStatus${status.replace(/\s+/g, '').replace(/[^a-zA-Z0-9]/g, '')}` }));
export const INCOME_COMPARISON_OPTIONS: SelectOption[] = Object.values(IncomeComparison).map(val => ({value: val, labelKey: `incomeComparison${val}`}));
export const CARER_RELATIONSHIP_OPTIONS: SelectOption[] = Object.values(CarerRelationshipType).map(val => ({value: val, labelKey: `carerRelationshipType${val.replace(/\s+/g, '').replace(/[^a-zA-Z0-9']/g, '')}`}));


export const YES_NO_OPTIONS: SelectOption[] = [
  { value: "yes", labelKey: "optionYes" },
  { value: "no", labelKey: "optionNo" },
];

export const TOTAL_APPLICATION_STEPS = 20; // Reverted: Step 18 (ChildAgeQuery) is back

export const APPLICATION_STATUS_OPTIONS: SelectOption[] = Object.values(ApplicationStatus).map(status => ({
  value: status,
  labelKey: `status${status.replace(/\s+/g, '')}`
}));

export const USER_QUESTIONNAIRE_STATUS_OPTIONS: SelectOption[] = Object.values(UserQuestionnaireStatus).map(status => ({
  value: status,
  labelKey: `userQuestionnaireStatus${status.replace(/\s+/g, '')}`
}));


// Enhanced translations
export const TEXTS = {
  // General UI
  appName: { en: "Swiss Child Allowance Portal", de: "Portal für Kinderzulagen Schweiz", fr: "Portail des allocations familiales Suisse", it: "Portale Assegni Familiari Svizzera" },
  welcome: { en: "Welcome", de: "Willkommen", fr: "Bienvenue", it: "Benvenuto" },
  hrManager: { en: "HR Manager", de: "HR-Manager", fr: "Responsable RH", it: "Manager Risorse Umane" },
  newApplication: { en: "New Application", de: "Neuer Antrag", fr: "Nouvelle Demande", it: "Nuova Domanda" },
  editApplicationTitle: { en: "Edit Child Allowance Application", de: "Antrag auf Kinderzulagen bearbeiten", fr: "Modifier la demande d'allocations familiales", it: "Modifica domanda di assegni familiari"},
  newApplicationTitle: { en: "New Child Allowance Application", de: "Neuer Antrag auf Kinderzulagen", fr: "Nouvelle demande d'allocations familiales", it: "Nuova domanda di assegni familiari"},
  applicationHistory: { en: "Application History", de: "Antragsverlauf", fr: "Historique des Demandes", it: "Storico Domande" },
  actions: { en: "Actions / Questionnaires", de: "Aktionen / Fragebögen", fr: "Actions / Questionnaires", it: "Azioni / Questionari" },
  applicationId: { en: "Application ID", de: "Antrags-ID", fr: "ID de Demande", it: "ID Domanda" },
  childrenNames: { en: "Child(ren)'s Name(s)", de: "Name(n) des Kindes(r)", fr: "Nom(s) de l'enfant/des enfants", it: "Nome/i del/i Figlio/i" },
  status: { en: "Status", de: "Status", fr: "Statut", it: "Stato" },
  submissionDate: { en: "Submission Date", de: "Einreichdatum", fr: "Date de Soumission", it: "Data di Invio" },
  view: { en: "View", de: "Ansehen", fr: "Voir", it: "Visualizza" },
  edit: { en: "Edit", de: "Bearbeiten", fr: "Modifier", it: "Modifica" },
  saveDraft: { en: "Save Draft", de: "Entwurf speichern", fr: "Sauvegarder Brouillon", it: "Salva Bozza" },
  next: { en: "Next", de: "Weiter", fr: "Suivant", it: "Avanti" },
  previous: { en: "Previous", de: "Zurück", fr: "Précédent", it: "Precedente" },
  submit: { en: "Submit Application", de: "Antrag einreichen", fr: "Soumettre la Demande", it: "Invia Domanda" },
  home: { en: "Home", de: "Startseite", fr: "Accueil", it: "Home" },
  areYouSure: { en: "Are you sure?", de: "Sind Sie sicher?", fr: "Êtes-vous sûr?", it: "Sei sicuro?" },
  unsavedChangesLost: { en: "You have unsaved changes that will be lost. Do you want to continue?", de: "Sie haben nicht gespeicherte Änderungen, die verloren gehen. Möchten Sie fortfahren?", fr: "Vous avez des modifications non enregistrées qui seront perdues. Voulez-vous continuer?", it: "Hai modifiche non salvate che andranno perse. Vuoi continuare?"},
  confirm: { en: "Confirm", de: "Bestätigen", fr: "Confirmer", it: "Conferma" },
  cancel: { en: "Cancel", de: "Abbrechen", fr: "Annuler", it: "Annulla" },
  close: {en: "Close", de: "Schließen", fr: "Fermer", it: "Chiudi"},
  exitApplication: { en: "Exit Application", de: "Antrag verlassen", fr: "Quitter la demande", it: "Esci dalla domanda"},
  confirmExitApplication: { en: "Confirm Exit", de: "Verlassen bestätigen", fr: "Confirmer la sortie", it: "Conferma uscita"},
  exitApplicationWarning: { en: "Are you sure you want to exit? Your progress will be saved as a draft if you have started, but it's recommended to use the 'Save Draft' button for explicit saves.", de: "Möchten Sie den Vorgang wirklich beenden? Ihr Fortschritt wird als Entwurf gespeichert, wenn Sie begonnen haben. Es wird jedoch empfohlen, die Schaltfläche 'Entwurf speichern' für explizite Speicherungen zu verwenden.", fr: "Êtes-vous sûr de vouloir quitter? Votre progression sera enregistrée comme brouillon si vous avez commencé, mais il est recommandé d'utiliser le bouton 'Sauvegarder le brouillon' pour des sauvegardes explicites.", it: "Sei sicuro di voler uscire? I tuoi progressi verranno salvati come bozza se hai iniziato, ma si raccomanda di utilizzare il pulsante 'Salva bozza' per salvataggi espliciti."},
  pleaseSelect: { en: "Please select...", de: "Bitte auswählen...", fr: "Veuillez sélectionner...", it: "Seleziona..." },
  loadingApplicationData: { en: "Loading application data...", de: "Lade Antragsdaten...", fr: "Chargement des données de la demande...", it: "Caricamento dati applicazione..." },
  unknownStep: { en: "Unknown step", de: "Unbekannter Schritt", fr: "Étape inconnue", it: "Passo sconosciuto" },
  draftSaved: { en: "Draft saved successfully!", de: "Entwurf erfolgreich gespeichert!", fr: "Brouillon enregistré avec succès!", it: "Bozza salvata con successo!" },
  applicationSubmitted: { en: "Application submitted successfully!", de: "Antrag erfolgreich eingereicht!", fr: "Demande soumise avec succès!", it: "Domanda inviata con successo!" },
  admin: { en: "Admin", de: "Admin", fr: "Admin", it: "Admin" },
  notProvided: { en: "Not Provided", de: "Nicht angegeben", fr: "Non fourni", it: "Non fornito" },
  respond: { en: "Respond", de: "Antworten", fr: "Répondre", it: "Rispondi"},
  noApplicationsFound: { en: "No applications found. Start a new one!", de: "Keine Anträge gefunden. Starten Sie einen neuen!", fr: "Aucune demande trouvée. Commencez-en une nouvelle!", it: "Nessuna domanda trovata. Iniziane una nuova!"},
  na: { en: "N/A", de: "N.V.", fr: "N/A", it: "N.D." }, // Not Applicable
  child: { en: "Child", de: "Kind", fr: "Enfant", it: "Figlio"},
  employer: {en: "Employer", de: "Arbeitgeber", fr: "Employeur", it: "Datore di lavoro"},
  loading: { en: "Loading...", de: "Lädt...", fr: "Chargement...", it: "Caricamento..." },
  step: { en: "Step", de: "Schritt", fr: "Étape", it: "Passo" },
  currentStep: { en: "current step", de: "aktueller Schritt", fr: "étape actuelle", it: "passo attuale" },
  disabledStep: { en: "disabled", de: "deaktiviert", fr: "désactivé", it: "disabilitato" },
  notificationsTitle: { en: "Notifications", de: "Benachrichtigungen", fr: "Notifications", it: "Notifiche" },
  noNotifications: { en: "No new notifications", de: "Keine neuen Benachrichtigungen", fr: "Aucune nouvelle notification", it: "Nessuna nuova notifica" },
  markAllAsRead: { en: "Mark all as read", de: "Alle als gelesen markieren", fr: "Tout marquer comme lu", it: "Segna tutti come letti" },
  notificationNewApplicationAvailable: { en: 'A new application form is available for child allowance.', de: 'Ein neues Antragsformular für Kinderzulagen ist verfügbar.', fr: 'Un nouveau formulaire de demande d\'allocations familiales est disponible.', it: 'È disponibile un nuovo modulo di domanda per gli assegni familiari.' },
  notificationPolicyUpdate: { en: 'Important: Child allowance policy has been updated. Please review.', de: 'Wichtig: Die Kinderzulagenrichtlinie wurde aktualisiert. Bitte überprüfen.', fr: 'Important : La politique des allocations familiales a été mise à jour. Veuillez consulter.', it: 'Importante: la politica sugli assegni familiari è stata aggiornata. Si prega di rivedere.' },
  notificationApplicationApproved: { en: 'Your application #APP-123 has been approved!', de: 'Ihr Antrag #APP-123 wurde genehmigt!', fr: 'Votre demande #APP-123 a été approuvée !', it: 'La tua domanda #APP-123 è stata approvata!' },
  notificationActionRequired: { en: 'Action required on application #APP-456.', de: 'Maßnahme für Antrag #APP-456 erforderlich.', fr: 'Action requise sur la demande #APP-456.', it: 'Azione richiesta sulla domanda #APP-456.' },
  viewApplicationLinkText: { en: 'View Details', de: 'Details anzeigen', fr: 'Voir les détails', it: 'Visualizza dettagli' },
  questionnaireSent: { en: "Questionnaire sent successfully!", de: "Fragebogen erfolgreich gesendet!", fr: "Questionnaire envoyé avec succès !", it: "Questionario inviato con successo!" },
  questionnaireFileName: { en: "Questionnaire File", de: "Fragebogendatei", fr: "Fichier du questionnaire", it: "File del questionario" },
  questionnaireSentTo: { en: "Sent to", de: "Gesendet an", fr: "Envoyé à", it: "Inviato a" },
  questionnaireSentOn: { en: "Sent On", de: "Gesendet am", fr: "Envoyé le", it: "Inviato il" },
  questionnaireCommentsByAdmin: { en: "Admin Comments/Instructions", de: "Admin-Kommentare/Anweisungen", fr: "Commentaires/Instructions de l'administrateur", it: "Commenti/Istruzioni dell'amministratore" },
  noQuestionnairesFound: { en: "No questionnaires found.", de: "Keine Fragebögen gefunden.", fr: "Aucun questionnaire trouvé.", it: "Nessun questionario trovato." },
  respondToQuestionnaire: { en: "Respond to Questionnaire", de: "Auf Fragebogen antworten", fr: "Répondre au questionnaire", it: "Rispondi al questionario" },
  downloadQuestionnaire: { en: "Download Questionnaire", de: "Fragebogen herunterladen", fr: "Télécharger le questionnaire", it: "Scarica questionario" },
  downloadYourResponse: { en: "Download Your Response", de: "Ihre Antwort herunterladen", fr: "Télécharger votre réponse", it: "Scarica la tua risposta" },
  uploadResponseFile: { en: "Upload Your Response File", de: "Ihre Antwortdatei hochladen", fr: "Télécharger votre fichier de réponse", it: "Carica il tuo file di risposta" },
  yourComments: { en: "Your Comments (Optional)", de: "Ihre Kommentare (Optional)", fr: "Vos commentaires (Optionnel)", it: "I tuoi commenti (Opzionale)" },
  submitResponse: { en: "Submit Response", de: "Antwort einreichen", fr: "Soumettre la réponse", it: "Invia risposta" },
  questionnaireResponseSubmitted: { en: "Questionnaire response submitted successfully!", de: "Fragebogenantwort erfolgreich eingereicht!", fr: "Réponse au questionnaire soumise avec succès !", it: "Risposta al questionario inviata con successo!" },
  adminReviewQuestionnaireTitle: { en: "Review Questionnaire Response", de: "Fragebogenantwort überprüfen", fr: "Examiner la réponse au questionnaire", it: "Esamina la risposta al questionario" },
  employeeResponse: { en: "Employee's Response", de: "Antwort des Mitarbeiters", fr: "Réponse de l'employé", it: "Risposta del dipendente" },
  employeeUploadedFile: { en: "Employee's Uploaded File", de: "Hochgeladene Datei des Mitarbeiters", fr: "Fichier téléchargé par l'employé", it: "File caricato dal dipendente" },
  employeeComments: { en: "Employee's Comments", de: "Kommentare des Mitarbeiters", fr: "Commentaires de l'employé", it: "Commenti del dipendente" },
  approveQuestionnaire: { en: "Approve Questionnaire", de: "Fragebogen genehmigen", fr: "Approuver le questionnaire", it: "Approva questionario" },
  rejectQuestionnaire: { en: "Reject Questionnaire", de: "Fragebogen ablehnen", fr: "Rejeter le questionnaire", it: "Respingi questionario" },
  confirmQuestionnaireAction: { en: "Confirm Questionnaire Action", de: "Fragebogenaktion bestätigen", fr: "Confirmer l'action du questionnaire", it: "Conferma azione questionario" },
  commentsForRejection: { en: "Comments for Rejection", de: "Kommentare zur Ablehnung", fr: "Commentaires pour le rejet", it: "Commenti per il rigetto" },
  questionnaireApproved: { en: "Questionnaire Approved", de: "Fragebogen genehmigt", fr: "Questionnaire Approuvé", it: "Questionario Approvato" },
  questionnaireRejected: { en: "Questionnaire Rejected", de: "Fragebogen abgelehnt", fr: "Questionnaire Rejeté", it: "Questionario Respinto" },
  relatedApplication: { en: "Related Application", de: "Zugehöriger Antrag", fr: "Demande associée", it: "Domanda associata" },
  selectRelatedApplication: { en: "Select Related Application (Optional)", de: "Zugehörigen Antrag auswählen (Optional)", fr: "Sélectionner la demande associée (Optionnel)", it: "Seleziona domanda associata (Opzionale)" },
  noApplicableApplications: { en: "No applicable applications for this user.", de: "Keine zutreffenden Anträge für diesen Benutzer.", fr: "Aucune demande applicable pour cet utilisateur.", it: "Nessuna domanda applicabile per questo utente." },
  notificationQuestionnaireReceived: { en: "You have received a new questionnaire from {senderName}.", de: "Sie haben einen neuen Fragebogen von {senderName} erhalten.", fr: "Vous avez reçu un nouveau questionnaire de {senderName}.", it: "Hai ricevuto un nuovo questionario da {senderName}." },
  notificationQuestionnaireResponded: { en: "{employeeName} has responded to questionnaire '{questionnaireTitle}'.", de: "{employeeName} hat auf den Fragebogen '{questionnaireTitle}' geantwortet.", fr: "{employeeName} a répondu au questionnaire '{questionnaireTitle}'.", it: "{employeeName} ha risposto al questionario '{questionnaireTitle}'." },
  notificationQuestionnaireActionTaken: { en: "Your response to questionnaire '{questionnaireTitle}' has been {action}.", de: "Ihre Antwort auf den Fragebogen '{questionnaireTitle}' wurde {action}.", fr: "Votre réponse au questionnaire '{questionnaireTitle}' a été {action}.", it: "La tua risposta al questionario '{questionnaireTitle}' è stata {action}." },
  actionApproved: { en: "approved", de: "genehmigt", fr: "approuvée", it: "approvata" },
  actionRejected: { en: "rejected", de: "abgelehnt", fr: "rejetée", it: "respinta" },
  pleaseSelectEmployeeAndFile: { en: "Please select an employee and upload a questionnaire file.", de: "Bitte wählen Sie einen Mitarbeiter aus und laden Sie eine Fragebogendatei hoch.", fr: "Veuillez sélectionner un employé et télécharger un fichier de questionnaire.", it: "Seleziona un dipendente e carica un file del questionario." },
  pleaseUploadResponseFile: { en: "Please upload your response file.", de: "Bitte laden Sie Ihre Antwortdatei hoch.", fr: "Veuillez télécharger votre fichier de réponse.", it: "Carica il tuo file di risposta." },
  fileNotAvailableForDownload: { en: "File is not available for download.", de: "Datei steht nicht zum Download zur Verfügung.", fr: "Le fichier n'est pas disponible au téléchargement.", it: "Il file non è disponibile per il download." },
  download: { en: "Download", de: "Herunterladen", fr: "Télécharger", it: "Scarica" },
  noResponseSubmittedYet: { en: "No response submitted by employee yet.", de: "Noch keine Antwort vom Mitarbeiter eingereicht.", fr: "Aucune réponse soumise par l'employé pour le moment.", it: "Nessuna risposta ancora inviata dal dipendente." },
  questionnaireIdDisplay: { en: "Questionnaire ID", de: "Fragebogen-ID", fr: "ID du Questionnaire", it: "ID Questionario" },
  questionnaireTitleDisplay: { en: "Title", de: "Titel", fr: "Titre", it: "Titolo" },
  questionnaireStatusDisplay: { en: "Status", de: "Status", fr: "Statut", it: "Stato" },
  questionnaireSentOnDisplay: { en: "Sent On", de: "Gesendet am", fr: "Envoyé le", it: "Inviato il" },
  questionnaireRespondedOnDisplay: { en: "Responded On", de: "Beantwortet am", fr: "Répondu le", it: "Risposto il" },
  questionnaireAdminReviewCommentsDisplay: { en: "Admin Feedback", de: "Admin Feedback", fr: "Feedback de l'admin", it: "Feedback dell'admin"},
  viewDetails: { en: "View Details", de: "Details anzeigen", fr: "Voir les détails", it: "Visualizza Dettagli" },

  // FileUpload component texts
  uploadAFile: { en: "Upload a file", de: "Datei hochladen", fr: "Télécharger un fichier", it: "Carica un file" },
  uploadAFileButton: { en: "Choose File", de: "Datei auswählen", fr: "Choisir Fichier", it: "Scegli File" },
  dragAndDrop: { en: "or drag and drop", de: "oder ziehen und ablegen", fr: "ou glisser-déposer", it: "o trascina e rilascia" },
  dragAndDropHint: { en: "(Optional: you can also drag files here)", de: "(Optional: Sie können Dateien auch hierher ziehen)", fr: "(Optionnel : vous pouvez aussi glisser des fichiers ici)", it: "(Opzionale: puoi anche trascinare i file qui)" },
  fileTypesAndSize: { en: "{types} up to {size}MB", de: "{types} bis zu {size}MB", fr: "{types} jusqu'à {size}Mo", it: "{types} fino a {size}MB" },
  uploadedFilesTitle: { en: "Uploaded files:", de: "Hochgeladene Dateien:", fr: "Fichiers téléchargés:", it: "File caricati:" },
  removeFile: { en: "Remove", de: "Entfernen", fr: "Supprimer", it: "Rimuovi" },
  fileTooLargeError: { en: "{fileName} is too large. Max size is {maxSize}MB.", de: "{fileName} ist zu groß. Max. Größe ist {maxSize}MB.", fr: "{fileName} est trop volumineux. La taille maximale est de {maxSize}Mo.", it: "{fileName} è troppo grande. La dimensione massima è {maxSize}MB." },
  unsupportedFileTypeError: { en: "{fileName} has an unsupported file type. Allowed: {types}.", de: "{fileName} hat einen nicht unterstützten Dateityp. Erlaubt: {types}.", fr: "{fileName} a un type de fichier non pris en charge. Autorisé: {types}.", it: "{fileName} ha un tipo di file non supportato. Consentiti: {types}." },
  
  // Select Options (labelKeys)
  optionYes: { en: "Yes", de: "Ja", fr: "Oui", it: "Sì" },
  optionNo: { en: "No", de: "Nein", fr: "Non", it: "No" },
  countryNotInList: { en: "Not-in-the-list", de: "Nicht in der Liste", fr: "Pas dans la liste", it: "Non in elenco" },
  // Marital Status options
  maritalStatusSingle: { en: "Single", de: "Ledig", fr: "Célibataire", it: "Celibe/Nubile" },
  maritalStatusMarried: { en: "Married", de: "Verheiratet", fr: "Marié(e)", it: "Sposato/a" },
  maritalStatusWidowed: { en: "Widowed", de: "Verwitwet", fr: "Veuf/Veuve", it: "Vedovo/a" },
  maritalStatusSeparated: { en: "Separated", de: "Getrennt", fr: "Séparé(e)", it: "Separato/a" },
  maritalStatusDivorced: { en: "Divorced", de: "Geschieden", fr: "Divorcé(e)", it: "Divorziato/a" },
  // Gender options
  genderMale: { en: "Male", de: "Männlich", fr: "Masculin", it: "Maschio" },
  genderFemale: { en: "Female", de: "Weiblich", fr: "Féminin", it: "Femmina" },
  // RelationshipToApplicant options
  relationshipToApplicantOwnorAdoptedchild: { en: "Own or Adopted child", de: "Eigenes oder adoptiertes Kind", fr: "Enfant propre ou adopté", it: "Figlio proprio o adottato" },
  relationshipToApplicantStepchild: { en: "Stepchild", de: "Stiefkind", fr: "Beau-fils/Belle-fille", it: "Figliastro/a" },
  relationshipToApplicantFosterchild: { en: "Foster child", de: "Pflegekind", fr: "Enfant placé", it: "Figlio in affido" },
  relationshipToApplicantSibling: { en: "Sibling", de: "Geschwister", fr: "Frère/Sœur", it: "Fratello/Sorella" },
  relationshipToApplicantGrandchild: { en: "Grandchild", de: "Enkelkind", fr: "Petit-enfant", it: "Nipote (di nonni)" },
  // SpouseEmploymentStatus options
  spouseEmploymentStatusHousewifeHousehusband: { en: "Housewife/House husband", de: "Hausfrau/Hausmann", fr: "Femme/Homme au foyer", it: "Casalinga/o" },
  spouseEmploymentStatusUnemployed: { en: "Unemployed", de: "Arbeitslos", fr: "Au chômage", it: "Disoccupato/a" },
  spouseEmploymentStatusChildraisingleave: { en: "Child-raising leave", de: "Erziehungsurlaub", fr: "Congé parental", it: "Congedo parentale" },
  spouseEmploymentStatusInvalid: { en: "Invalid", de: "Invalid", fr: "Invalide", it: "Invalido/a" },
  // LegalParentEmploymentStatus options
  legalParentEmploymentStatusEmployed: { en: "Employed", de: "Angestellt", fr: "Employé(e)", it: "Impiegato/a" },
  legalParentEmploymentStatusSelfEmployed: { en: "Self-Employed", de: "Selbstständig", fr: "Indépendant(e)", it: "Lavoratore/trice autonomo/a" },
  legalParentEmploymentStatusNotgainfullyemployed: { en: "Not gainfully employed", de: "Nicht erwerbstätig", fr: "Non salarié(e)", it: "Non occupato/a" },
  // IncomeComparison options
  incomeComparisonHigher: { en: "Higher", de: "Höher", fr: "Plus élevé", it: "Superiore" },
  incomeComparisonLower: { en: "Lower", de: "Niedriger", fr: "Moins élevé", it: "Inferiore" },
  // CarerRelationshipType options
  carerRelationshipTypeFosterparent: { en: "Foster parent", de: "Pflegeelternteil", fr: "Parent d'accueil", it: "Genitore affidatario" },
  carerRelationshipTypeChildscustodian: { en: "Child's custodian", de: "Vormund des Kindes", fr: "Gardien de l'enfant", it: "Tutore del bambino" },
  carerRelationshipTypeGrandparent: { en: "Grandparent", de: "Großelternteil", fr: "Grand-parent", it: "Nonno/a" },
  carerRelationshipTypeSibling: { en: "Sibling", de: "Geschwister", fr: "Frère/Sœur", it: "Fratello/Sorella" },
  carerRelationshipTypeOther: { en: "Other", de: "Andere", fr: "Autre", it: "Altro" },

  // ApplicationStatus for display
  statusDraft: { en: "Draft", de: "Entwurf", fr: "Brouillon", it: "Bozza" },
  statusSubmitted: { en: "Submitted", de: "Eingereicht", fr: "Soumis", it: "Inviata" },
  statusUnderReview: { en: "Under Review", de: "In Prüfung", fr: "En cours d'examen", it: "In revisione" },
  statusPendingEmployeeAction: { en: "Pending Employee Action", de: "Wartet auf Aktion des Mitarbeiters", fr: "En attente d'action de l'employé", it: "In attesa di azione del dipendente" },
  statusQuestionnaireSenttoEmployee: { en: "Questionnaire Sent", de: "Fragebogen gesendet", fr: "Questionnaire envoyé", it: "Questionario inviato" }, // New App Status
  statusQuestionnaireCompleted: { en: "Questionnaire Processed", de: "Fragebogen bearbeitet", fr: "Questionnaire traité", it: "Questionario elaborato" }, // New App Status
  statusCompleted: { en: "Completed", de: "Abgeschlossen", fr: "Terminé", it: "Completata" },
  statusRejected: { en: "Rejected", de: "Abgelehnt", fr: "Rejeté", it: "Respinta" },
  statusPending: { en: "Pending", de: "Ausstehend", fr: "En attente", it: "In attesa" }, // For UserQuestionnaireStatus

  // UserQuestionnaireStatus for display
  userQuestionnaireStatusPendingEmployeeResponse: { en: "Pending Employee Response", de: "Wartet auf Antwort des Mitarbeiters", fr: "En attente de réponse de l'employé", it: "In attesa di risposta del dipendente" },
  userQuestionnaireStatusSubmittedbyEmployee: { en: "Submitted by Employee", de: "Vom Mitarbeiter eingereicht", fr: "Soumis par l'employé", it: "Inviato dal dipendente" },
  userQuestionnaireStatusApprovedbyAdmin: { en: "Approved by Admin", de: "Vom Admin genehmigt", fr: "Approuvé par l'administrateur", it: "Approvato dall'amministratore" },
  userQuestionnaireStatusRejectedbyAdmin: { en: "Rejected by Admin", de: "Vom Admin abgelehnt", fr: "Rejeté par l'administrateur", it: "Respinto dall'amministratore" },


  // Step specific texts - General
  stepProgress: { en: "Step {current} of {total}", de: "Schritt {current} von {total}", fr: "Étape {current} sur {total}", it: "Passo {current} di {total}" },
  confirmAndNext: { en: "Confirm and Next", de: "Bestätigen und Weiter", fr: "Confirmer et Suivant", it: "Conferma e Avanti"},
  countryOfResidence: { en: "Country of Residence", de: "Wohnsitzland", fr: "Pays de résidence", it: "Paese di residenza"},
  selectCountryPlaceholder: { en: "Select your country...", de: "Wählen Sie Ihr Land...", fr: "Sélectionnez votre pays...", it: "Seleziona il tuo paese..."},

  // Step 1: Residency
  step1Title: { en: "Step 1: Residency Confirmation", de: "Schritt 1: Aufenthaltsbestätigung", fr: "Étape 1: Confirmation de résidence", it: "Passo 1: Conferma di residenza"},
  step1Instruction: { en: "Are you living in one of the following countries (Free Movement Agreement with Switzerland)?", de: "Wohnen Sie in einem der folgenden Länder (Freizügigkeitsabkommen mit der Schweiz)?", fr: "Vivez-vous dans l'un des pays suivants (Accord sur la libre circulation avec la Suisse)?", it: "Vivi in uno dei seguenti paesi (Accordo di libera circolazione con la Svizzera)?" },
  step1NotEligible: { en: "Unfortunately, you are not entitled to child benefits in Switzerland and you cannot apply for child benefits. Please contact your HR manager for further details.", de: "Leider haben Sie keinen Anspruch auf Kinderzulagen in der Schweiz und können keine Kinderzulagen beantragen. Bitte wenden Sie sich für weitere Einzelheiten an Ihren HR-Manager.", fr: "Malheureusement, vous n'avez pas droit aux allocations familiales en Suisse et vous ne pouvez pas en faire la demande. Veuillez contacter votre responsable RH pour plus de détails.", it: "Purtroppo non hai diritto agli assegni familiari in Svizzera e non puoi richiederli. Si prega di contattare il proprio responsabile delle risorse umane per ulteriori dettagli." },
  eligibilityCheck: { en: "Eligibility Check", de: "Anspruchsprüfung", fr: "Vérification d'éligibilité", it: "Verifica dell'idoneità"},
  selectCountryError: { en: "Please select your country of residence.", de: "Bitte wählen Sie Ihr Wohnsitzland aus.", fr: "Veuillez sélectionner votre pays de résidence.", it: "Seleziona il tuo paese di residenza."},
  
  // Step 2: Employee Confirmation
  step2Title: { en: "Step 2: Confirm Your Details", de: "Schritt 2: Bestätigen Sie Ihre Angaben", fr: "Étape 2: Confirmez vos coordonnées", it: "Passo 2: Conferma i tuoi dati"},
  step2InstructionEditable: { en: "Please review and update the following information pre-filled from our HR system. If any core information (like your legal name or date of birth) is incorrect, please also inform your HR manager to update it in SuccessFactors.", de: "Bitte überprüfen und aktualisieren Sie die folgenden Informationen, die aus unserem HR-System vorab ausgefüllt wurden. Wenn Kerninformationen (wie Ihr gesetzlicher Name oder Ihr Geburtsdatum) falsch sind, informieren Sie bitte auch Ihren HR-Manager, um diese in SuccessFactors zu aktualisieren.", fr: "Veuillez examiner et mettre à jour les informations suivantes pré-remplies à partir de notre système RH. Si des informations essentielles (comme votre nom légal ou date de naissance) sont incorrectes, veuillez également en informer votre responsable RH pour les mettre à jour dans SuccessFactors.", it: "Si prega di rivedere e aggiornare le seguenti informazioni precompilate dal nostro sistema HR. Se informazioni fondamentali (come il nome legale o la data di nascita) non sono corrette, si prega di informare anche il proprio responsabile HR per aggiornarle in SuccessFactors."},
  firstName: { en: "First Name", de: "Vorname", fr: "Prénom", it: "Nome"},
  lastName: { en: "Last Name", de: "Nachname", fr: "Nom de famille", it: "Cognome"},
  dateOfBirth: { en: "Date Of Birth", de: "Geburtsdatum", fr: "Date de naissance", it: "Data di nascita"},
  employeeId: { en: "Employee ID", de: "Mitarbeiter-ID", fr: "ID employé", it: "ID Dipendente"},
  ahvNumber: { en: "AHV Number", de: "AHV-Nummer", fr: "Numéro AVS", it: "Numero AVS"},
  companyName: { en: "Company Name (Viking Contract)", de: "Firmenname (Viking-Vertrag)", fr: "Nom de l'entreprise (Contrat Viking)", it: "Nome azienda (Contratto Viking)"},
  contractStartDate: { en: "Contract Start Date", de: "Vertragsbeginn", fr: "Date de début du contrat", it: "Data inizio contratto"},
  contractEndDate: { en: "Contract End Date", de: "Vertragsende", fr: "Date de fin du contrat", it: "Data fine contratto"},
  loadingSfData: { en: "Loading employee data...", de: "Lade Mitarbeiterdaten...", fr: "Chargement des données de l'employé...", it: "Caricamento dati dipendente..."},
  
  // Step 3: Prior Application in Residence Country
  step3Title: { en: "Step 3: Prior Application in Residence Country", de: "Schritt 3: Vorheriger Antrag im Wohnsitzland", fr: "Étape 3: Demande préalable dans le pays de résidence", it: "Passo 3: Domanda preliminare nel paese di residenza" },
  step3Question: { en: "Did you apply in your country of residence for child allowances?", de: "Haben Sie in Ihrem Wohnsitzland Kinderzulagen beantragt?", fr: "Avez-vous demandé des allocations familiales dans votre pays de résidence?", it: "Hai richiesto gli assegni familiari nel tuo paese di residenza?" },
  step3ApplyFirstMessage: { en: "Please first apply in your country of residence for child allowances. Your request can only be processed by the compensation office if you have a valid application or rejection. After that, please start this application again.", de: "Bitte beantragen Sie zuerst Kinderzulagen in Ihrem Wohnsitzland. Ihr Antrag kann von der Ausgleichskasse nur bearbeitet werden, wenn Ihnen ein gültiger Antrag oder eine Ablehnung vorliegt. Starten Sie diesen Antrag danach erneut.", fr: "Veuillez d'abord faire une demande d'allocations familiales dans votre pays de résidence. Votre demande ne pourra être traitée par la caisse de compensation que si vous disposez d'une demande ou d'un refus valable. Ensuite, veuillez recommencer cette demande.", it: "Si prega di richiedere prima gli assegni familiari nel proprio paese di residenza. La sua richiesta potrà essere elaborata dall'ufficio di compensazione solo se in possesso di una domanda o di un rigetto validi. Successivamente, si prega di avviare nuovamente questa applicazione." },
  applicationRequirementTitle: { en: "Application Requirement", de: "Antragsvoraussetzung", fr: "Exigence de la demande", it: "Requisito della domanda"},

  // Step 4: Personal Details
  step4Title: { en: "Step 4: Your Personal Details", de: "Schritt 4: Ihre persönlichen Daten", fr: "Étape 4: Vos coordonnées personnelles", it: "Passo 4: I tuoi dati personali"},
  step4Instruction: { en: "Please provide your current address and marital status information.", de: "Bitte geben Sie Ihre aktuelle Adresse und Informationen zum Familienstand an.", fr: "Veuillez fournir votre adresse actuelle et les informations sur votre état civil.", it: "Fornisci il tuo indirizzo attuale e le informazioni sullo stato civile."},
  addressStreet: { en: "Street", de: "Straße", fr: "Rue", it: "Via"},
  helpStreet: { en: "e.g., Bahnhofstrasse", de: "z.B. Bahnhofstrasse", fr: "ex: Rue de la Gare", it: "es: Via Roma"},
  addressStreetNo: { en: "Street No.", de: "Hausnr.", fr: "N° de rue", it: "N. civico"},
  helpStreetNo: { en: "e.g., 10A", de: "z.B. 10A", fr: "ex: 10A", it: "es: 10A"},
  addressPostCode: { en: "Post Code", de: "PLZ", fr: "Code postal", it: "CAP"},
  helpPostCode: { en: "e.g., 8001", de: "z.B. 8001", fr: "ex: 75001", it: "es: 00100"},
  addressTown: { en: "Town", de: "Ort", fr: "Ville", it: "Città (Comune)"},
  helpTown: { en: "e.g., Zürich", de: "z.B. Zürich", fr: "ex: Paris", it: "es: Roma"},
  addressCity: { en: "City (if different from Town/Canton)", de: "Stadt (falls abweichend von Ort/Kanton)", fr: "Grande ville (si différent de Ville/Canton)", it: "Città (se diversa da Comune/Cantone)"},
  helpCity: { en: "e.g., Zürich (if Town is a smaller locality within)", de: "z.B. Zürich (falls Ort eine kleinere Ortschaft darin ist)", fr: "ex: Paris (si Ville est une localité plus petite à l'intérieur)", it: "es: Roma (se Comune è una località più piccola all'interno)"},
  telephone: { en: "Telephone", de: "Telefon", fr: "Téléphone", it: "Telefono"},
  helpTelephone: { en: "e.g., +41 79 123 45 67", de: "z.B. +41 79 123 45 67", fr: "ex: +33 6 12 34 56 78", it: "es: +39 333 1234567"},
  email: { en: "Email Address", de: "E-Mail-Adresse", fr: "Adresse e-mail", it: "Indirizzo email"},
  helpEmail: { en: "e.g., your.name@example.com", de: "z.B. dein.name@beispiel.com", fr: "ex: votre.nom@exemple.com", it: "es: tuo.nome@esempio.com"},
  maritalStatus: { en: "Marital Status", de: "Familienstand", fr: "État civil", it: "Stato civile"},
  selectMaritalStatus: { en: "Select marital status...", de: "Familienstand auswählen...", fr: "Sélectionnez l'état civil...", it: "Seleziona stato civile..."},
  helpMaritalStatus: { en: "Select your current marital status.", de: "Wählen Sie Ihren aktuellen Familienstand.", fr: "Sélectionnez votre état civil actuel.", it: "Seleziona il tuo stato civile attuale."},
  maritalStatusSince: { en: "Marital Status Since", de: "Familienstand seit", fr: "État civil depuis", it: "Stato civile dal"},
  helpMaritalStatusSince: { en: "Date (YYYY-MM-DD). Not required if 'Single'.", de: "Datum (JJJJ-MM-TT). Nicht erforderlich bei 'Ledig'.", fr: "Date (AAAA-MM-JJ). Non requis si 'Célibataire'.", it: "Data (AAAA-MM-GG). Non richiesto se 'Celibe/Nubile'."},

  // Step 5: Other Employers Query
  step5Title: { en: "Step 5: Other Employers", de: "Schritt 5: Andere Arbeitgeber", fr: "Étape 5: Autres employeurs", it: "Passo 5: Altri datori di lavoro"},
  step5Question: { en: "Are you working for other employers?", de: "Sind Sie für andere Arbeitgeber tätig?", fr: "Travaillez-vous pour d'autres employeurs?", it: "Lavori per altri datori di lavoro?"},

  // Step 6: Other Employer Details
  step6Title: { en: "Step 6: Other Employer Details", de: "Schritt 6: Details zu anderen Arbeitgebern", fr: "Étape 6: Détails des autres employeurs", it: "Passo 6: Dettagli di altri datori di lavoro"},
  step6Instruction: { en: "Please add information about your other employer(s).", de: "Bitte fügen Sie Informationen zu Ihrem/Ihren anderen Arbeitgeber(n) hinzu.", fr: "Veuillez ajouter des informations sur votre/vos autre(s) employeur(s).", it: "Aggiungi informazioni sull'altro/i datore/i di lavoro."},
  employerName: { en: "Name of Employer", de: "Name des Arbeitgebers", fr: "Nom de l'employeur", it: "Nome del datore di lavoro"},
  employerAddress: { en: "Address of Employer", de: "Adresse des Arbeitgebers", fr: "Adresse de l'employeur", it: "Indirizzo del datore di lavoro"},
  incomeAtOtherEmployer: { en: "Is the income at the other employer higher than the one at Viking?", de: "Ist das Einkommen beim anderen Arbeitgeber höher als bei Viking?", fr: "Le revenu chez l'autre employeur est-il plus élevé que celui chez Viking?", it: "Il reddito presso l'altro datore di lavoro è superiore a quello presso Viking?"},
  addAnotherEmployer: { en: "+ Add Another Employer", de: "+ Weiteren Arbeitgeber hinzufügen", fr: "+ Ajouter un autre employeur", it: "+ Aggiungi un altro datore di lavoro"},
  removeEmployer: { en: "Remove", de: "Entfernen", fr: "Supprimer", it: "Rimuovi"},
  highestSalaryRule: { en: "You are only allowed to apply for Child Allowance at the employer where your salary is the highest.", de: "Kinderzulagen dürfen Sie nur bei dem Arbeitgeber beantragen, bei dem Ihr Gehalt am höchsten ist.", fr: "Vous n'êtes autorisé à demander des allocations familiales qu'auprès de l'employeur où votre salaire est le plus élevé.", it: "Puoi richiedere gli assegni familiari solo presso il datore di lavoro presso cui il tuo stipendio è più alto."},
  importantNotice: { en: "Important Notice", de: "Wichtiger Hinweis", fr: "Avis Important", it: "Avviso Importante"},
  
  // Step 7: Employee Cash Benefits
  step7Title: {en: "Step 7: Employee Cash Benefits", de: "Schritt 7: Geldleistungen Arbeitnehmer", fr: "Étape 7: Prestations en espèces de l'employé", it: "Passo 7: Prestazioni in denaro per i dipendenti"},
  step7Question: {en: "Are you receiving daily cash benefits from any insurance in Switzerland (invalidity, unemployment, accident, maternity etc.)?", de: "Beziehen Sie Taggelder von einer Versicherung in der Schweiz (Invalidität, Arbeitslosigkeit, Unfall, Mutterschaft etc.)?", fr: "Percevez-vous des indemnités journalières d'une assurance en Suisse (invalidité, chômage, accident, maternité, etc.)?", it: "Ricevi indennità giornaliere in denaro da un'assicurazione in Svizzera (invalidità, disoccupazione, infortunio, maternità ecc.)?"},
  benefitType: {en: "Type of Benefit", de: "Art der Leistung", fr: "Type de prestation", it: "Tipo di prestazione"},
  benefitReceivedSince: {en: "Benefit Received Since", de: "Leistung erhalten seit", fr: "Prestation reçue depuis", it: "Prestazione ricevuta dal"},
  paymentOffice: {en: "Payment Office", de: "Zahlstelle", fr: "Office de paiement", it: "Ufficio pagamenti"},

  // Step 8: Spouse/Partner Details
  step8Title: {en: "Step 8: Spouse/Partner Details", de: "Schritt 8: Angaben zum Ehepartner/Partner", fr: "Étape 8: Détails du conjoint/partenaire", it: "Passo 8: Dettagli del coniuge/partner"},
  step8Instruction: {en: "Details of Spouse, Registered Partner or Life Companion who lives in the same household.", de: "Angaben zum Ehegatten, eingetragenen Partner oder Lebenspartner, der im selben Haushalt lebt.", fr: "Détails du conjoint, du partenaire enregistré ou du compagnon de vie qui vit dans le même ménage.", it: "Dettagli del coniuge, partner registrato o compagno di vita che vive nello stesso nucleo familiare."},
  spouseLastName: {en: "Last Name", de: "Nachname", fr: "Nom de famille", it: "Cognome"},
  spouseFirstName: {en: "First Name", de: "Vorname", fr: "Prénom", it: "Nome"},
  spouseDateOfBirth: {en: "Date of Birth", de: "Geburtsdatum", fr: "Date de naissance", it: "Data di nascita"},
  spousePersonalId: {en: "Personal Identification Number (CH AHV or Home Country ID)", de: "Personenidentifikationsnummer (CH AHV oder ID des Heimatlandes)", fr: "Numéro d'identification personnel (AVS CH ou ID du pays d'origine)", it: "Numero di identificazione personale (AVS CH o ID del paese di origine)"},
  spouseMaritalStatus: {en: "Marital Status of Spouse/Partner", de: "Zivilstand des Ehepartners/Partners", fr: "État civil du conjoint/partenaire", it: "Stato civile del coniuge/partner"},

  // Step 9: Spouse/Partner Employment
  step9Title: {en: "Step 9: Spouse/Partner Employment", de: "Schritt 9: Erwerbstätigkeit Ehepartner/Partner", fr: "Étape 9: Emploi du conjoint/partenaire", it: "Passo 9: Occupazione del coniuge/partner"},
  step9Question: {en: "Is this person gainfully employed?", de: "Ist diese Person erwerbstätig?", fr: "Cette personne exerce-t-elle une activité lucrative?", it: "Questa persona è regolarmente assunta?"},
  spouseEmploymentStatusLabel: {en: "If not gainfully employed, please select status:", de: "Falls nicht erwerbstätig, bitte Status auswählen:", fr: "Si non lucrativement employé, veuillez sélectionner le statut:", it: "Se non regolarmente assunto, selezionare lo stato:"},

  // Step 10: Spouse/Partner Cash Benefits Query
  step10Title: {en: "Step 10: Spouse/Partner Cash Benefits", de: "Schritt 10: Geldleistungen Ehepartner/Partner", fr: "Étape 10: Prestations en espèces du conjoint/partenaire", it: "Passo 10: Prestazioni in denaro del coniuge/partner"},
  step10Question: {en: "Is the person mentioned above receiving daily cash benefits from any insurance (invalidity, unemployment, accident, maternity etc.)?", de: "Bezieht die oben genannte Person Taggelder von einer Versicherung (Invalidität, Arbeitslosigkeit, Unfall, Mutterschaft etc.)?", fr: "La personne mentionnée ci-dessus perçoit-elle des indemnités journalières d'une assurance (invalidité, chômage, accident, maternité, etc.)?", it: "La persona sopra menzionata riceve indennità giornaliere in denaro da un'assicurazione (invalidità, disoccupazione, infortunio, maternità ecc.)?"},

  // Step 11: Spouse/Partner Benefit Details
  step11Title: {en: "Step 11: Spouse/Partner Benefit Details", de: "Schritt 11: Details zu Leistungen des Ehepartners/Partners", fr: "Étape 11: Détails des prestations du conjoint/partenaire", it: "Passo 11: Dettagli delle prestazioni del coniuge/partner"},
  step11Instruction: {en: "Please provide details of the benefits received by your spouse/partner.", de: "Bitte geben Sie Details zu den von Ihrem Ehepartner/Partner erhaltenen Leistungen an.", fr: "Veuillez fournir les détails des prestations reçues par votre conjoint/partenaire.", it: "Fornisci i dettagli delle prestazioni ricevute dal tuo coniuge/partner."},

  // Step 12: Spouse/Partner Employer Details
  step12Title: {en: "Step 12: Spouse/Partner Employer Details", de: "Schritt 12: Details zum Arbeitgeber des Ehepartners/Partners", fr: "Étape 12: Détails de l'employeur du conjoint/partenaire", it: "Passo 12: Dettagli del datore di lavoro del coniuge/partner"},
  step12Instruction: {en: "Please provide employment details for your spouse/partner.", de: "Bitte geben Sie die Beschäftigungsdetails Ihres Ehepartners/Partners an.", fr: "Veuillez fournir les détails d'emploi de votre conjoint/partenaire.", it: "Fornisci i dettagli sull'impiego del tuo coniuge/partner."},
  spouseEmployerName: {en: "Name of Employer", de: "Name des Arbeitgebers", fr: "Nom de l'employeur", it: "Nome del datore di lavoro"},
  spouseEmployerAddress: {en: "Address of Employer", de: "Adresse des Arbeitgebers", fr: "Adresse de l'employeur", it: "Indirizzo del datore di lavoro"},
  spouseEmployerCantonCountry: {en: "Canton/Country of Employment", de: "Kanton/Land der Beschäftigung", fr: "Canton/Pays d'emploi", it: "Cantone/Paese di impiego"},
  spouseEmploymentExtent: {en: "Extent of employment (1-100%)", de: "Beschäftigungsumfang (1-100%)", fr: "Degré d'occupation (1-100%)", it: "Percentuale di impiego (1-100%)"},
  spouseEmploymentExtentHelp: {en: "Enter a number between 1 and 100.", de: "Geben Sie eine Zahl zwischen 1 und 100 ein.", fr: "Entrez un nombre entre 1 et 100.", it: "Inserisci un numero tra 1 e 100."},
  spouseIncomeComparison: {en: "Is the income of your spouse/partner higher or lower than yours?", de: "Ist das Einkommen Ihres Ehepartners/Partners höher oder niedriger als Ihres?", fr: "Le revenu de votre conjoint/partenaire est-il supérieur ou inférieur au vôtre?", it: "Il reddito del tuo coniuge/partner è superiore o inferiore al tuo?"},

  // Step 13: Children Details
  step13Title: { en: "Step 13: Children Details", de: "Schritt 13: Angaben zu den Kindern", fr: "Étape 13: Détails des enfants", it: "Passo 13: Dettagli dei figli"},
  step13Instruction: { en: "Please provide details for all your children for whom you are applying for allowance. Click \"Add Child\" for each child.", de: "Bitte geben Sie die Daten für alle Ihre Kinder an, für die Sie eine Zulage beantragen. Klicken Sie für jedes Kind auf \"Kind hinzufügen\".", fr: "Veuillez fournir les détails de tous vos enfants pour lesquels vous demandez une allocation. Cliquez sur \"Ajouter un enfant\" pour chaque enfant.", it: "Fornisci i dettagli per tutti i tuoi figli per i quali stai richiedendo l'assegno. Fai clic su \"Aggiungi figlio\" per ogni figlio."},
  addChildButton: { en: "+ Add Child", de: "+ Kind hinzufügen", fr: "+ Ajouter un enfant", it: "+ Aggiungi figlio"},
  gender: { en: "Gender", de: "Geschlecht", fr: "Sexe", it: "Sesso"},
  address: { en: "Address (Street, No, Postcode, Town)", de: "Adresse (Straße, Nr, PLZ, Ort)", fr: "Adresse (Rue, N°, Code postal, Ville)", it: "Indirizzo (Via, N., CAP, Città)"},
  childAddressHelp: { en: "Full address of the child.", de: "Vollständige Adresse des Kindes.", fr: "Adresse complète de l'enfant.", it: "Indirizzo completo del bambino."},
  placeOfResidence: { en: "Place of Residence (City, Country)", de: "Wohnort (Stadt, Land)", fr: "Lieu de résidence (Ville, Pays)", it: "Luogo di residenza (Città, Nazione)"},
  childPlaceHelp: { en: "City and country where the child lives.", de: "Stadt und Land, in dem das Kind lebt.", fr: "Ville et pays où vit l'enfant.", it: "Città e nazione in cui vive il bambino."},
  relationshipToApplicant: { en: "Relationship to Applicant", de: "Beziehung zum Antragsteller", fr: "Relation avec le demandeur", it: "Relazione con il richiedente"},
  allChildrenEnteredQuery: { en: "Have you entered all children related to you?", de: "Haben Sie alle mit Ihnen verwandten Kinder eingegeben?", fr: "Avez-vous inscrit tous les enfants qui vous sont liés?", it: "Hai inserito tutti i figli a te collegati?"},

  // Step 14: Legal Parent Details
  step14Title: {en: "Step 14: Legal Parent Details (if different)", de: "Schritt 14: Angaben zum gesetzlichen Elternteil (falls abweichend)", fr: "Étape 14: Détails du parent légal (si différent)", it: "Passo 14: Dettagli del genitore legale (se diverso)"},
  step14Question: {en: "Are the details of the child's other legal parent different from the spouse/partner mentioned in Section 3 (e.g., natural parent of a stepchild or former partner who is the biological parent)?", de: "Weichen die Angaben zum anderen gesetzlichen Elternteil des Kindes von dem in Abschnitt 3 genannten Ehepartner/Partner ab (z.B. leiblicher Elternteil eines Stiefkindes oder früherer Partner, der der biologische Elternteil ist)?", fr: "Les détails de l'autre parent légal de l'enfant sont-ils différents de ceux du conjoint/partenaire mentionné à la section 3 (par exemple, parent naturel d'un beau-fils ou ex-partenaire qui est le parent biologique)?", it: "I dettagli dell'altro genitore legale del bambino sono diversi da quelli del coniuge/partner menzionato nella Sezione 3 (ad es. genitore naturale di un figliastro o ex partner che è il genitore biologico)?"},
  legalParentAppliesToWhichChildren: {en: "To which child(ren) do these details apply?", de: "Für welches Kind/welche Kinder gelten diese Angaben?", fr: "À quel(s) enfant(s) ces détails s'appliquent-ils?", it: "A quale/i bambino/i si applicano questi dettagli?"},
  allChildren: {en: "All children", de: "Alle Kinder", fr: "Tous les enfants", it: "Tutti i bambini"},
  selectChildren: {en: "Select specific child(ren)", de: "Bestimmte(s) Kind(er) auswählen", fr: "Sélectionner un/des enfant(s) spécifique(s)", it: "Seleziona bambino/i specifico/i"},
  selectApplicableChildren: { en: "Select applicable children:", de: "Zutreffende Kinder auswählen:", fr: "Sélectionnez les enfants concernés:", it: "Seleziona i figli interessati:"},
  legalParentLastName: {en: "Last Name", de: "Nachname", fr: "Nom de famille", it: "Cognome"},
  legalParentFirstName: {en: "First Name", de: "Vorname", fr: "Prénom", it: "Nome"},
  legalParentDob: {en: "Date of Birth", de: "Geburtsdatum", fr: "Date de naissance", it: "Data di nascita"},
  legalParentMaritalStatus: {en: "Marital Status", de: "Zivilstand", fr: "État civil", it: "Stato civile"},
  legalParentAddress: {en: "Address", de: "Adresse", fr: "Adresse", it: "Indirizzo"},
  legalParentTelephone: {en: "Telephone", de: "Telefon", fr: "Téléphone", it: "Telefono"},
  legalParentEmploymentDetail: {en: "Employment Detail", de: "Beschäftigungsdetail", fr: "Détail de l'emploi", it: "Dettaglio impiego"},
  legalParentEmployerNameHelpText: { en: "Name of employer", de: "Name des Arbeitgebers", fr: "Nom de l'employeur", it: "Nome del datore di lavoro"},
  legalParentEmployerAddressHelpText: { en: "Address of employer", de: "Adresse des Arbeitgebers", fr: "Adresse de l'employeur", it: "Indirizzo del datore di lavoro"},
  legalParentEmployerNameAddress: {en: "Name and address of employer", de: "Name und Adresse des Arbeitgebers", fr: "Nom et adresse de l'employeur", it: "Nome e indirizzo del datore di lavoro"},
  legalParentEmployerCantonCountry: {en: "Canton/Country of employment", de: "Kanton/Land der Beschäftigung", fr: "Canton/Pays d'emploi", it: "Cantone/Paese di impiego"},
  legalParentSelfEmployedCantonCountry: {en: "Canton/Country of self-employment", de: "Kanton/Land der Selbstständigkeit", fr: "Canton/Pays de travail indépendant", it: "Cantone/Paese di lavoro autonomo"},

  // Step 15: Child Carer Query
  step15Title: {en: "Step 15: Child's Carer Information", de: "Schritt 15: Angaben zur Betreuungsperson des Kindes", fr: "Étape 15: Informations sur la personne qui s'occupe de l'enfant", it: "Passo 15: Informazioni sulla persona che si prende cura del bambino"},
  step15Question: {en: "If both parents are working abroad OR you are the only legal parent AND your child is in the care of another person (e.g., foster parent, grandparent, sibling), please complete the details below.", de: "Wenn beide Elternteile im Ausland arbeiten ODER Sie der alleinige gesetzliche Elternteil sind UND Ihr Kind von einer anderen Person betreut wird (z.B. Pflegeeltern, Großeltern, Geschwister), füllen Sie bitte die folgenden Angaben aus.", fr: "Si les deux parents travaillent à l'étranger OU si vous êtes le seul parent légal ET que votre enfant est confié à une autre personne (par exemple, parent d'accueil, grand-parent, frère/sœur), veuillez compléter les détails ci-dessous.", it: "Se entrambi i genitori lavorano all'estero OPPURE sei l'unico genitore legale E tuo figlio è affidato a un'altra persona (ad es. genitore affidatario, nonno, fratello/sorella), completa i dettagli di seguito."},
  step15HelpText: {en: "Complete if child is cared for by someone other than parents, and specific conditions apply.", de: "Ausfüllen, wenn das Kind von einer anderen Person als den Eltern betreut wird und besondere Bedingungen gelten.", fr: "À compléter si l'enfant est gardé par une personne autre que les parents et que des conditions spécifiques s'appliquent.", it: "Completare se il bambino è accudito da una persona diversa dai genitori e si applicano condizioni specifiche."},

  // Step 16: Carer Details
  step16Title: {en: "Step 16: Carer Details", de: "Schritt 16: Angaben zur Betreuungsperson", fr: "Étape 16: Détails de la personne responsable", it: "Passo 16: Dettagli della persona responsabile"},
  step16Instruction: {en: "Please provide details of the person with whom the child lives.", de: "Bitte machen Sie Angaben zu der Person, bei der das Kind lebt.", fr: "Veuillez fournir les détails de la personne avec qui l'enfant vit.", it: "Fornisci i dettagli della persona con cui vive il bambino."},
  carerAppliesToWhichChildren: {en: "To which child(ren) do these carer details apply?", de: "Für welches Kind/welche Kinder gelten diese Angaben zur Betreuungsperson?", fr: "À quel(s) enfant(s) ces détails de garde s'appliquent-ils?", it: "A quale/i bambino/i si applicano questi dettagli sulla persona che si prende cura?"},
  carerLastName: {en: "Last Name of Carer", de: "Nachname der Betreuungsperson", fr: "Nom de famille du responsable", it: "Cognome della persona responsabile"},
  carerFirstName: {en: "First Name of Carer", de: "Vorname der Betreuungsperson", fr: "Prénom du responsable", it: "Nome della persona responsabile"},
  carerTelephone: {en: "Telephone of Carer", de: "Telefon der Betreuungsperson", fr: "Téléphone du responsable", it: "Telefono della persona responsabile"},
  carerRelationship: {en: "Relationship to Child", de: "Beziehung zum Kind", fr: "Relation avec l'enfant", it: "Relazione con il bambino"},
  carerRelationshipOther: {en: "If 'Other', please specify", de: "Wenn 'Andere', bitte angeben", fr: "Si 'Autre', veuillez préciser", it: "Se 'Altro', specificare"},

  // Step 17: Previous Swiss Child Allowances
  step17Title: {en: "Step 17: Previous Swiss Child Allowances", de: "Schritt 17: Frühere Kinderzulagen Schweiz", fr: "Étape 17: Allocations familiales suisses antérieures", it: "Passo 17: Precedenti assegni familiari svizzeri"},
  step17Question: {en: "Have you ever received child allowances in Switzerland?", de: "Haben Sie jemals Kinderzulagen in der Schweiz erhalten?", fr: "Avez-vous déjà reçu des allocations familiales en Suisse?", it: "Hai mai ricevuto assegni familiari in Svizzera?"},
  whichCanton: {en: "Which canton?", de: "Welcher Kanton?", fr: "Quel canton?", it: "Quale cantone?"},
  selectCanton: { en: "Select canton...", de: "Kanton auswählen...", fr: "Sélectionnez le canton...", it: "Seleziona cantone..."},
  untilWhen: {en: "Until when?", de: "Bis wann?", fr: "Jusqu'à quand?", it: "Fino a quando?"},

  // Step 18: Child Age Query (Restored)
  step18Title: { en: "Step 18: Child Age Confirmation (>15)", de: "Schritt 18: Altersbestätigung Kind (>15)", fr: "Étape 18: Confirmation de l'âge de l'enfant (>15 ans)", it: "Passo 18: Conferma età figlio (>15 anni)" },
  step18Question: { en: "Is your child (or any of your children) older than 15 years and in education/training?", de: "Ist Ihr Kind (oder eines Ihrer Kinder) älter als 15 Jahre und in Ausbildung?", fr: "Votre enfant (ou l'un de vos enfants) a-t-il plus de 15 ans et est-il en formation?", it: "Tuo figlio (o uno dei tuoi figli) ha più di 15 anni ed è in formazione?" },
  step18Info: { en: "If yes, you will be required to upload a confirmation of education/training in the next step.", de: "Wenn ja, müssen Sie im nächsten Schritt eine Ausbildungsbestätigung hochladen.", fr: "Si oui, vous devrez télécharger une attestation de formation à l'étape suivante.", it: "Se sì, ti verrà richiesto di caricare una conferma di istruzione/formazione nel passaggio successivo." },
  childOver15Warning: { en: "Warning: You indicated 'No', but system data suggests at least one child is over 15. Please verify. Education confirmation will be required if applicable.", de: "Warnung: Sie haben 'Nein' angegeben, aber Systemdaten deuten darauf hin, dass mindestens ein Kind über 15 ist. Bitte überprüfen Sie dies. Eine Ausbildungsbestätigung ist ggf. erforderlich.", fr: "Avertissement : Vous avez indiqué 'Non', mais les données du système suggèrent qu'au moins un enfant a plus de 15 ans. Veuillez vérifier. Une attestation de formation sera requise le cas échéant.", it: "Attenzione: Hai indicato 'No', ma i dati di sistema suggeriscono che almeno un figlio ha più di 15 anni. Si prega di verificare. Sarà richiesta una conferma dell'istruzione, se applicabile." },


  // Step 19 (formerly 19/20): Document Upload
  documentUploadTitle: { en: "Step 19: Document Upload", de: "Schritt 19: Dokumentenupload", fr: "Étape 19: Téléchargement de documents", it: "Passo 19: Caricamento documenti"},
  documentUploadInstruction: { en: "Please upload the required documents. Ensure files are clear and legible. Accepted formats: PDF, JPG, PNG. Max 5MB per file.", de: "Bitte laden Sie die erforderlichen Dokumente hoch. Stellen Sie sicher, dass die Dateien klar und leserlich sind. Akzeptierte Formate: PDF, JPG, PNG. Max. 5MB pro Datei.", fr: "Veuillez télécharger les documents requis. Assurez-vous que les fichiers sont clairs et lisibles. Formats acceptés: PDF, JPG, PNG. Max 5Mo par fichier.", it: "Carica i documenti richiesti. Assicurati che i file siano chiari e leggibili. Formati accettati: PDF, JPG, PNG. Max 5MB per file."},
  birthCertificatesSectionTitle: { en: "Birth Certificates", de: "Geburtsurkunden", fr: "Actes de naissance", it: "Certificati di nascita"},
  birthCertificateForChildLabel: { en: "Birth Certificate for", de: "Geburtsurkunde für", fr: "Acte de naissance pour", it: "Certificato di nascita per" },
  birthCertificateHelpChild: { en: "Upload the birth certificate for this child.", de: "Laden Sie die Geburtsurkunde für dieses Kind hoch.", fr: "Téléchargez l'acte de naissance de cet enfant.", it: "Carica il certificato di nascita per questo bambino." },
  marriageCertificateLabel: { en: "Marriage Certificate", de: "Heiratsurkunde", fr: "Acte de mariage", it: "Certificato di matrimonio"},
  divorceDecreeLabel: { en: "Divorce Decree", de: "Scheidungsurteil", fr: "Jugement de divorce", it: "Decreto di divorzio"},
  educationConfirmationsLabel: { en: "Confirmation of Education (for children >15)", de: "Ausbildungsbestätigung (für Kinder >15)", fr: "Attestation de formation (pour les enfants >15 ans)", it: "Conferma dell'istruzione (per figli >15 anni)"},
  educationConfirmationsHelp: { en: "Upload proof of education for each child over 15. If a standard form cannot be stamped by the school, other official school documents are accepted. Translations may be required for non-official language documents.", de: "Laden Sie für jedes Kind über 15 Jahre einen Ausbildungsnachweis hoch. Wenn ein Standardformular nicht von der Schule gestempelt werden kann, werden andere offizielle Schuldokumente akzeptiert. Für Dokumente in nicht offiziellen Sprachen können Übersetzungen erforderlich sein.", fr: "Téléchargez une preuve de formation pour chaque enfant de plus de 15 ans. Si un formulaire standard ne peut pas être tamponné par l'école, d'autres documents scolaires officiels sont acceptés. Des traductions peuvent être nécessaires pour les documents rédigés dans une langue non officielle.", it: "Carica la prova dell'istruzione per ogni figlio di età superiore ai 15 anni. Se un modulo standard non può essere timbrato dalla scuola, sono accettati altri documenti scolastici ufficiali. Potrebbero essere necessarie traduzioni per documenti in lingue non ufficiali."},
  noEducationConfirmationNeeded: { en: "Confirmation of education is not currently required based on your previous selection or children's ages.", de: "Eine Ausbildungsbestätigung ist aufgrund Ihrer vorherigen Auswahl oder des Alters der Kinder derzeit nicht erforderlich.", fr: "Une attestation de formation n'est actuellement pas requise sur la base de votre sélection précédente ou de l'âge des enfants.", it: "La conferma dell'istruzione non è attualmente richiesta in base alla selezione precedente o all'età dei figli."},


  // Step 20 (formerly 21, now 19 based on previous change, now 20): Signature
  step20Title: { en: "Step 20: Signature & Confirmation", de: "Schritt 20: Unterschrift & Bestätigung", fr: "Étape 20: Signature & Confirmation", it: "Passo 20: Firma e Conferma"}, // Title was step19Title, adjusted to 20
  step20Instruction: { en: "Your application is ready. Please confirm your submission by entering your full name, the date of signature, and confirming the accuracy of the information. By submitting, you confirm that all information provided is true and complete to the best of your knowledge.", de: "Ihr Antrag ist bereit. Bitte bestätigen Sie Ihre Einreichung, indem Sie Ihren vollständigen Namen, das Unterschriftsdatum eingeben und die Richtigkeit der Angaben bestätigen. Mit der Einreichung bestätigen Sie, dass alle gemachten Angaben nach bestem Wissen und Gewissen wahr und vollständig sind.", fr: "Votre demande est prête. Veuillez confirmer votre soumission en entrant votre nom complet, la date de signature et en confirmant l'exactitude des informations. En soumettant, vous confirmez que toutes les informations fournies sont vraies et complètes au meilleur de votre connaissance.", it: "La tua domanda è pronta. Conferma l'invio inserendo il tuo nome completo, la data della firma e confermando l'accuratezza delle informazioni. Inviando, confermi che tutte le informazioni fornite sono veritiere e complete al meglio delle tue conoscenze."}, // Key was step19Instruction
  signatureName: { en: "Full Name (as signature)", de: "Vollständiger Name (als Unterschrift)", fr: "Nom complet (en tant que signature)", it: "Nome completo (come firma)"},
  signatureNameHelp: { en: "Enter your full name as it appears on official documents.", de: "Geben Sie Ihren vollständigen Namen ein, wie er auf offiziellen Dokumenten erscheint.", fr: "Entrez votre nom complet tel qu'il apparaît sur les documents officiels.", it: "Inserisci il tuo nome completo come appare sui documenti ufficiali."},
  signatureDate: { en: "Date of Signature", de: "Datum der Unterschrift", fr: "Date de signature", it: "Data della firma"},
  signatureDateHelp: { en: "Select today's date.", de: "Wählen Sie das heutige Datum.", fr: "Sélectionnez la date d'aujourd'hui.", it: "Seleziona la data odierna."},
  informationConfirmationLabel: { en: "I confirm that all of the above information is correct and complete to the best of my knowledge.", de: "Ich bestätige, dass alle oben gemachten Angaben nach bestem Wissen und Gewissen richtig und vollständig sind.", fr: "Je confirme que toutes les informations ci-dessus sont correctes et complètes au meilleur de ma connaissance.", it: "Confermo che tutte le informazioni sopra riportate sono corrette e complete al meglio delle mie conoscenze."},


  // View Application Page
  viewApplicationTitle: { en: "View Application Details", de: "Antragsdetails anzeigen", fr: "Afficher les détails de la demande", it: "Visualizza dettagli domanda"},
  backToDashboard: { en: "Back to Dashboard", de: "Zurück zum Dashboard", fr: "Retour au tableau de bord", it: "Torna alla dashboard"},
  applicationSummary: { en: "Application Summary", de: "Antragsübersicht", fr: "Résumé de la demande", it: "Riepilogo domanda"},
  employeeInformation: { en: "Employee Information", de: "Mitarbeiterinformationen", fr: "Informations sur l'employé", it: "Informazioni sul dipendente"},
  personalDetails: { en: "Applicant's Personal Details", de: "Persönliche Daten des Antragstellers", fr: "Coordonnées personnelles du demandeur", it: "Dati personali del richiedente"},
  otherEmployersSection: { en: "Other Employers", de: "Andere Arbeitgeber", fr: "Autres employeurs", it: "Altri datori di lavoro"},
  employeeCashBenefitsSection: { en: "Employee Cash Benefits", de: "Geldleistungen Arbeitnehmer", fr: "Prestations en espèces de l'employé", it: "Prestazioni in denaro del dipendente"},
  spouseDetailsSection: { en: "Spouse/Partner Details", de: "Angaben zum Ehepartner/Partner", fr: "Détails du conjoint/partenaire", it: "Dettagli del coniuge/partner"},
  spouseEmploymentSection: { en: "Spouse/Partner Employment", de: "Erwerbstätigkeit Ehepartner/Partner", fr: "Emploi du conjoint/partenaire", it: "Occupazione del coniuge/partner"},
  spouseCashBenefitsSection: { en: "Spouse/Partner Cash Benefits", de: "Geldleistungen Ehepartner/Partner", fr: "Prestations en espèces du conjoint/partenaire", it: "Prestazioni in denaro del coniuge/partner"},
  spouseEmployerSection: { en: "Spouse/Partner Employer Details", de: "Details zum Arbeitgeber des Ehepartners/Partners", fr: "Détails de l'employeur du conjoint/partenaire", it: "Dettagli del datore di lavoro del coniuge/partner"},
  legalParentSection: { en: "Legal Parent Details (if different)", de: "Angaben zum gesetzlichen Elternteil (falls abweichend)", fr: "Détails du parent légal (si différent)", it: "Dettagli del genitore legale (se diverso)"},
  childCarerSection: { en: "Child's Carer Details", de: "Angaben zur Betreuungsperson des Kindes", fr: "Détails de la personne qui s'occupe de l'enfant", it: "Dettagli della persona che si prende cura del bambino"},
  previousAllowancesSection: { en: "Previous Swiss Child Allowances", de: "Frühere Kinderzulagen Schweiz", fr: "Allocations familiales suisses antérieures", it: "Precedenti assegni familiari svizzeri"},
  childrenDetails: { en: "Children Details", de: "Angaben zu den Kindern", fr: "Détails des enfants", it: "Dettagli dei figli"},
  uploadedDocuments: { en: "Uploaded Documents", de: "Hochgeladene Dokumente", fr: "Documents téléchargés", it: "Documenti caricati"},
  noDocumentsUploaded: { en: "No documents were uploaded for this part.", de: "Für diesen Teil des Antrags wurden keine Dokumente hochgeladen.", fr: "Aucun document n'a été téléchargé pour cette partie de la demande.", it: "Nessun documento è stato caricato per questa parte della domanda."},
  signature: { en: "Signature & Confirmation", de: "Unterschrift & Bestätigung", fr: "Signature & Confirmation", it: "Firma e Conferma"},
  signedBy: { en: "Signed By", de: "Unterzeichnet von", fr: "Signé par", it: "Firmato da"},
  applicationNotFound: { en: "Application not found.", de: "Antrag nicht gefunden.", fr: "Demande non trouvée.", it: "Domanda non trovata."},
  informationConfirmedTrue: { en: "Information confirmed as correct.", de: "Informationen als korrekt bestätigt.", fr: "Informations confirmées comme correctes.", it: "Informazioni confermate come corrette."},
  informationConfirmedFalse: { en: "Information not yet confirmed as correct.", de: "Informationen noch nicht als korrekt bestätigt.", fr: "Informations non encore confirmées comme correctes.", it: "Informazioni non ancora confermate come corrette."},
  adminComments: { en: "Admin Comments", de: "Admin-Kommentare", fr: "Commentaires de l'administrateur", it: "Commenti dell'amministratore" },
  noAdminComments: { en: "No comments from admin.", de: "Keine Kommentare vom Admin.", fr: "Aucun commentaire de l'administrateur.", it: "Nessun commento dall'amministratore." },


  // Admin Page
  adminDashboardTitle: { en: "Admin Dashboard - Child Allowance Applications", de: "Admin Dashboard - Kinderzulagenanträge", fr: "Tableau de bord Admin - Demandes d'allocations familiales", it: "Dashboard Admin - Domande di assegni familiari"},
  loadingApplications: { en: "Loading applications...", de: "Lade Anträge...", fr: "Chargement des demandes...", it: "Caricamento domande..."},
  review: { en: "Review", de: "Überprüfen", fr: "Examiner", it: "Revisiona"},
  noApplicationsSystem: { en: "No applications found in the system.", de: "Keine Anträge im System gefunden.", fr: "Aucune demande trouvée dans le système.", it: "Nessuna domanda trovata nel sistema."},
  adminNote: { en: "Note: This is a simplified admin view. Full admin functionality (review workflows, document download, sending questionnaires, corrections) would require further implementation.", de: "Hinweis: Dies ist eine vereinfachte Admin-Ansicht. Die volle Admin-Funktionalität (Prüf-Workflows, Dokumenten-Download, Versand von Fragebögen, Korrekturen) würde eine weitere Implementierung erfordern.", fr: "Note : Ceci est une vue admin simplifiée. Les fonctionnalités admin complètes (workflows de révision, téléchargement de documents, envoi de questionnaires, corrections) nécessiteraient une implémentation ultérieure.", it: "Nota: Questa è una vista admin semplificata. Le funzionalità admin complete (flussi di revisione, download documenti, invio questionari, correzioni) richiederebbero un'ulteriore implementazione."},
  employeeName: { en: "Employee Name", de: "Mitarbeitername", fr: "Nom de l'employé", it: "Nome Dipendente" },
  approve: { en: "Approve", de: "Genehmigen", fr: "Approuver", it: "Approva" },
  reject: { en: "Reject", de: "Ablehnen", fr: "Rejeter", it: "Respingi" },
  sendBack: { en: "Send Back", de: "Zurücksenden", fr: "Renvoyer", it: "Rimanda Indietro" },
  filterByEmployeeName: { en: "Filter by Employee Name", de: "Nach Mitarbeitername filtern", fr: "Filtrer par nom d'employé", it: "Filtra per Nome Dipendente" },
  filterBySubmissionDateFrom: { en: "Submission Date From", de: "Einreichdatum Von", fr: "Date de soumission De", it: "Data Invio Da" },
  filterBySubmissionDateTo: { en: "Submission Date To", de: "Einreichdatum Bis", fr: "Date de soumission À", it: "Data Invio A" },
  filterByStatus: { en: "Filter by Status", de: "Nach Status filtern", fr: "Filtrer par statut", it: "Filtra per Stato" },
  clearFilters: { en: "Clear Filters", de: "Filter löschen", fr: "Effacer les filtres", it: "Cancella Filtri" },
  allStatuses: { en: "All Statuses", de: "Alle Status", fr: "Tous les statuts", it: "Tutti gli Stati" },
  commentsForEmployee: { en: "Comments for Employee (Reason for sending back/rejection)", de: "Kommentare für Mitarbeiter (Grund für Rücksendung/Ablehnung)", fr: "Commentaires pour l'employé (Raison du renvoi/rejet)", it: "Commenti per il dipendente (Motivo del rinvio/rifiuto)" },
  enterComments: { en: "Enter comments...", de: "Kommentare eingeben...", fr: "Saisir les commentaires...", it: "Inserisci commenti..." },
  submitComment: { en: "Submit Comment", de: "Kommentar absenden", fr: "Soumettre le commentaire", it: "Invia Commento" },
  actionConfirmTitle: { en: "Confirm Action", de: "Aktion bestätigen", fr: "Confirmer l'action", it: "Conferma Azione" },
  actionConfirmMessage: { en: "Are you sure you want to {actionType} this application?", de: "Möchten Sie diesen Antrag wirklich {actionType}?", fr: "Êtes-vous sûr de vouloir {actionType} cette demande ?", it: "Sei sicuro di voler {actionType} questa domanda?" },
  newQuestionnaire: { en: "New Questionnaire", de: "Neuer Fragebogen", fr: "Nouveau Questionnaire", it: "Nuovo Questionario" },
  sendQuestionnaireTitle: { en: "Send New Questionnaire", de: "Neuen Fragebogen senden", fr: "Envoyer un nouveau questionnaire", it: "Invia nuovo questionario" },
  selectEmployee: { en: "Select Employee", de: "Mitarbeiter auswählen", fr: "Sélectionner un employé", it: "Seleziona dipendente" },
  selectEmployeePlaceholder: { en: "Choose an employee...", de: "Mitarbeiter auswählen...", fr: "Choisissez un employé...", it: "Scegli un dipendente..." },
  questionnaireFileLabel: { en: "Questionnaire File (PDF, DOCX)", de: "Fragebogendatei (PDF, DOCX)", fr: "Fichier du questionnaire (PDF, DOCX)", it: "File questionario (PDF, DOCX)" },
  commentsForQuestionnaire: { en: "Comments/Instructions for Employee", de: "Kommentare/Anweisungen für Mitarbeiter", fr: "Commentaires/Instructions pour l'employé", it: "Commenti/Istruzioni per il dipendente" },
  send: { en: "Send", de: "Senden", fr: "Envoyer", it: "Invia" },
  deadline: { en: "Deadline", de: "Frist", fr: "Date limite", it: "Scadenza" },
  questionnaireDetails: { en: "Questionnaire Details", de: "Fragebogen Details", fr: "Détails du Questionnaire", it: "Dettagli del Questionario"},


};

export const MAX_FILE_SIZE_MB = 5;
export const ALLOWED_FILE_TYPES = ['application/pdf', 'image/jpeg', 'image/png'];
export const ALLOWED_QUESTIONNAIRE_FILE_TYPES = ['application/pdf', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'image/jpeg', 'image/png'];


export const DEFAULT_LANGUAGE = 'en';
export const DEFAULT_THEME = 'theme2'; // Changed default theme

export const THEME_OPTIONS: SelectOption[] = [
  { value: 'theme2', label: 'Bright Blue & Mediterranean' },
  { value: 'theme3', label: 'Moody Blue & Silver' },
  { value: 'theme4', label: 'Sleek Graphite (Dark)' }, // Added new theme
];

export const LANGUAGE_OPTIONS: SelectOption[] = [
  { value: 'en', label: 'English' },
  { value: 'de', label: 'Deutsch' },
  { value: 'fr', label: 'Français' },
  { value: 'it', label: 'Italiano' },
];

export const MOCK_NOTIFICATIONS: Notification[] = [
  { id: 'notif1', type: 'info', messageKey: 'notificationNewApplicationAvailable', defaultMessage: 'A new application form is available for child allowance.', timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(), isRead: false, link: '/application/new' },
  { id: 'notif2', type: 'alert', messageKey: 'notificationPolicyUpdate', defaultMessage: 'Important: Child allowance policy has been updated. Please review.', timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3).toISOString(), isRead: false },
  { id: 'notif3', type: 'success', messageKey: 'notificationApplicationApproved', defaultMessage: 'Your application #APP-123 has been approved!', timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 5).toISOString(), isRead: true, link: '/application/view/app-xyz-123', linkState: { fromAdmin: false} }, 
  { id: 'notif4', type: 'update', messageKey: 'notificationActionRequired', defaultMessage: 'Action required on application #APP-456.', timestamp: new Date(Date.now() - 1000 * 60 * 30).toISOString(), isRead: false, link: '/application/edit/app-abc-456', linkState: { fromAdmin: false} }, 
];


// Helper to get translated enum value or fallback to original
export const translateEnum = (value: string, enumKeyPrefix: string, translateFn: (key: string, fallback?: string) => string): string => {
    if (!value) return translateFn('na', 'N/A');
    const translationKey = `${enumKeyPrefix}${value.replace(/\s+/g, '').replace(/[^a-zA-Z0-9]/g, '')}`;
    return translateFn(translationKey, value);
};

export const translateApplicationStatus = (status: ApplicationStatus | 'Pending' | 'Completed', translateFn: (key: string, fallback?: string) => string): string => {
    if (status === 'Pending' || status === 'Completed') { // For questionnaire status (old values)
        return translateFn(`status${status}`, status);
    }
    // For new ApplicationStatus and UserQuestionnaireStatus, they'll use their specific prefixes if needed
    // The key in TEXTS is 'status' + 'QuestionnaireSenttoEmployee' for example
    const translationKey = `status${status.replace(/\s+/g, '')}`;
    return translateFn(translationKey, status);
};

export const translateUserQuestionnaireStatus = (status: UserQuestionnaireStatus, translateFn: (key: string, fallback?: string) => string): string => {
    // The key in TEXTS is 'userQuestionnaireStatus' + 'PendingEmployeeResponse' for example
    const translationKey = `userQuestionnaireStatus${status.replace(/\s+/g, '')}`;
    return translateFn(translationKey, status);
};