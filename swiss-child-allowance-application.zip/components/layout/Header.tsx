
import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAppContext } from '../../hooks/useAppContext';
import { THEME_OPTIONS, LANGUAGE_OPTIONS } from '../../constants';
import Button from '../ui/Button';
import Modal from '../ui/Modal';
import NotificationBell from '../notifications/NotificationBell'; // Import NotificationBell

const Header: React.FC = () => {
  const { theme, setTheme, language, setLanguage, translate, user, isFormDirty, setIsFormDirty } = useAppContext();
  const navigate = useNavigate();
  const location = useLocation(); // Get location
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [navTarget, setNavTarget] = useState<string | null>(null);


  const handleThemeChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    setTheme(event.target.value as typeof theme);
  };

  const handleLanguageChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    setLanguage(event.target.value as typeof language);
  };

  const handleNavigationAttempt = (e: React.MouseEvent<HTMLAnchorElement | HTMLButtonElement>, targetPath: string) => {
    const isViewingApplication = location.pathname.startsWith('/application/view/');
    if (isFormDirty && !isViewingApplication) {
      e.preventDefault();
      setNavTarget(targetPath);
      setShowConfirmModal(true);
    } else {
      if (isFormDirty && isViewingApplication) {
         setIsFormDirty(false); // Clear dirty state if navigating away from view mode
      }
      navigate(targetPath);
    }
  };


  const confirmNavigation = () => {
    if (navTarget) {
      setIsFormDirty(false);
      navigate(navTarget);
    }
    setShowConfirmModal(false);
    setNavTarget(null);
  };

  const cancelNavigation = () => {
    setShowConfirmModal(false);
    setNavTarget(null);
  };

  let headerBgClass = 'bg-white shadow-md';
  let textColorClass = 'text-gray-800';
  let appNameColorClass = 'text-gray-900';
  let selectBgClass = 'bg-gray-100';
  let selectTextColorClass = 'text-gray-700';
  let selectBorderClass = 'border-gray-300';
  let selectFocusRingClass = 'focus:ring-indigo-500';


  if (theme === 'theme2') {
    headerBgClass = 'bg-theme2-primary shadow-lg';
    textColorClass = 'text-white';
    appNameColorClass = 'text-white';
    selectBgClass = 'bg-blue-700';
    selectTextColorClass = 'text-white';
    selectBorderClass = 'border-blue-500';
    selectFocusRingClass = 'focus:ring-white';
  } else if (theme === 'theme3') {
    headerBgClass = 'bg-theme3-primary shadow-lg';
    textColorClass = 'text-theme3-text-on-dark';
    appNameColorClass = 'text-theme3-text-on-dark';
    selectBgClass = 'bg-slate-700';
    selectTextColorClass = 'text-theme3-text-on-dark';
    selectBorderClass = 'border-slate-500';
    selectFocusRingClass = 'focus:ring-theme3-accent-light';
  } else if (theme === 'theme4') {
    headerBgClass = 'bg-theme4-secondary-bg shadow-lg'; 
    textColorClass = 'text-theme4-text-on-dark';
    appNameColorClass = 'text-theme4-text-on-dark';
    selectBgClass = 'bg-theme4-bg'; 
    selectTextColorClass = 'text-theme4-text-on-dark';
    selectBorderClass = 'border-theme4-border';
    selectFocusRingClass = 'focus:ring-theme4-primary';
  }


  return (
    <>
      <header className={`py-4 px-6 sticky top-0 z-40 ${headerBgClass}`}>
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-4">
             <Link to="/" onClick={(e) => handleNavigationAttempt(e, '/')} className={`text-2xl font-bold ${appNameColorClass}`}>
                {translate('appName', 'Swiss Child Allowance Portal')}
             </Link>
             <Button onClick={(e) => handleNavigationAttempt(e, '/')} variant="ghost" className={`${textColorClass} hover:underline`}>
                {translate('home')}
             </Button>
          </div>
          <div className="flex items-center space-x-4">
            {user && <span className={`text-sm ${textColorClass}`}>{translate('welcome')}, {user.name}</span>}
            
            <NotificationBell />

            <select
              value={theme}
              onChange={handleThemeChange}
              className={`px-3 py-1.5 border rounded-md text-sm focus:outline-none focus:ring-2 ${selectBgClass} ${selectTextColorClass} ${selectBorderClass} ${selectFocusRingClass} focus:ring-opacity-50`}
              aria-label={translate('selectTheme', 'Select Theme')}
            >
              {THEME_OPTIONS.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
            </select>

            <select
              value={language}
              onChange={handleLanguageChange}
              className={`px-3 py-1.5 border rounded-md text-sm focus:outline-none focus:ring-2 ${selectBgClass} ${selectTextColorClass} ${selectBorderClass} ${selectFocusRingClass} focus:ring-opacity-50`}
              aria-label={translate('selectLanguage', 'Select Language')}
            >
              {LANGUAGE_OPTIONS.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
            </select>
            {user?.role === 'admin' && (
              <Link to="/admin" onClick={(e) => handleNavigationAttempt(e, '/admin')} className={`text-sm font-medium ${textColorClass} hover:underline`}>{translate('admin', 'Admin')}</Link>
            )}
          </div>
        </div>
      </header>
      <Modal
        isOpen={showConfirmModal}
        onClose={cancelNavigation}
        title={translate('areYouSure')}
        onOk={confirmNavigation}
        okText={translate('confirm')}
        showCancelButton={true}
        cancelText={translate('cancel')}
      >
        <p>{translate('unsavedChangesLost')}</p>
      </Modal>
    </>
  );
};

export default Header;