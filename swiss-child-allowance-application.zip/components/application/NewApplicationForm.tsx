
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { ApplicationData, ApplicationStatus } from '../../types';
import { useAppContext } from '../../hooks/useAppContext';
import { saveApplication, getApplicationById, createNewApplication } from '../../services/applicationPersistenceService';
import StepIndicator from './StepIndicator';
import Button from '../ui/Button';
import Modal from '../ui/Modal';
import LoadingSpinner from '../ui/LoadingSpinner';

import Step1_Residency from './steps/Step1_Residency';
import Step2_EmployeeConfirmation from './steps/Step2_EmployeeConfirmation';
import Step3_AppliedInResidence from './steps/Step3_AppliedInResidence';
import Step4_PersonalDetails from './steps/Step4_PersonalDetails';
import Step5_OtherEmployersQuery from './steps/Step5_OtherEmployersQuery';
import Step6_OtherEmployerDetails from './steps/Step6_OtherEmployerDetails';
import Step7_EmployeeCashBenefits from './steps/Step7_EmployeeCashBenefits';
import Step8_SpouseDetails from './steps/Step8_SpouseDetails';
import Step9_SpouseEmployment from './steps/Step9_SpouseEmployment';
import Step10_SpouseCashBenefitsQuery from './steps/Step10_SpouseCashBenefitsQuery';
import Step11_SpouseBenefitDetails from './steps/Step11_SpouseBenefitDetails';
import Step12_SpouseEmployerDetails from './steps/Step12_SpouseEmployerDetails';
import Step13_ChildrenDetails from './steps/Step13_ChildrenDetails';
import Step14_LegalParentDetails from './steps/Step14_LegalParentDetails';
import Step15_ChildCarerQuery from './steps/Step15_ChildCarerQuery';
import Step16_ChildCarerDetails from './steps/Step16_ChildCarerDetails';
import Step17_PreviousAllowances from './steps/Step17_PreviousAllowances';
import Step18_ChildAgeQuery from './steps/Step18_ChildAgeQuery'; 
import Step19_20_DocumentUpload from './steps/Step19_20_DocumentUpload'; 
import StepFinal_Signature from './steps/StepFinal_Signature'; 
import { TOTAL_APPLICATION_STEPS } from '../../constants';


const NewApplicationForm: React.FC = () => {
  const { user, sfUserData, isLoadingSFData, translate, activeApplication, setActiveApplication, setIsFormDirty, isFormDirty, theme } = useAppContext();
  const navigate = useNavigate();
  const { id: applicationId } = useParams<{ id: string }>();
  const location = useLocation();
  
  const isViewMode = location.pathname.startsWith('/application/view/');

  const [currentStep, setCurrentStep_] = useState(1); 
  const [formData, setFormDataState] = useState<ApplicationData | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showExitModal, setShowExitModal] = useState(false);
  
  const [showStepNavigationModal, setShowStepNavigationModal] = useState(false);
  const [targetStepForNavigation, setTargetStepForNavigation] = useState<number | null>(null);


  const updateCurrentStepState = useCallback((step: number) => {
    setCurrentStep_(step); 
    if (!isViewMode) { // Only update persisted step if not in view mode
        setFormDataState(prev => {
            if (!prev) return null;
            const maxReachedStep = Math.max(prev.currentStep || 1, step);
            return { ...prev, currentStep: maxReachedStep };
        });
    }
  }, [isViewMode]);


  const initializeFormData = useCallback(() => {
    let appToLoad: ApplicationData | null = null;
    let initialUiStep = 1; 
    let initialFormDataStep = 1; 

    if (applicationId) {
        const existingApp = getApplicationById(applicationId);
        if (existingApp) {
            // In view mode, load any status. In edit mode, only DRAFT or PENDING_EMPLOYEE_ACTION.
            if (isViewMode || existingApp.status === ApplicationStatus.DRAFT || existingApp.status === ApplicationStatus.PENDING_EMPLOYEE_ACTION) {
                appToLoad = {...existingApp};
                initialUiStep = isViewMode ? 1 : (existingApp.currentStep || 1);
                // For view mode, unlock all steps. For edit, use saved progress.
                initialFormDataStep = isViewMode ? TOTAL_APPLICATION_STEPS : (existingApp.currentStep || 1);
            } else {
                navigate('/'); 
                return;
            }
        } else {
            navigate('/'); // App not found
            return;
        }
    } else if (activeApplication && (activeApplication.status === ApplicationStatus.DRAFT || activeApplication.status === ApplicationStatus.PENDING_EMPLOYEE_ACTION) && !isViewMode) {
        // This case is for continuing a draft that was set in context, not for view mode.
        appToLoad = {...activeApplication};
        initialUiStep = activeApplication.currentStep || 1;
        initialFormDataStep = activeApplication.currentStep || 1;
    } else if (!isViewMode) { // Only create new if not in view mode and no existing app is loaded
        if (user && sfUserData) {
            appToLoad = createNewApplication(user.id, sfUserData);
            initialUiStep = 1;
            initialFormDataStep = 1;
        } else {
            return; 
        }
    } else {
         // If in view mode but no applicationId, something is wrong.
         navigate('/');
         return;
    }

    if (appToLoad) {
        appToLoad.currentStep = initialFormDataStep; // Set the formData's currentStep (max step for indicator)

        setFormDataState(appToLoad);
        setCurrentStep_(initialUiStep); 
        setActiveApplication(appToLoad); 
        setIsFormDirty(false); 
    }

  }, [applicationId, user, sfUserData, activeApplication, setActiveApplication, navigate, setIsFormDirty, isViewMode]);


  useEffect(() => {
    // If isViewMode, always re-initialize when applicationId changes or on first load.
    // If not isViewMode, standard logic applies.
    if (isViewMode) {
        if (!formData || (applicationId && formData.id !== applicationId)) {
            initializeFormData();
        }
    } else {
        // Original logic for edit/new mode
        if (!formData || (applicationId && formData.id !== applicationId)) {
            initializeFormData();
        } else if (!applicationId && (user && sfUserData) && !formData) {
            initializeFormData();
        }
    }
  }, [initializeFormData, applicationId, formData, user, sfUserData, isViewMode]);


  const handleDataChange = (field: keyof ApplicationData | 'children', value: any) => { 
    if (isViewMode) return; // Prevent data changes in view mode
    setFormDataState(prev => prev ? { ...prev, [field]: value, lastModifiedDate: new Date().toISOString().split('T')[0] } : null);
    if (!isFormDirty) setIsFormDirty(true);
  };
  
  const nextStep = () => {
    if (!formData) return;
    let targetStep = currentStep + 1;

    if (currentStep === 1 && formData.residencyCountry === "Not-in-the-list" && !isViewMode) return; 
    if (currentStep === 3 && formData.appliedInResidenceCountry === false && !isViewMode) return; 
    
    if (currentStep === 5) { 
        if (formData.hasOtherEmployers === false || formData.hasOtherEmployers === undefined) targetStep = 7; 
    } else if (currentStep === 6 && formData.otherEmployers.some(e => e.incomeComparedToViking === 'Higher') && !isViewMode) {
        return; 
    } else if (currentStep === 9) { 
        if (formData.isSpouseGainfullyEmployed === true) targetStep = 12; 
        else if (formData.isSpouseGainfullyEmployed === false || formData.isSpouseGainfullyEmployed === undefined) targetStep = 10; 
    } else if (currentStep === 10) { 
        if (formData.spouseReceivingCashBenefits === true) targetStep = 11; 
        else if (formData.spouseReceivingCashBenefits === false || formData.spouseReceivingCashBenefits === undefined) targetStep = 13; 
    } else if (currentStep === 11) { 
        targetStep = 13; 
    } else if (currentStep === 14) { 
      if (formData.hasDifferentLegalParent === false || formData.hasDifferentLegalParent === undefined) {
          targetStep = 17; 
      } else { 
          targetStep = 15; 
      }
    } else if (currentStep === 15) { 
        if (formData.childLivesWithOtherCarer === false || formData.childLivesWithOtherCarer === undefined) targetStep = 17; 
    } else if (currentStep === 17) { 
        targetStep = 18; 
    } else if (currentStep === 18) { 
        targetStep = 19; 
    }

    if (targetStep <= TOTAL_APPLICATION_STEPS) {
      updateCurrentStepState(targetStep);
    }
  };

  const prevStep = () => {
    if (!formData) return;
    let targetStep = currentStep - 1;

    if (currentStep === 7 && (formData.hasOtherEmployers === false || formData.hasOtherEmployers === undefined)) { 
        targetStep = 5;
    } else if (currentStep === 12 && formData.isSpouseGainfullyEmployed === true) { 
        targetStep = 9;
    } else if (currentStep === 10 && (formData.isSpouseGainfullyEmployed === false || formData.isSpouseGainfullyEmployed === undefined)) { 
        targetStep = 9;
    } else if (currentStep === 13) { 
        if(formData.isSpouseGainfullyEmployed === true) { 
            targetStep = 12;
        } else if (formData.isSpouseGainfullyEmployed === false || formData.isSpouseGainfullyEmployed === undefined) { 
            if(formData.spouseReceivingCashBenefits === false || formData.spouseReceivingCashBenefits === undefined) { 
                targetStep = 10;
            } else { 
                targetStep = 11;
            }
        } else { 
            targetStep = 9; 
        }
    } else if (currentStep === 17) { 
        if(formData.childLivesWithOtherCarer === false || formData.childLivesWithOtherCarer === undefined) { 
            if (formData.hasDifferentLegalParent === false || formData.hasDifferentLegalParent === undefined) { 
                targetStep = 14; 
            } else { 
                 targetStep = 15; 
            }
        } else { 
            targetStep = 16;
        }
    } else if (currentStep === 19) { 
        targetStep = 18; 
    } else if (currentStep === 18) { 
        targetStep = 17; 
    }

    if (targetStep >= 1) {
      updateCurrentStepState(targetStep);
    }
  };

  const handleSaveDraft = () => {
    if (isViewMode || !formData || !user) return;
    const draftData: ApplicationData = {
      ...formData,
      status: ApplicationStatus.DRAFT,
      currentStep: currentStep, 
    };
    saveApplication(draftData);
    setIsFormDirty(false); 
    alert(translate('draftSaved'));
    navigate('/'); 
  };

  const handleSubmit = async () => {
    if (isViewMode || !formData || !user) return;
    setIsSubmitting(true);
    const submittedData: ApplicationData = {
      ...formData,
      status: ApplicationStatus.UNDER_REVIEW, 
      submissionDate: new Date().toISOString().split('T')[0],
      currentStep: TOTAL_APPLICATION_STEPS, 
    };
    await new Promise(resolve => setTimeout(resolve, 1000)); 
    saveApplication(submittedData);
    setIsFormDirty(false); 
    setIsSubmitting(false);
    alert(translate('applicationSubmitted'));
    navigate('/');
  };

  const handleExitClick = () => {
    if (isFormDirty && !isViewMode) {
        setShowExitModal(true);
    } else {
        // For view mode, or if not dirty, just navigate.
        // If coming from admin, navigate to admin, else to user dashboard.
        const targetDashboard = location.state?.fromAdmin ? '/admin' : '/';
        setIsFormDirty(false); // Clear dirty state if it was somehow set in view mode (shouldn't happen)
        navigate(targetDashboard);
    }
  };

  const confirmExitApplication = () => {
    if (formData && isFormDirty && !isViewMode) { 
        handleSaveDraft(); 
    } else {
        const targetDashboard = location.state?.fromAdmin ? '/admin' : '/';
        navigate(targetDashboard);
    }
    setIsFormDirty(false); 
    setShowExitModal(false);
  };

  const cancelExitApplication = () => {
    setShowExitModal(false);
  };
  
  const performDirectStepNavigation = (step: number) => {
    updateCurrentStepState(step);
    setTargetStepForNavigation(null);
    setShowStepNavigationModal(false);
  };

  const handleStepIndicatorClick = (step: number) => {
    if (step === currentStep) return;
    // In view mode, or if form is not dirty, navigate directly.
    if (isViewMode || !isFormDirty) {
      performDirectStepNavigation(step);
    } else { // Form is dirty and in edit/new mode
      setTargetStepForNavigation(step);
      setShowStepNavigationModal(true);
    }
  };

  const confirmStepNavigation = () => {
    if (targetStepForNavigation !== null) {
      setIsFormDirty(false); // User confirmed to lose changes
      performDirectStepNavigation(targetStepForNavigation);
    }
  };

  const cancelStepNavigation = () => {
    setShowStepNavigationModal(false);
    setTargetStepForNavigation(null);
  };

  if (isLoadingSFData && (!user || !sfUserData) && !applicationId) { // Adjusted for view mode not needing sfUserData for existing app
    return <LoadingSpinner text={translate('loading', 'Loading...')} />;
  }
  if (!formData) {
    return <LoadingSpinner text={translate('loadingApplicationData', 'Loading application data...')} />;
  }
  
  const renderStepContent = () => {
    const flexibleDataChange = (field: keyof ApplicationData | 'children', value: any) => {
        handleDataChange(field as keyof ApplicationData, value);
    };
    
    // Common props for all step components
    const commonStepProps = {
        formData: formData,
        onDataChange: flexibleDataChange,
        onNext: nextStep,
        onPrevious: prevStep,
        isViewMode: isViewMode,
    };

    switch (currentStep) {
      case 1: return <Step1_Residency {...commonStepProps} />;
      case 2: return <Step2_EmployeeConfirmation {...commonStepProps} />;
      case 3: return <Step3_AppliedInResidence {...commonStepProps} />;
      case 4: return <Step4_PersonalDetails {...commonStepProps} />;
      case 5: return <Step5_OtherEmployersQuery {...commonStepProps} />;
      case 6: return <Step6_OtherEmployerDetails {...commonStepProps} />;
      case 7: return <Step7_EmployeeCashBenefits {...commonStepProps} />;
      case 8: return <Step8_SpouseDetails {...commonStepProps} />;
      case 9: return <Step9_SpouseEmployment {...commonStepProps} />;
      case 10: return <Step10_SpouseCashBenefitsQuery {...commonStepProps} />;
      case 11: return <Step11_SpouseBenefitDetails {...commonStepProps} />;
      case 12: return <Step12_SpouseEmployerDetails {...commonStepProps} />;
      case 13: return <Step13_ChildrenDetails {...commonStepProps} />;
      case 14: return <Step14_LegalParentDetails {...commonStepProps} />;
      case 15: return <Step15_ChildCarerQuery {...commonStepProps} />;
      case 16: return <Step16_ChildCarerDetails {...commonStepProps} />;
      case 17: return <Step17_PreviousAllowances {...commonStepProps} />;
      case 18: return <Step18_ChildAgeQuery {...commonStepProps} />;
      case 19: return <Step19_20_DocumentUpload {...commonStepProps} />;
      case 20: return <StepFinal_Signature {...commonStepProps} onSubmit={handleSubmit} />; // onSubmit is only called if not isViewMode (handled in StepFinal)
      default:
        return <div>{translate('unknownStep')} {currentStep}</div>;
    }
  };
  
  let formContainerClasses = 'bg-white border border-gray-200';
  if (theme === 'theme2') {
    formContainerClasses = 'bg-theme2-secondary-bg border border-gray-200';
  } else if (theme === 'theme3') {
    formContainerClasses = 'bg-theme3-secondary-bg border border-gray-300';
  } else if (theme === 'theme4') {
    formContainerClasses = 'bg-theme4-secondary-bg border border-theme4-border';
  }


  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">
          {isViewMode ? translate('viewApplicationTitle') : (applicationId ? translate('editApplicationTitle') : translate('newApplicationTitle'))}
        </h1>
        <Button onClick={handleExitClick} variant="ghost" className="text-sm">
            {isViewMode ? translate('backToDashboard') : translate('exitApplication')}
        </Button>
      </div>

      <StepIndicator 
        currentStep={currentStep} 
        totalSteps={TOTAL_APPLICATION_STEPS}
        persistedCurrentStep={formData.currentStep} // This will be TOTAL_APPLICATION_STEPS in view mode
        onStepClick={handleStepIndicatorClick}
      />
      
      <div className={`p-6 rounded-lg shadow-lg bg-opacity-50 dark:bg-opacity-80 ${formContainerClasses}`}>
        {renderStepContent()}
      </div>

      {!isViewMode && (
        <div className="mt-6 flex justify-end items-center">
          {currentStep < TOTAL_APPLICATION_STEPS && (
              <Button onClick={handleSaveDraft} variant="secondary" className="mr-3" isLoading={isSubmitting}>
                  {translate('saveDraft')}
              </Button>
          )}
        </div>
      )}

      <Modal
        isOpen={showExitModal}
        onClose={cancelExitApplication}
        title={translate('confirmExitApplication')}
        onOk={confirmExitApplication}
        okText={translate('confirm')} 
        showCancelButton={true}
        cancelText={translate('cancel')} 
      >
        <p>{translate('exitApplicationWarning')}</p>
      </Modal>

      <Modal
        isOpen={showStepNavigationModal}
        onClose={cancelStepNavigation}
        title={translate('areYouSure')}
        onOk={confirmStepNavigation}
        okText={translate('confirm')}
        showCancelButton={true}
        cancelText={translate('cancel')}
      >
        <p>{translate('unsavedChangesLost')}</p>
      </Modal>

    </div>
  );
};

export default NewApplicationForm;