
import React from 'react';
import { Link } from 'react-router-dom';
import { ApplicationData, ChildDetails, ApplicationStatus } from '../../types';
import Button from '../ui/Button';
import { useAppContext } from '../../hooks/useAppContext';
import { translateApplicationStatus } from '../../constants';

interface ApplicationListItemProps {
  application: ApplicationData;
}

const ApplicationListItem: React.FC<ApplicationListItemProps> = ({ application }) => {
  const { translate, theme } = useAppContext();

  const childrenNames = application.children?.map((child: ChildDetails) => `${child.firstName} ${child.lastName}`).join(', ') || translate('na', 'N/A');

  let itemBgClass = 'bg-white';
  let textColorClass = 'text-gray-700';
  let headingColorClass = 'text-gray-900';
  let borderColorClass = 'border-gray-200';
  
  let statusBadgeBg = '';
  let statusBadgeText = '';

  if (theme === 'theme2') {
    itemBgClass = 'bg-theme2-secondary-bg';
    textColorClass = 'text-theme2-text';
    headingColorClass = 'text-theme2-text';
    borderColorClass = 'border-gray-200';

    switch (application.status) {
      case ApplicationStatus.DRAFT:
        statusBadgeBg = 'bg-gray-100'; statusBadgeText = 'text-gray-700'; break;
      case ApplicationStatus.SUBMITTED:
        statusBadgeBg = 'bg-blue-100'; statusBadgeText = 'text-blue-700'; break;
      case ApplicationStatus.UNDER_REVIEW:
        statusBadgeBg = 'bg-yellow-100'; statusBadgeText = 'text-yellow-700'; break;
      case ApplicationStatus.PENDING_EMPLOYEE_ACTION:
        statusBadgeBg = 'bg-orange-100'; statusBadgeText = 'text-orange-700'; break;
      case ApplicationStatus.COMPLETED:
        statusBadgeBg = 'bg-green-100'; statusBadgeText = 'text-green-700'; break;
      case ApplicationStatus.REJECTED:
        statusBadgeBg = 'bg-red-100'; statusBadgeText = 'text-red-700'; break;
      default:
        statusBadgeBg = 'bg-gray-100'; statusBadgeText = 'text-gray-700';
    }
  } else if (theme === 'theme3') {
    itemBgClass = 'bg-theme3-secondary-bg';
    textColorClass = 'text-theme3-text-on-light';
    headingColorClass = 'text-theme3-text-on-light';
    borderColorClass = 'border-gray-300';

    switch (application.status) {
      case ApplicationStatus.DRAFT:
        statusBadgeBg = 'bg-slate-200'; statusBadgeText = 'text-slate-700'; break;
      case ApplicationStatus.SUBMITTED:
        statusBadgeBg = 'bg-sky-200'; statusBadgeText = 'text-sky-800'; break; 
      case ApplicationStatus.UNDER_REVIEW:
        statusBadgeBg = 'bg-amber-200'; statusBadgeText = 'text-amber-800'; break;
      case ApplicationStatus.PENDING_EMPLOYEE_ACTION:
        statusBadgeBg = 'bg-rose-200'; statusBadgeText = 'text-rose-800'; break;
      case ApplicationStatus.COMPLETED:
        statusBadgeBg = 'bg-emerald-200'; statusBadgeText = 'text-emerald-800'; break;
      case ApplicationStatus.REJECTED:
        statusBadgeBg = 'bg-red-200'; statusBadgeText = 'text-red-800'; break;
      default:
        statusBadgeBg = 'bg-slate-200'; statusBadgeText = 'text-slate-700';
    }
  } else if (theme === 'theme4') {
    itemBgClass = 'bg-theme4-secondary-bg';
    textColorClass = 'text-theme4-text-on-dark';
    headingColorClass = 'text-theme4-text-on-dark';
    borderColorClass = 'border-theme4-border';

     switch (application.status) {
      case ApplicationStatus.DRAFT:
        statusBadgeBg = 'bg-slate-600'; statusBadgeText = 'text-slate-300'; break;
      case ApplicationStatus.SUBMITTED:
        statusBadgeBg = 'bg-sky-700/80'; statusBadgeText = 'text-sky-200'; break;
      case ApplicationStatus.UNDER_REVIEW:
        statusBadgeBg = 'bg-yellow-600/80'; statusBadgeText = 'text-yellow-200'; break;
      case ApplicationStatus.PENDING_EMPLOYEE_ACTION:
        statusBadgeBg = 'bg-orange-600/80'; statusBadgeText = 'text-orange-200'; break;
      case ApplicationStatus.COMPLETED:
        statusBadgeBg = 'bg-green-600/80'; statusBadgeText = 'text-green-200'; break;
      case ApplicationStatus.REJECTED:
        statusBadgeBg = 'bg-red-600/80'; statusBadgeText = 'text-red-200'; break;
      default:
        statusBadgeBg = 'bg-slate-700'; statusBadgeText = 'text-slate-400';
    }
  }
  
  const canEdit = application.status === ApplicationStatus.DRAFT || application.status === ApplicationStatus.PENDING_EMPLOYEE_ACTION;
  const showComments = application.adminComments && (application.status === ApplicationStatus.PENDING_EMPLOYEE_ACTION || application.status === ApplicationStatus.REJECTED);

  return (
    <div className={`p-4 rounded-lg shadow-md border ${borderColorClass} ${itemBgClass} mb-4`}>
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4 items-start">
        {/* Column 1: Application ID */}
        <div>
          <p className={`text-sm font-medium ${headingColorClass}`}>{translate('applicationId')}</p>
          <p className={`text-sm ${textColorClass}`}>{application.id.substring(0,8)}...</p>
        </div>
        {/* Column 2: Children Names */}
        <div>
          <p className={`text-sm font-medium ${headingColorClass}`}>{translate('childrenNames')}</p>
          <p className={`text-sm ${textColorClass} truncate`}>{childrenNames}</p>
        </div>
        {/* Column 3: Status */}
        <div>
          <p className={`text-sm font-medium ${headingColorClass} mb-1`}>{translate('status')}</p>
          <span className={`px-2.5 py-0.5 inline-flex text-xs leading-5 font-semibold rounded-full ${statusBadgeBg} ${statusBadgeText}`}>
            {translateApplicationStatus(application.status, translate)}
          </span>
        </div>
        {/* Column 4: Admin Comments */}
        <div>
          <p className={`text-sm font-medium ${headingColorClass}`}>{translate('adminComments')}</p>
          {showComments ? (
            <p className={`text-xs ${textColorClass} break-words whitespace-pre-wrap`}>{application.adminComments}</p>
          ) : (
            <p className={`text-xs ${textColorClass} italic`}>{translate('noAdminComments')}</p>
          )}
        </div>
        {/* Column 5: Actions */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-end space-y-2 md:space-y-0 md:space-x-2">
          {canEdit ? (
            <Link to={`/application/edit/${application.id}`}>
              <Button
                variant="secondary"
                size="sm"
              >
                {translate('edit')}
              </Button>
            </Link>
          ) : (
            <Link to={`/application/view/${application.id}`}>
              <Button
                variant="secondary"
                size="sm"
              >
                {translate('view')}
              </Button>
            </Link>
          )}
        </div>
      </div>
       <div className="mt-2">
          <p className={`text-xs ${textColorClass}`}>{translate('submissionDate')}: {application.submissionDate || translate('na', 'N/A')}</p>
        </div>
    </div>
  );
};

export default ApplicationListItem;
    