
import React from 'react';
import { useAppContext } from '../../hooks/useAppContext';

interface StepIndicatorProps {
  currentStep: number; // Current UI step
  totalSteps: number;
  persistedCurrentStep: number; // Highest step saved in formData
  onStepClick?: (step: number) => void;
}

const StepIndicator: React.FC<StepIndicatorProps> = ({ currentStep, totalSteps, persistedCurrentStep, onStepClick }) => {
  const { theme, translate } = useAppContext();
  const percentage = totalSteps > 1 ? ((currentStep -1) / (totalSteps -1 )) * 100 : (currentStep === 1 ? 100 : 0);

  let progressBgColor = 'bg-gray-200';
  let progressFillColor = 'bg-blue-600';
  let textColor = 'text-gray-700';
  let stepButtonDefaultBg = 'bg-gray-200 hover:bg-gray-300';
  let stepButtonActiveBg = 'bg-blue-600 text-white';
  let stepButtonDisabledBg = 'bg-gray-100 text-gray-400 cursor-not-allowed';


  if (theme === 'theme2') {
    progressBgColor = 'bg-theme2-accent1';
    progressFillColor = 'bg-theme2-primary';
    textColor = 'text-theme2-text';
    stepButtonDefaultBg = 'bg-theme2-accent3/50 hover:bg-theme2-accent3 text-theme2-text';
    stepButtonActiveBg = 'bg-theme2-primary text-white';
    stepButtonDisabledBg = 'bg-gray-200 text-gray-400 cursor-not-allowed';
  } else if (theme === 'theme3') {
    progressBgColor = 'bg-theme3-accent/50';
    progressFillColor = 'bg-theme3-primary';
    textColor = 'text-theme3-text-on-light';
    stepButtonDefaultBg = 'bg-theme3-accent/70 hover:bg-theme3-accent text-theme3-text-on-light';
    stepButtonActiveBg = 'bg-theme3-primary text-theme3-text-on-dark';
    stepButtonDisabledBg = 'bg-slate-300 text-slate-500 cursor-not-allowed';
  } else if (theme === 'theme4') {
    progressBgColor = 'bg-theme4-accent/50'; // Lighter accent for progress track
    progressFillColor = 'bg-theme4-primary';
    textColor = 'text-theme4-text-on-dark';
    stepButtonDefaultBg = 'bg-theme4-accent/70 hover:bg-theme4-accent text-theme4-text-on-dark';
    stepButtonActiveBg = 'bg-theme4-primary text-white'; // Primary for active step
    stepButtonDisabledBg = 'bg-slate-700 text-slate-500 cursor-not-allowed'; // Darker disabled
  }

  const stepText = translate('stepProgress', 'Step {current} of {total}')
    .replace('{current}', currentStep.toString())
    .replace('{total}', totalSteps.toString());

  const maxUnlockedStep = Math.max(currentStep, persistedCurrentStep);

  return (
    <div className="my-6">
      <div className="flex justify-between items-center mb-1">
        <span className={`text-sm font-medium ${textColor}`}>{stepText}</span>
        <span className={`text-sm font-medium ${textColor}`}>{Math.round(percentage)}%</span>
      </div>
      <div className={`w-full ${progressBgColor} rounded-full h-2.5 mb-3`}>
        <div
          className={`${progressFillColor} h-2.5 rounded-full transition-all duration-500 ease-out`}
          style={{ width: `${percentage}%` }}
          aria-valuenow={percentage}
          aria-valuemin={0}
          aria-valuemax={100}
          role="progressbar"
          aria-label={stepText}
        ></div>
      </div>
      <div className="flex flex-wrap justify-center sm:justify-between gap-1 mt-2">
        {Array.from({ length: totalSteps }, (_, i) => i + 1).map((stepNumber) => {
          const isStepClickable = !!onStepClick && stepNumber <= maxUnlockedStep;
          return (
            <button
              key={stepNumber}
              onClick={() => isStepClickable && onStepClick(stepNumber)}
              disabled={!isStepClickable}
              className={`w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-colors
                ${stepNumber === currentStep ? stepButtonActiveBg : 
                  isStepClickable ? stepButtonDefaultBg :
                  stepButtonDisabledBg
                }
              `}
              aria-label={`${translate('step', 'Step')} ${stepNumber}${stepNumber === currentStep ? `, ${translate('currentStep', 'current step')}` : ''}${!isStepClickable ? `, ${translate('disabledStep', 'disabled')}`: ''}`}
              aria-current={stepNumber === currentStep ? 'step' : undefined}
            >
              {stepNumber}
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default StepIndicator;