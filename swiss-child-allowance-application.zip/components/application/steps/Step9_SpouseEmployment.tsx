
import React from 'react';
import { ApplicationData, SpouseEmploymentStatus } from '../../../types';
import FormField from '../../ui/FormField';
import Button from '../../ui/Button';
import { YES_NO_OPTIONS, SPOUSE_EMPLOYMENT_STATUS_OPTIONS } from '../../../constants';
import { useAppContext } from '../../../hooks/useAppContext';

interface Step9SpouseEmploymentProps {
  formData: ApplicationData;
  onDataChange: (field: keyof ApplicationData, value: any) => void;
  onNext: () => void;
  onPrevious: () => void;
  isViewMode?: boolean; // Added
}

const Step9_SpouseEmployment: React.FC<Step9SpouseEmploymentProps> = ({ formData, onDataChange, onNext, onPrevious, isViewMode }) => {
  const { translate, theme } = useAppContext();

  const handleYesNoChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value === "yes" ? true : e.target.value === "no" ? false : undefined;
    onDataChange('isSpouseGainfullyEmployed', value);
    if (value === true) { 
        onDataChange('spouseEmploymentStatus', undefined);
    }
  };
  
  const valueForYesNoSelect = formData.isSpouseGainfullyEmployed === true ? "yes" : formData.isSpouseGainfullyEmployed === false ? "no" : "";

  const isNextDisabledInEditMode = formData.isSpouseGainfullyEmployed === undefined ||
                        (formData.isSpouseGainfullyEmployed === false && formData.spouseEmploymentStatus === undefined);
  const isNextDisabled = !isViewMode && isNextDisabledInEditMode;

  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">{translate('step9Title')}</h2>
      <FormField
        id="isSpouseGainfullyEmployed"
        label={translate('step9Question')}
        as="select"
        options={YES_NO_OPTIONS}
        value={valueForYesNoSelect}
        onChange={handleYesNoChange}
        required={!isViewMode}
        placeholder={translate('pleaseSelect')}
        disabled={isViewMode} // Added
      />

      {formData.isSpouseGainfullyEmployed === false && (
        <div className="mt-4 pt-4 border-t">
          <FormField
            id="spouseEmploymentStatus"
            name="spouseEmploymentStatus"
            label={translate('spouseEmploymentStatusLabel')}
            as="select"
            options={SPOUSE_EMPLOYMENT_STATUS_OPTIONS}
            value={formData.spouseEmploymentStatus || ''}
            onChange={(e) => onDataChange('spouseEmploymentStatus', e.target.value as SpouseEmploymentStatus)}
            required={!isViewMode}
            placeholder={translate('pleaseSelect')}
            disabled={isViewMode} // Added
          />
        </div>
      )}
      {isViewMode && formData.isSpouseGainfullyEmployed === undefined && (
        <p className={`italic mt-4 ${theme === 'theme4' ? 'text-theme4-text-on-dark' : 'text-gray-600'}`}>{translate('notProvided')}</p>
      )}


      <div className="mt-6 flex justify-between">
        <Button onClick={onPrevious} variant="secondary">
          {translate('previous')}
        </Button>
        <Button onClick={onNext} disabled={isNextDisabled}>
          {translate('next')}
        </Button>
      </div>
    </div>
  );
};

export default Step9_SpouseEmployment;