
import React from 'react';
import { ApplicationData } from '../../../types';
import FormField from '../../ui/FormField';
import Button from '../../ui/Button';
import { MARITAL_STATUS_OPTIONS } from '../../../constants';
import { useAppContext } from '../../../hooks/useAppContext';

interface Step8SpouseDetailsProps {
  formData: ApplicationData;
  onDataChange: (field: keyof ApplicationData, value: any) => void;
  onNext: () => void;
  onPrevious: () => void;
  isViewMode?: boolean; // Added
}

const Step8_SpouseDetails: React.FC<Step8SpouseDetailsProps> = ({ formData, onDataChange, onNext, onPrevious, isViewMode }) => {
  const { translate } = useAppContext();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    onDataChange(e.target.name as keyof ApplicationData, e.target.value);
  };
  
  const isNextDisabledInEditMode = ![
    formData.spouseLastName,
    formData.spouseFirstName,
    formData.spouseDateOfBirth,
    formData.spousePersonalId,
    formData.spouseMaritalStatus
  ].every(Boolean);
  const isNextDisabled = !isViewMode && isNextDisabledInEditMode;

  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">{translate('step8Title')}</h2>
      <p className="mb-4 text-sm">{translate('step8Instruction')}</p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4">
        <FormField
          id="spouseLastName"
          name="spouseLastName"
          label={translate('spouseLastName')}
          value={formData.spouseLastName || ''}
          onChange={handleChange}
          required={!isViewMode}
          disabled={isViewMode} // Added
        />
        <FormField
          id="spouseFirstName"
          name="spouseFirstName"
          label={translate('spouseFirstName')}
          value={formData.spouseFirstName || ''}
          onChange={handleChange}
          required={!isViewMode}
          disabled={isViewMode} // Added
        />
        <FormField
          id="spouseDateOfBirth"
          name="spouseDateOfBirth"
          label={translate('spouseDateOfBirth')}
          type="date"
          value={formData.spouseDateOfBirth || ''}
          onChange={handleChange}
          required={!isViewMode}
          disabled={isViewMode} // Added
        />
        <FormField
          id="spousePersonalId"
          name="spousePersonalId"
          label={translate('spousePersonalId')}
          value={formData.spousePersonalId || ''}
          onChange={handleChange}
          required={!isViewMode}
          disabled={isViewMode} // Added
        />
        <FormField
          id="spouseMaritalStatus"
          name="spouseMaritalStatus"
          label={translate('spouseMaritalStatus')}
          as="select"
          options={MARITAL_STATUS_OPTIONS}
          value={formData.spouseMaritalStatus || ''}
          onChange={handleChange}
          required={!isViewMode}
          placeholder={translate('selectMaritalStatus')}
          disabled={isViewMode} // Added
        />
      </div>

      <div className="mt-6 flex justify-between">
        <Button onClick={onPrevious} variant="secondary">
          {translate('previous')}
        </Button>
        <Button onClick={onNext} disabled={isNextDisabled}>
          {translate('next')}
        </Button>
      </div>
    </div>
  );
};

export default Step8_SpouseDetails;