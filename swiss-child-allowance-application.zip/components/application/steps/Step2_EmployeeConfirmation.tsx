
import React from 'react';
import { ApplicationData } from '../../../types';
import Button from '../../ui/Button';
import FormField from '../../ui/FormField';
import { useAppContext } from '../../../hooks/useAppContext';

interface Step2EmployeeConfirmationProps {
  formData: ApplicationData;
  onDataChange: (field: keyof ApplicationData, value: any) => void;
  onNext: () => void;
  onPrevious: () => void;
  isViewMode?: boolean; // Added
}

const Step2_EmployeeConfirmation: React.FC<Step2EmployeeConfirmationProps> = ({ formData, onDataChange, onNext, onPrevious, isViewMode }) => {
  const { translate, theme } = useAppContext();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onDataChange(e.target.name as keyof ApplicationData, e.target.value);
  };

  let cardBgClass = 'bg-white';
  let cardBorderClass = 'border-gray-200';
  if (theme === 'theme2') {
    cardBgClass = 'bg-theme2-secondary-bg/70';
    cardBorderClass = 'border-gray-200';
  } else if (theme === 'theme3') {
    cardBgClass = 'bg-theme3-secondary-bg/70';
    cardBorderClass = 'border-gray-300';
  } else if (theme === 'theme4') {
    cardBgClass = 'bg-theme4-secondary-bg/70'; 
    cardBorderClass = 'border-theme4-border';
  }

  const isNextDisabled = !isViewMode && ![
    formData.employeeFirstName,
    formData.employeeLastName,
    formData.employeeDateOfBirth,
    formData.employeeEmployeeId, 
  ].every(Boolean);


  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">{translate('step2Title')}</h2>
      <p className="mb-4 text-sm">
        {translate('step2InstructionEditable')}
      </p>

      <div className={`border rounded-md shadow-sm p-4 ${cardBgClass} ${cardBorderClass}`}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4">
            <FormField
                id="employeeFirstName"
                name="employeeFirstName"
                label={translate('firstName')}
                value={formData.employeeFirstName || ''}
                onChange={handleChange}
                required={!isViewMode}
                disabled={isViewMode} // Added
            />
            <FormField
                id="employeeLastName"
                name="employeeLastName"
                label={translate('lastName')}
                value={formData.employeeLastName || ''}
                onChange={handleChange}
                required={!isViewMode}
                disabled={isViewMode} // Added
            />
            <FormField
                id="employeeDateOfBirth"
                name="employeeDateOfBirth"
                label={translate('dateOfBirth')}
                type="date"
                value={formData.employeeDateOfBirth || ''}
                onChange={handleChange}
                required={!isViewMode}
                disabled={isViewMode} // Added
            />
            <FormField
                id="employeeEmployeeId"
                name="employeeEmployeeId"
                label={translate('employeeId')}
                value={formData.employeeEmployeeId || ''}
                onChange={handleChange}
                disabled // Typically Employee ID is not changed by user, always disabled
                required={!isViewMode}
            />
            <FormField
                id="employeeAhvNumber"
                name="employeeAhvNumber"
                label={translate('ahvNumber')}
                value={formData.employeeAhvNumber || ''}
                onChange={handleChange}
                disabled={isViewMode} // Added
            />
            <FormField
                id="employeeCompanyName"
                name="employeeCompanyName"
                label={translate('companyName')}
                value={formData.employeeCompanyName || ''}
                onChange={handleChange}
                disabled // Company context is usually fixed, always disabled
            />
            <FormField
                id="employeeContractStartDate"
                name="employeeContractStartDate"
                label={translate('contractStartDate')}
                type="date"
                value={formData.employeeContractStartDate || ''}
                onChange={handleChange}
                disabled // Contract dates often fixed by HR, always disabled
            />
            <FormField
                id="employeeContractEndDate"
                name="employeeContractEndDate"
                label={translate('contractEndDate')}
                type="date"
                value={formData.employeeContractEndDate || ''}
                onChange={handleChange}
                disabled // Contract dates often fixed by HR, always disabled
            />
        </div>
      </div>

      <div className="mt-6 flex justify-between">
        <Button onClick={onPrevious} variant="secondary">
          {translate('previous')}
        </Button>
        <Button onClick={onNext} disabled={isNextDisabled}>
          {translate('confirmAndNext')}
        </Button>
      </div>
    </div>
  );
};

export default Step2_EmployeeConfirmation;