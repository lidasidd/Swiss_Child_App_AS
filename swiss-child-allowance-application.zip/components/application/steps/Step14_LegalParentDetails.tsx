
import React from 'react';
import { ApplicationData, MaritalStatus, LegalParentEmploymentStatus, ChildDetails } from '../../../types';
import FormField from '../../ui/FormField';
import Button from '../../ui/Button';
import { YES_NO_OPTIONS, MARITAL_STATUS_OPTIONS, LEGAL_PARENT_EMPLOYMENT_OPTIONS } from '../../../constants';
import { useAppContext } from '../../../hooks/useAppContext';

interface Step14LegalParentDetailsProps {
  formData: ApplicationData;
  onDataChange: (field: keyof ApplicationData, value: any) => void;
  onNext: () => void;
  onPrevious: () => void;
  isViewMode?: boolean; // Added
}

const Step14_LegalParentDetails: React.FC<Step14LegalParentDetailsProps> = ({ formData, onDataChange, onNext, onPrevious, isViewMode }) => {
  const { translate, theme } = useAppContext();

  const handleOuterChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value === "yes" ? true : e.target.value === "no" ? false : undefined;
    onDataChange('hasDifferentLegalParent', value);
    if (value === false) { 
        onDataChange('legalParentAppliesToAllChildren', undefined);
        onDataChange('legalParentAppliesToChildIds', []);
        onDataChange('legalParentLastName', '');
        onDataChange('legalParentFirstName', '');
        onDataChange('legalParentDateOfBirth', '');
        onDataChange('legalParentMaritalStatus', undefined);
        onDataChange('legalParentAddress', '');
        onDataChange('legalParentTelephone', '');
        onDataChange('legalParentEmploymentDetail', undefined);
        onDataChange('legalParentEmployerName', '');
        onDataChange('legalParentEmployerAddress', '');
        onDataChange('legalParentEmployerCantonCountry', '');
        onDataChange('legalParentSelfEmployedCantonCountry', '');
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    onDataChange(e.target.name as keyof ApplicationData, e.target.value);
  };
  
  const handleChildSelection = (childId: string) => {
    if (isViewMode) return;
    const currentSelection = formData.legalParentAppliesToChildIds || [];
    const newSelection = currentSelection.includes(childId)
        ? currentSelection.filter(id => id !== childId)
        : [...currentSelection, childId];
    onDataChange('legalParentAppliesToChildIds', newSelection);
  };

  const valueForOuterSelect = formData.hasDifferentLegalParent === true ? "yes" : formData.hasDifferentLegalParent === false ? "no" : "";
  
  const areCoreDetailsFilled = () => {
    return !!(formData.legalParentLastName &&
           formData.legalParentFirstName &&
           formData.legalParentDateOfBirth &&
           formData.legalParentMaritalStatus &&
           formData.legalParentAddress &&
           formData.legalParentTelephone &&
           formData.legalParentEmploymentDetail);
  };

  const areEmploymentDetailsFilled = () => {
    if (formData.legalParentEmploymentDetail === LegalParentEmploymentStatus.EMPLOYED) {
      return !!(formData.legalParentEmployerName && formData.legalParentEmployerAddress && formData.legalParentEmployerCantonCountry);
    }
    if (formData.legalParentEmploymentDetail === LegalParentEmploymentStatus.SELF_EMPLOYED) {
      return !!formData.legalParentSelfEmployedCantonCountry;
    }
    return true; 
  };
  
  const isChildSelectionValid = () => {
    if (formData.hasDifferentLegalParent && formData.legalParentAppliesToAllChildren === false) {
        return formData.legalParentAppliesToChildIds && formData.legalParentAppliesToChildIds.length > 0;
    }
    return true; 
  };

  const isNextDisabledInEditMode = formData.hasDifferentLegalParent === undefined ||
                        (formData.hasDifferentLegalParent === true && 
                            (formData.legalParentAppliesToAllChildren === undefined ||
                             !isChildSelectionValid() ||
                             !areCoreDetailsFilled() ||
                             !areEmploymentDetailsFilled()
                            )
                        );
  const isNextDisabled = !isViewMode && isNextDisabledInEditMode;

  let checkboxLabelClass = 'text-gray-700';
  let checkboxContainerBorder = 'border-gray-200';
  let checkboxContainerBg = 'bg-gray-50';


  if (theme === 'theme2') {
    checkboxLabelClass = 'text-theme2-text';
    checkboxContainerBorder = 'border-theme2-accent3/50';
    checkboxContainerBg = 'bg-theme2-accent1/20';
  } else if (theme === 'theme3') {
    checkboxLabelClass = 'text-theme3-text-on-light';
    checkboxContainerBorder = 'border-slate-300';
    checkboxContainerBg = 'bg-slate-100';
  } else if (theme === 'theme4') {
    checkboxLabelClass = 'text-theme4-text-on-dark';
    checkboxContainerBorder = 'border-theme4-border';
    checkboxContainerBg = 'bg-theme4-secondary-bg/70';
  }


  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">{translate('step14Title')}</h2>
      <FormField
        id="hasDifferentLegalParent"
        label={translate('step14Question')}
        as="select"
        options={YES_NO_OPTIONS}
        value={valueForOuterSelect}
        onChange={handleOuterChange}
        required={!isViewMode}
        placeholder={translate('pleaseSelect')}
        disabled={isViewMode}
      />

      {formData.hasDifferentLegalParent && (
        <div className="mt-4 pt-4 border-t">
          <FormField
            id="legalParentAppliesToAllChildren"
            name="legalParentAppliesToAllChildren"
            label={translate('legalParentAppliesToWhichChildren')}
            as="select"
            options={[{value: "true", labelKey: 'allChildren'}, {value: "false", labelKey: 'selectChildren'}]}
            value={formData.legalParentAppliesToAllChildren === true ? "true" : formData.legalParentAppliesToAllChildren === false ? "false" : ""}
            onChange={(e) => onDataChange('legalParentAppliesToAllChildren', e.target.value === "true")}
            required={!isViewMode}
            placeholder={translate('pleaseSelect')}
            disabled={isViewMode}
          />

          {formData.legalParentAppliesToAllChildren === false && formData.children.length > 0 && (
            <div className={`my-3 p-3 border rounded-md ${checkboxContainerBg} ${checkboxContainerBorder}`}>
              <p className={`text-sm font-medium mb-1 ${checkboxLabelClass}`}>{translate('selectApplicableChildren')}</p>
              {formData.children.map((child: ChildDetails) => (
                <label key={child.id} className="flex items-center space-x-2 my-1">
                  <input
                    type="checkbox"
                    className={`form-checkbox h-4 w-4 rounded ${theme === 'theme4' ? 'bg-slate-600 border-slate-500 text-theme4-primary focus:ring-theme4-primary' : 'border-gray-300 text-indigo-600 focus:ring-indigo-500'}`}
                    checked={(formData.legalParentAppliesToChildIds || []).includes(child.id)}
                    onChange={() => handleChildSelection(child.id)}
                    disabled={isViewMode}
                  />
                  <span className={checkboxLabelClass}>{child.firstName} {child.lastName}</span>
                </label>
              ))}
            </div>
          )}

          <FormField id="legalParentLastName" name="legalParentLastName" label={translate('legalParentLastName')} value={formData.legalParentLastName || ''} onChange={handleChange} required={!isViewMode} disabled={isViewMode} />
          <FormField id="legalParentFirstName" name="legalParentFirstName" label={translate('legalParentFirstName')} value={formData.legalParentFirstName || ''} onChange={handleChange} required={!isViewMode} disabled={isViewMode} />
          <FormField id="legalParentDateOfBirth" name="legalParentDateOfBirth" label={translate('legalParentDob')} type="date" value={formData.legalParentDateOfBirth || ''} onChange={handleChange} required={!isViewMode} disabled={isViewMode} />
          <FormField id="legalParentMaritalStatus" name="legalParentMaritalStatus" label={translate('legalParentMaritalStatus')} as="select" options={MARITAL_STATUS_OPTIONS} value={formData.legalParentMaritalStatus || ''} onChange={handleChange} required={!isViewMode} placeholder={translate('pleaseSelect')} disabled={isViewMode} />
          <FormField id="legalParentAddress" name="legalParentAddress" label={translate('legalParentAddress')} value={formData.legalParentAddress || ''} onChange={handleChange} required={!isViewMode} disabled={isViewMode} />
          <FormField id="legalParentTelephone" name="legalParentTelephone" label={translate('legalParentTelephone')} type="tel" value={formData.legalParentTelephone || ''} onChange={handleChange} required={!isViewMode} disabled={isViewMode} />
          
          <FormField 
            id="legalParentEmploymentDetail" 
            name="legalParentEmploymentDetail" 
            label={translate('legalParentEmploymentDetail')} 
            as="select" 
            options={LEGAL_PARENT_EMPLOYMENT_OPTIONS} 
            value={formData.legalParentEmploymentDetail || ''} 
            onChange={handleChange} required={!isViewMode} 
            placeholder={translate('pleaseSelect')} 
            disabled={isViewMode}
          />

          {formData.legalParentEmploymentDetail === LegalParentEmploymentStatus.EMPLOYED && (
            <>
              <FormField id="legalParentEmployerName" name="legalParentEmployerName" label={translate('legalParentEmployerNameAddress')} value={formData.legalParentEmployerName || ''} onChange={handleChange} required={!isViewMode} helpText={translate('legalParentEmployerNameHelpText')} disabled={isViewMode}/>
              <FormField id="legalParentEmployerAddress" name="legalParentEmployerAddress" label="" value={formData.legalParentEmployerAddress || ''} onChange={handleChange} required={!isViewMode} helpText={translate('legalParentEmployerAddressHelpText')} disabled={isViewMode}/>
              <FormField id="legalParentEmployerCantonCountry" name="legalParentEmployerCantonCountry" label={translate('legalParentEmployerCantonCountry')} value={formData.legalParentEmployerCantonCountry || ''} onChange={handleChange} required={!isViewMode} disabled={isViewMode} />
            </>
          )}
          {formData.legalParentEmploymentDetail === LegalParentEmploymentStatus.SELF_EMPLOYED && (
            <FormField id="legalParentSelfEmployedCantonCountry" name="legalParentSelfEmployedCantonCountry" label={translate('legalParentSelfEmployedCantonCountry')} value={formData.legalParentSelfEmployedCantonCountry || ''} onChange={handleChange} required={!isViewMode} disabled={isViewMode} />
          )}
        </div>
      )}
      {isViewMode && formData.hasDifferentLegalParent === false && (
         <p className={`italic mt-4 ${theme === 'theme4' ? 'text-theme4-text-on-dark' : 'text-gray-600'}`}>{translate('notProvided')}</p>
      )}


      <div className="mt-6 flex justify-between">
        <Button onClick={onPrevious} variant="secondary">{translate('previous')}</Button>
        <Button onClick={onNext} disabled={isNextDisabled}>{translate('next')}</Button>
      </div>
    </div>
  );
};

export default Step14_LegalParentDetails;