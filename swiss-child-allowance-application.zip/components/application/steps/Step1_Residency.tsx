
import React, { useState } from 'react';
import { ApplicationData } from '../../../types';
import FormField from '../../ui/FormField';
import Button from '../../ui/Button';
import Modal from '../../ui/Modal';
import { EU_EFTA_FREE_MOVEMENT_COUNTRIES } from '../../../constants';
import { useAppContext } from '../../../hooks/useAppContext';

interface Step1ResidencyProps {
  formData: ApplicationData;
  onDataChange: (field: keyof ApplicationData, value: any) => void;
  onNext: () => void;
  isViewMode?: boolean; // Added
}

const Step1_Residency: React.FC<Step1ResidencyProps> = ({ formData, onDataChange, onNext, isViewMode }) => {
  const { translate } = useAppContext();
  const [showNotEligibleModal, setShowNotEligibleModal] = useState(false);

  const handleNext = () => {
    if (!isViewMode && formData.residencyCountry === "Not-in-the-list") {
      setShowNotEligibleModal(true);
    } else if (formData.residencyCountry || isViewMode) { // Allow next if in view mode even if empty (should be filled usually)
      onNext();
    } else {
      alert(translate('selectCountryError'));
    }
  };

  const handleModalClose = () => {
    setShowNotEligibleModal(false);
  };
  
  const residencyCountry = formData.residencyCountry ?? "";

  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">{translate('step1Title')}</h2>
      <p className="mb-4 text-sm">{translate('step1Instruction')}</p>
      
      <FormField
        id="residencyCountry"
        label={translate('countryOfResidence')}
        as="select"
        options={EU_EFTA_FREE_MOVEMENT_COUNTRIES}
        value={residencyCountry}
        onChange={(e) => onDataChange('residencyCountry', e.target.value)}
        required={!isViewMode}
        placeholder={translate('selectCountryPlaceholder')}
        disabled={isViewMode} // Added
      />

      <div className="mt-6 flex justify-end">
        <Button onClick={handleNext} disabled={!isViewMode && !formData.residencyCountry}>
          {translate('next')}
        </Button>
      </div>

      {!isViewMode && (
        <Modal
            isOpen={showNotEligibleModal}
            onClose={handleModalClose}
            title={translate('eligibilityCheck')}
            showOkButton={true}
            okText={translate('close')}
            onOk={handleModalClose}
        >
            <p>{translate('step1NotEligible')}</p>
        </Modal>
      )}
    </div>
  );
};

export default Step1_Residency;