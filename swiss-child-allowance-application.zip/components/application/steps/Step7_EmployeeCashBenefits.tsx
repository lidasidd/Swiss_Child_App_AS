
import React from 'react';
import { ApplicationData } from '../../../types';
import FormField from '../../ui/FormField';
import Button from '../../ui/Button';
import { YES_NO_OPTIONS } from '../../../constants';
import { useAppContext } from '../../../hooks/useAppContext';

interface Step7EmployeeCashBenefitsProps {
  formData: ApplicationData;
  onDataChange: (field: keyof ApplicationData, value: any) => void;
  onNext: () => void;
  onPrevious: () => void;
  isViewMode?: boolean; // Added
}

const Step7_EmployeeCashBenefits: React.FC<Step7EmployeeCashBenefitsProps> = ({ formData, onDataChange, onNext, onPrevious, isViewMode }) => {
  const { translate, theme } = useAppContext();

  const handleBenefitChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    onDataChange(e.target.name as keyof ApplicationData, e.target.value);
  };

  const handleYesNoChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value === "yes" ? true : e.target.value === "no" ? false : undefined;
    onDataChange('receivingCashBenefits', value);
    if (value === false) { 
        onDataChange('benefitType', '');
        onDataChange('benefitReceivedSince', '');
        onDataChange('benefitPaymentOffice', '');
    }
  };
  
  const valueForSelect = formData.receivingCashBenefits === true ? "yes" : formData.receivingCashBenefits === false ? "no" : "";

  const isNextDisabledInEditMode = formData.receivingCashBenefits === undefined || 
                        (formData.receivingCashBenefits === true && (!formData.benefitType || !formData.benefitReceivedSince || !formData.benefitPaymentOffice));
  const isNextDisabled = !isViewMode && isNextDisabledInEditMode;

  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">{translate('step7Title')}</h2>
      <FormField
        id="receivingCashBenefits"
        label={translate('step7Question')}
        as="select"
        options={YES_NO_OPTIONS}
        value={valueForSelect}
        onChange={handleYesNoChange}
        required={!isViewMode}
        placeholder={translate('pleaseSelect')}
        disabled={isViewMode} // Added
      />

      {formData.receivingCashBenefits && (
        <div className="mt-4 pt-4 border-t">
          <FormField
            id="benefitType"
            name="benefitType"
            label={translate('benefitType')}
            value={formData.benefitType || ''}
            onChange={handleBenefitChange}
            required={!isViewMode && formData.receivingCashBenefits}
            disabled={isViewMode} // Added
          />
          <FormField
            id="benefitReceivedSince"
            name="benefitReceivedSince"
            label={translate('benefitReceivedSince')}
            type="date"
            value={formData.benefitReceivedSince || ''}
            onChange={handleBenefitChange}
            required={!isViewMode && formData.receivingCashBenefits}
            disabled={isViewMode} // Added
          />
          <FormField
            id="benefitPaymentOffice"
            name="benefitPaymentOffice"
            label={translate('paymentOffice')}
            value={formData.benefitPaymentOffice || ''}
            onChange={handleBenefitChange}
            required={!isViewMode && formData.receivingCashBenefits}
            disabled={isViewMode} // Added
          />
        </div>
      )}
       {isViewMode && !formData.receivingCashBenefits && (
         <p className={`italic mt-4 ${theme === 'theme4' ? 'text-theme4-text-on-dark' : 'text-gray-600'}`}>{translate('notProvided')}</p>
       )}

      <div className="mt-6 flex justify-between">
        <Button onClick={onPrevious} variant="secondary">
          {translate('previous')}
        </Button>
        <Button onClick={onNext} disabled={isNextDisabled}>
          {translate('next')}
        </Button>
      </div>
    </div>
  );
};

export default Step7_EmployeeCashBenefits;
