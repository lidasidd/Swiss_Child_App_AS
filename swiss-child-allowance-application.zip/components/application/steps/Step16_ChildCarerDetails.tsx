
import React from 'react';
import { ApplicationData, CarerRelationshipType, ChildDetails } from '../../../types';
import FormField from '../../ui/FormField';
import Button from '../../ui/Button';
import { CARER_RELATIONSHIP_OPTIONS } from '../../../constants';
import { useAppContext } from '../../../hooks/useAppContext';

interface Step16ChildCarerDetailsProps {
  formData: ApplicationData;
  onDataChange: (field: keyof ApplicationData, value: any) => void;
  onNext: () => void;
  onPrevious: () => void;
  isViewMode?: boolean; // Added
}

const Step16_ChildCarerDetails: React.FC<Step16ChildCarerDetailsProps> = ({ formData, onDataChange, onNext, onPrevious, isViewMode }) => {
  const { translate, theme } = useAppContext();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    onDataChange(e.target.name as keyof ApplicationData, e.target.value);
  };

  const handleChildSelection = (childId: string) => {
    if (isViewMode) return;
    const currentSelection = formData.carerAppliesToChildIds || [];
    const newSelection = currentSelection.includes(childId)
        ? currentSelection.filter(id => id !== childId)
        : [...currentSelection, childId];
    onDataChange('carerAppliesToChildIds', newSelection);
  };
  
  const isNextDisabledInEditMode = 
    formData.carerAppliesToAllChildren === undefined ||
    (formData.carerAppliesToAllChildren === false && (!formData.carerAppliesToChildIds || formData.carerAppliesToChildIds.length === 0)) ||
    ![
      formData.carerLastName,
      formData.carerFirstName,
      formData.carerTelephone,
      formData.carerRelationship
    ].every(Boolean) ||
    (formData.carerRelationship === CarerRelationshipType.OTHER && !formData.carerRelationshipOtherText);
  const isNextDisabled = !isViewMode && isNextDisabledInEditMode;

  let checkboxLabelClass = 'text-gray-700';
  let checkboxContainerBorder = 'border-gray-200';
  let checkboxContainerBg = 'bg-gray-50';

  if (theme === 'theme2') {
    checkboxLabelClass = 'text-theme2-text';
    checkboxContainerBorder = 'border-theme2-accent3/50';
    checkboxContainerBg = 'bg-theme2-accent1/20';
  } else if (theme === 'theme3') {
    checkboxLabelClass = 'text-theme3-text-on-light';
    checkboxContainerBorder = 'border-slate-300';
    checkboxContainerBg = 'bg-slate-100';
  } else if (theme === 'theme4') {
    checkboxLabelClass = 'text-theme4-text-on-dark';
    checkboxContainerBorder = 'border-theme4-border';
    checkboxContainerBg = 'bg-theme4-secondary-bg/70';
  }


  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">{translate('step16Title')}</h2>
      <p className="mb-4 text-sm">{translate('step16Instruction')}</p>

       <FormField
            id="carerAppliesToAllChildren"
            name="carerAppliesToAllChildren"
            label={translate('carerAppliesToWhichChildren')}
            as="select"
            options={[{value: "true", labelKey: 'allChildren'}, {value: "false", labelKey: 'selectChildren'}]}
            value={formData.carerAppliesToAllChildren === true ? "true" : formData.carerAppliesToAllChildren === false ? "false" : ""}
            onChange={(e) => onDataChange('carerAppliesToAllChildren', e.target.value === "true")}
            required={!isViewMode}
            placeholder={translate('pleaseSelect')}
            disabled={isViewMode}
        />

        {formData.carerAppliesToAllChildren === false && formData.children.length > 0 && (
        <div className={`my-3 p-3 border rounded-md ${checkboxContainerBg} ${checkboxContainerBorder}`}>
            <p className={`text-sm font-medium mb-1 ${checkboxLabelClass}`}>{translate('selectApplicableChildren')}</p>
            {formData.children.map((child: ChildDetails) => (
            <label key={child.id} className="flex items-center space-x-2 my-1">
                <input
                type="checkbox"
                className={`form-checkbox h-4 w-4 rounded ${theme === 'theme4' ? 'bg-slate-600 border-slate-500 text-theme4-primary focus:ring-theme4-primary' : 'border-gray-300 text-indigo-600 focus:ring-indigo-500'}`}
                checked={(formData.carerAppliesToChildIds || []).includes(child.id)}
                onChange={() => handleChildSelection(child.id)}
                disabled={isViewMode}
                />
                <span className={checkboxLabelClass}>{child.firstName} {child.lastName}</span>
            </label>
            ))}
        </div>
        )}

      <FormField id="carerLastName" name="carerLastName" label={translate('carerLastName')} value={formData.carerLastName || ''} onChange={handleChange} required={!isViewMode} disabled={isViewMode} />
      <FormField id="carerFirstName" name="carerFirstName" label={translate('carerFirstName')} value={formData.carerFirstName || ''} onChange={handleChange} required={!isViewMode} disabled={isViewMode} />
      <FormField id="carerTelephone" name="carerTelephone" label={translate('carerTelephone')} type="tel" value={formData.carerTelephone || ''} onChange={handleChange} required={!isViewMode} disabled={isViewMode} />
      <FormField 
        id="carerRelationship" 
        name="carerRelationship" 
        label={translate('carerRelationship')} 
        as="select" 
        options={CARER_RELATIONSHIP_OPTIONS} 
        value={formData.carerRelationship || ''} 
        onChange={handleChange} 
        required={!isViewMode} 
        placeholder={translate('pleaseSelect')}
        disabled={isViewMode}
      />
      {formData.carerRelationship === CarerRelationshipType.OTHER && (
        <FormField id="carerRelationshipOtherText" name="carerRelationshipOtherText" label={translate('carerRelationshipOther')} value={formData.carerRelationshipOtherText || ''} onChange={handleChange} required={!isViewMode && formData.carerRelationship === CarerRelationshipType.OTHER} disabled={isViewMode} />
      )}
      {isViewMode && !formData.carerLastName && ( // Check if any carer details are provided in view mode
         <p className={`italic mt-4 ${theme === 'theme4' ? 'text-theme4-text-on-dark' : 'text-gray-600'}`}>{translate('notProvided')}</p>
      )}

      <div className="mt-6 flex justify-between">
        <Button onClick={onPrevious} variant="secondary">{translate('previous')}</Button>
        <Button onClick={onNext} disabled={isNextDisabled}>{translate('next')}</Button>
      </div>
    </div>
  );
};

export default Step16_ChildCarerDetails;