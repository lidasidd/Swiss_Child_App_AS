
import React from 'react';
import { ApplicationData } from '../../../types';
import FormField from '../../ui/FormField';
import Button from '../../ui/Button';
import { YES_NO_OPTIONS } from '../../../constants';
import { useAppContext } from '../../../hooks/useAppContext';

interface Step15ChildCarerQueryProps {
  formData: ApplicationData;
  onDataChange: (field: keyof ApplicationData, value: any) => void;
  onNext: () => void;
  onPrevious: () => void;
  isViewMode?: boolean; // Added
}

const Step15_ChildCarerQuery: React.FC<Step15ChildCarerQueryProps> = ({ formData, onDataChange, onNext, onPrevious, isViewMode }) => {
  const { translate } = useAppContext();

  const handleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value === "yes" ? true : e.target.value === "no" ? false : undefined;
    onDataChange('childLivesWithOtherCarer', value);
  };
  
  const valueForSelect = formData.childLivesWithOtherCarer === true ? "yes" : formData.childLivesWithOtherCarer === false ? "no" : "";
  const isNextDisabled = !isViewMode && formData.childLivesWithOtherCarer === undefined;

  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">{translate('step15Title')}</h2>
      <FormField
        id="childLivesWithOtherCarer"
        label={translate('step15Question')}
        as="select"
        options={YES_NO_OPTIONS}
        value={valueForSelect}
        onChange={handleChange}
        required={!isViewMode}
        placeholder={translate('pleaseSelect')}
        helpText={translate('step15HelpText')} 
        disabled={isViewMode} // Added
      />
      <div className="mt-6 flex justify-between">
        <Button onClick={onPrevious} variant="secondary">
          {translate('previous')}
        </Button>
        <Button onClick={onNext} disabled={isNextDisabled}>
          {translate('next')}
        </Button>
      </div>
    </div>
  );
};

export default Step15_ChildCarerQuery;