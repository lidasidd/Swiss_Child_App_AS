
import React from 'react';
import { ApplicationData } from '../../../types';
import FormField from '../../ui/FormField';
import Button from '../../ui/Button';
import { INCOME_COMPARISON_OPTIONS } from '../../../constants';
import { useAppContext } from '../../../hooks/useAppContext';

interface Step12SpouseEmployerDetailsProps {
  formData: ApplicationData;
  onDataChange: (field: keyof ApplicationData, value: any) => void;
  onNext: () => void;
  onPrevious: () => void;
  isViewMode?: boolean; // Added
}

const Step12_SpouseEmployerDetails: React.FC<Step12SpouseEmployerDetailsProps> = ({ formData, onDataChange, onNext, onPrevious, isViewMode }) => {
  const { translate, theme } = useAppContext();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    if (name === 'spouseEmploymentExtent') {
        onDataChange(name as keyof ApplicationData, parseInt(value, 10) || 0);
    } else {
        onDataChange(name as keyof ApplicationData, value);
    }
  };
  
  const isNextDisabledInEditMode = ![
    formData.spouseEmployerName,
    formData.spouseEmployerAddress,
    formData.spouseEmployerCantonCountry,
    formData.spouseEmploymentExtent,
    formData.spouseIncomeComparedToApplicant
  ].every(val => val !== undefined && val !== '' && (typeof val === 'number' ? val > 0 && val <=100 : true));
  const isNextDisabled = !isViewMode && isNextDisabledInEditMode;


  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">{translate('step12Title')}</h2>
      <p className="mb-4 text-sm">{translate('step12Instruction')}</p>
      
      <FormField
        id="spouseEmployerName"
        name="spouseEmployerName"
        label={translate('spouseEmployerName')}
        value={formData.spouseEmployerName || ''}
        onChange={handleChange}
        required={!isViewMode}
        disabled={isViewMode} // Added
      />
      <FormField
        id="spouseEmployerAddress"
        name="spouseEmployerAddress"
        label={translate('spouseEmployerAddress')}
        value={formData.spouseEmployerAddress || ''}
        onChange={handleChange}
        required={!isViewMode}
        disabled={isViewMode} // Added
      />
      <FormField
        id="spouseEmployerCantonCountry"
        name="spouseEmployerCantonCountry"
        label={translate('spouseEmployerCantonCountry')}
        value={formData.spouseEmployerCantonCountry || ''}
        onChange={handleChange}
        required={!isViewMode}
        disabled={isViewMode} // Added
      />
      <FormField
        id="spouseEmploymentExtent"
        name="spouseEmploymentExtent"
        label={translate('spouseEmploymentExtent')}
        type="number"
        value={formData.spouseEmploymentExtent || ''}
        onChange={handleChange}
        required={!isViewMode}
        helpText={translate('spouseEmploymentExtentHelp')}
        disabled={isViewMode} // Added
      />
      <FormField
        id="spouseIncomeComparedToApplicant"
        name="spouseIncomeComparedToApplicant"
        label={translate('spouseIncomeComparison')}
        as="select"
        options={INCOME_COMPARISON_OPTIONS}
        value={formData.spouseIncomeComparedToApplicant || ''}
        onChange={handleChange}
        required={!isViewMode}
        placeholder={translate('pleaseSelect')}
        disabled={isViewMode} // Added
      />
      {isViewMode && !formData.spouseEmployerName && (
         <p className={`italic mt-4 ${theme === 'theme4' ? 'text-theme4-text-on-dark' : 'text-gray-600'}`}>{translate('notProvided')}</p>
      )}

      <div className="mt-6 flex justify-between">
        <Button onClick={onPrevious} variant="secondary">
          {translate('previous')}
        </Button>
        <Button onClick={onNext} disabled={isNextDisabled}>
          {translate('next')}
        </Button>
      </div>
    </div>
  );
};

export default Step12_SpouseEmployerDetails;