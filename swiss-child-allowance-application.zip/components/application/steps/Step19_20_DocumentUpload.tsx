
import React from 'react';
import { ApplicationData, MaritalStatus, UploadedFile, ChildDetails } from '../../../types';
import FileUpload from '../../ui/FileUpload';
import Button from '../../ui/Button';
import { useAppContext } from '../../../hooks/useAppContext';

interface Step19_20_DocumentUploadProps {
  formData: ApplicationData;
  onDataChange: (field: keyof ApplicationData | 'children', value: any) => void; 
  onNext: () => void;
  onPrevious: () => void;
  isViewMode?: boolean; // Added
}

const Step19_20_DocumentUpload: React.FC<Step19_20_DocumentUploadProps> = ({ formData, onDataChange, onNext, onPrevious, isViewMode }) => {
  const { translate, theme } = useAppContext();
  
  const needsEducationConfirmation = formData.children.some(child => {
    if (!child.dateOfBirth) return false;
    const birthDate = new Date(child.dateOfBirth);
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }
    return age >= 15;
  });

  const handleChildBirthCertificateChange = (childId: string, files: UploadedFile[]) => {
    const updatedChildren = formData.children.map(c => {
      if (c.id === childId) {
        return { ...c, birthCertificate: files.length > 0 ? files[0] : undefined };
      }
      return c;
    });
    onDataChange('children', updatedChildren);
  };
  
  const handleSingleFileChange = (field: keyof ApplicationData, files: UploadedFile[]) => {
    onDataChange(field, files.length > 0 ? files[0] : undefined);
  };

  const handleMultipleFileChange = (field: keyof ApplicationData, files: UploadedFile[]) => {
    onDataChange(field, files);
  };
  
  const areDocumentsValidInEditMode = () => {
    if (formData.children.length > 0) {
      const allBirthCertsUploaded = formData.children.every(child => !!child.birthCertificate);
      if (!allBirthCertsUploaded) return false; 
    }
    if (formData.maritalStatus === MaritalStatus.MARRIED && !formData.marriageCertificate) return false;
    if (formData.maritalStatus === MaritalStatus.DIVORCED && !formData.divorceDecree) return false;
    if (needsEducationConfirmation && (!formData.educationConfirmations || formData.educationConfirmations.length === 0)) return false;
    return true;
  };

  const isNextDisabled = !isViewMode && !areDocumentsValidInEditMode();

  let sectionBorder = 'border-gray-200';
  let sectionBg = 'bg-white'; 
  let completedSectionBg = 'bg-green-100/60';
  let completedSectionBorder = 'border-green-500';
  let infoBoxBg = 'bg-blue-50';
  let infoBoxBorder = 'border-blue-200';
  let infoBoxText = 'text-blue-700';


  if (theme === 'theme2') {
    sectionBorder = 'border-theme2-accent3/40';
    sectionBg = 'bg-theme2-accent1/20';
    completedSectionBg = 'bg-green-100/60';
    completedSectionBorder = 'border-green-500';
    infoBoxBg = 'bg-blue-50';
    infoBoxBorder = 'border-blue-200';
    infoBoxText = 'text-blue-700';
  } else if (theme === 'theme3') {
    sectionBorder = 'border-slate-300';
    sectionBg = 'bg-slate-100/50';
    completedSectionBg = 'bg-green-200/50';
    completedSectionBorder = 'border-green-600';
    infoBoxBg = 'bg-blue-100'; 
    infoBoxBorder = 'border-blue-300';
    infoBoxText = 'text-blue-800';
  } else if (theme === 'theme4') {
    sectionBorder = 'border-theme4-border';
    sectionBg = 'bg-theme4-secondary-bg/70'; 
    completedSectionBg = 'bg-green-700/30'; 
    completedSectionBorder = 'border-green-500';
    infoBoxBg = 'bg-sky-700/30'; 
    infoBoxBorder = 'border-sky-500';
    infoBoxText = 'text-sky-300';
  }
  const defaultSectionClasses = `mt-3 mb-2 p-3 border rounded-md ${sectionBg} ${sectionBorder}`;
  const completedSectionDynamicClasses = `${defaultSectionClasses} ${completedSectionBg} ${completedSectionBorder}`;


  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">{translate('documentUploadTitle')}</h2>
      <p className="mb-6 text-sm">{translate('documentUploadInstruction')}</p>

      {formData.children.length > 0 && (
        <div className="mb-6">
          <h3 className="text-md font-semibold mb-2 py-2 border-b">{translate('birthCertificatesSectionTitle')}</h3>
          {formData.children.map((child: ChildDetails) => {
            const isChildCertUploaded = !!child.birthCertificate;
            const sectionDynamicClasses = !isViewMode && isChildCertUploaded ? completedSectionDynamicClasses : defaultSectionClasses;
            return (
                <div key={child.id} className={sectionDynamicClasses}>
                <FileUpload
                    id={`birthCertificate-${child.id}`}
                    label={`${translate('birthCertificateForChildLabel')} ${child.firstName} ${child.lastName}`}
                    onFilesChange={(files) => handleChildBirthCertificateChange(child.id, files)}
                    multiple={false} 
                    required={!isViewMode}
                    existingFiles={child.birthCertificate ? [child.birthCertificate] : []}
                    helpText={translate('birthCertificateHelpChild')}
                    disabled={isViewMode} // Added
                />
                </div>
            );
          })}
        </div>
      )}
      {isViewMode && formData.children.length === 0 && (
          <p className={`italic mb-6 ${theme === 'theme4' ? 'text-theme4-text-on-dark' : 'text-gray-600'}`}>{translate('notProvided')}</p>
      )}


      {formData.maritalStatus === MaritalStatus.MARRIED && (
        <div className={!isViewMode && formData.marriageCertificate ? completedSectionDynamicClasses : defaultSectionClasses}>
            <FileUpload
            id="marriageCertificate"
            label={translate('marriageCertificateLabel')}
            onFilesChange={(files) => handleSingleFileChange('marriageCertificate', files)}
            multiple={false}
            required={!isViewMode}
            existingFiles={formData.marriageCertificate ? [formData.marriageCertificate] : []}
            disabled={isViewMode} // Added
            />
        </div>
      )}

      {formData.maritalStatus === MaritalStatus.DIVORCED && (
        <div className={!isViewMode && formData.divorceDecree ? completedSectionDynamicClasses : defaultSectionClasses}>
            <FileUpload
            id="divorceDecree"
            label={translate('divorceDecreeLabel')}
            onFilesChange={(files) => handleSingleFileChange('divorceDecree', files)}
            multiple={false}
            required={!isViewMode}
            existingFiles={formData.divorceDecree ? [formData.divorceDecree] : []}
            disabled={isViewMode} // Added
            />
        </div>
      )}

      {needsEducationConfirmation && (
        <div className={!isViewMode && formData.educationConfirmations && formData.educationConfirmations.length > 0 ? completedSectionDynamicClasses : defaultSectionClasses}>
            <FileUpload
            id="educationConfirmations"
            label={translate('educationConfirmationsLabel')}
            onFilesChange={(files) => handleMultipleFileChange('educationConfirmations', files)}
            multiple
            required={!isViewMode}
            existingFiles={formData.educationConfirmations || []}
            helpText={translate('educationConfirmationsHelp')}
            disabled={isViewMode} // Added
            />
        </div>
      )}
      
      {!needsEducationConfirmation && formData.children.length > 0 && formData.children.every(c => {
          if (!c.dateOfBirth) return true; 
          const birthDate = new Date(c.dateOfBirth);
          const today = new Date();
          let age = today.getFullYear() - birthDate.getFullYear();
          const m = today.getMonth() - birthDate.getMonth();
          if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
              age--;
          }
          return age < 15;
      }) && (
          <p className={`text-sm my-4 p-3 rounded-md ${infoBoxBg} ${infoBoxBorder} ${infoBoxText}`}>
              {translate('noEducationConfirmationNeeded')}
          </p>
      )}


      <div className="mt-8 flex justify-between">
        <Button onClick={onPrevious} variant="secondary">
          {translate('previous')}
        </Button>
        <Button onClick={onNext} disabled={isNextDisabled}>
          {translate('next')}
        </Button>
      </div>
    </div>
  );
};

export default Step19_20_DocumentUpload;