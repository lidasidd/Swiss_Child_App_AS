
import React from 'react';
import { ApplicationData, MaritalStatus } from '../../../types';
import FormField from '../../ui/FormField';
import Button from '../../ui/Button';
import { MARITAL_STATUS_OPTIONS } from '../../../constants';
import { useAppContext } from '../../../hooks/useAppContext';

interface Step4PersonalDetailsProps {
  formData: ApplicationData;
  onDataChange: (field: keyof ApplicationData, value: any) => void;
  onNext: () => void;
  onPrevious: () => void;
  isViewMode?: boolean; // Added
}

const Step4_PersonalDetails: React.FC<Step4PersonalDetailsProps> = ({ formData, onDataChange, onNext, onPrevious, isViewMode }) => {
  const { translate } = useAppContext();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    onDataChange(e.target.name as keyof ApplicationData, e.target.value);
  };
  
  const isMaritalStatusSinceRequired = !isViewMode && formData.maritalStatus !== MaritalStatus.SINGLE;

  const isNextDisabledInEditMode = ![
    formData.addressStreet,
    formData.addressStreetNo,
    formData.addressPostCode,
    formData.addressTown,
    formData.telephone,
    formData.email,
    formData.maritalStatus,
    ...(isMaritalStatusSinceRequired ? [formData.maritalStatusSince] : []) 
  ].every(Boolean) || (isMaritalStatusSinceRequired && !formData.maritalStatusSince);

  const isNextDisabled = !isViewMode && isNextDisabledInEditMode;


  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">{translate('step4Title')}</h2>
      <p className="mb-4 text-sm">{translate('step4Instruction')}</p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4">
        <FormField
          id="addressStreet"
          name="addressStreet"
          label={translate('addressStreet')}
          value={formData.addressStreet || ''}
          onChange={handleChange}
          required={!isViewMode}
          helpText={translate('helpStreet')} 
          placeholder="Bahnhofstrasse"
          disabled={isViewMode}
        />
        <FormField
          id="addressStreetNo"
          name="addressStreetNo"
          label={translate('addressStreetNo')}
          value={formData.addressStreetNo || ''}
          onChange={handleChange}
          required={!isViewMode}
          helpText={translate('helpStreetNo')}
          placeholder="10A" 
          disabled={isViewMode}
        />
        <FormField
          id="addressPostCode"
          name="addressPostCode"
          label={translate('addressPostCode')}
          value={formData.addressPostCode || ''}
          onChange={handleChange}
          required={!isViewMode}
           helpText={translate('helpPostCode')}
           placeholder="8001"
           disabled={isViewMode}
        />
        <FormField
          id="addressTown"
          name="addressTown"
          label={translate('addressTown')}
          value={formData.addressTown || ''}
          onChange={handleChange}
          required={!isViewMode}
          helpText={translate('helpTown')}
          placeholder="Zürich"
          disabled={isViewMode}
        />
        <FormField
          id="addressCity"
          name="addressCity"
          label={translate('addressCity')}
          value={formData.addressCity || ''}
          onChange={handleChange}
          helpText={translate('helpCity')} 
          placeholder="Zürich"
          disabled={isViewMode}
        />
        <FormField
          id="telephone"
          name="telephone"
          label={translate('telephone')}
          type="tel"
          value={formData.telephone || ''}
          onChange={handleChange}
          required={!isViewMode}
          helpText={translate('helpTelephone')} 
          placeholder="+41 79 123 45 67"
          disabled={isViewMode}
        />
        <FormField
          id="email"
          name="email"
          label={translate('email')}
          type="email"
          value={formData.email || ''} 
          onChange={handleChange}
          required={!isViewMode}
          helpText={translate('helpEmail')} 
          placeholder="your.name@example.com"
          disabled={isViewMode}
        />
        <div className="md:col-span-2 grid md:grid-cols-2 gap-x-4">
            <FormField
            id="maritalStatus"
            name="maritalStatus"
            label={translate('maritalStatus')}
            as="select"
            options={MARITAL_STATUS_OPTIONS}
            value={formData.maritalStatus || ''}
            onChange={handleChange}
            required={!isViewMode}
            placeholder={translate('selectMaritalStatus')} 
            helpText={translate('helpMaritalStatus')}
            disabled={isViewMode}
            />
            <FormField
            id="maritalStatusSince"
            name="maritalStatusSince"
            label={translate('maritalStatusSince')}
            type="date"
            value={formData.maritalStatusSince || ''}
            onChange={handleChange}
            required={isMaritalStatusSinceRequired}
            disabled={isViewMode || !isMaritalStatusSinceRequired}
            helpText={translate('helpMaritalStatusSince')}
            placeholder="YYYY-MM-DD"
            />
        </div>
      </div>

      <div className="mt-6 flex justify-between">
        <Button onClick={onPrevious} variant="secondary">
          {translate('previous')}
        </Button>
        <Button onClick={onNext} disabled={isNextDisabled}>
          {translate('next')}
        </Button>
      </div>
    </div>
  );
};

export default Step4_PersonalDetails;