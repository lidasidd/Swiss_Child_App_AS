
import React from 'react';
import { ApplicationData } from '../../../types';
import FormField from '../../ui/FormField';
import Button from '../../ui/Button';
import { YES_NO_OPTIONS } from '../../../constants';
import { useAppContext } from '../../../hooks/useAppContext';

interface Step5OtherEmployersQueryProps {
  formData: ApplicationData;
  onDataChange: (field: keyof ApplicationData, value: any) => void;
  onNext: () => void;
  onPrevious: () => void;
  isViewMode?: boolean; // Added
}

const Step5_OtherEmployersQuery: React.FC<Step5OtherEmployersQueryProps> = ({ formData, onDataChange, onNext, onPrevious, isViewMode }) => {
  const { translate } = useAppContext();

  const handleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value === "yes" ? true : e.target.value === "no" ? false : undefined;
    onDataChange('hasOtherEmployers', value);
  };

  const valueForSelect = formData.hasOtherEmployers === true ? "yes" : formData.hasOtherEmployers === false ? "no" : "";

  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">{translate('step5Title')}</h2>
      <FormField
        id="hasOtherEmployers"
        label={translate('step5Question')}
        as="select"
        options={YES_NO_OPTIONS}
        value={valueForSelect}
        onChange={handleChange}
        required={!isViewMode}
        placeholder={translate('pleaseSelect')}
        disabled={isViewMode} // Added
      />
      <div className="mt-6 flex justify-between">
        <Button onClick={onPrevious} variant="secondary">
          {translate('previous')}
        </Button>
        <Button onClick={onNext} disabled={!isViewMode && formData.hasOtherEmployers === undefined}>
          {translate('next')}
        </Button>
      </div>
    </div>
  );
};

export default Step5_OtherEmployersQuery;