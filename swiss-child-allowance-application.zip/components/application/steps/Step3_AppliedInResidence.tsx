
import React, { useState } from 'react';
import { ApplicationData } from '../../../types';
import FormField from '../../ui/FormField';
import Button from '../../ui/Button';
import Modal from '../../ui/Modal';
import { YES_NO_OPTIONS } from '../../../constants';
import { useAppContext } from '../../../hooks/useAppContext';

interface Step3AppliedInResidenceProps {
  formData: ApplicationData;
  onDataChange: (field: keyof ApplicationData, value: any) => void;
  onNext: () => void;
  onPrevious: () => void;
  isViewMode?: boolean; // Added
}

const Step3_AppliedInResidence: React.FC<Step3AppliedInResidenceProps> = ({ formData, onDataChange, onNext, onPrevious, isViewMode }) => {
  const { translate } = useAppContext();
  const [showApplyFirstModal, setShowApplyFirstModal] = useState(false);

  const handleNext = () => {
    if (!isViewMode && formData.appliedInResidenceCountry === false) { 
      setShowApplyFirstModal(true);
    } else if (isViewMode || formData.appliedInResidenceCountry === true) {
      onNext();
    }
  };

  const handleModalClose = () => {
    setShowApplyFirstModal(false);
  };

  const handleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value === "yes" ? true : e.target.value === "no" ? false : undefined;
    onDataChange('appliedInResidenceCountry', value);
  };
  
  const valueForSelect = formData.appliedInResidenceCountry === true ? "yes" : formData.appliedInResidenceCountry === false ? "no" : "";

  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">{translate('step3Title')}</h2>
      <FormField
        id="appliedInResidenceCountry"
        label={translate('step3Question')}
        as="select"
        options={YES_NO_OPTIONS}
        value={valueForSelect}
        onChange={handleChange}
        required={!isViewMode}
        placeholder={translate('pleaseSelect')}
        disabled={isViewMode} // Added
      />

      <div className="mt-6 flex justify-between">
        <Button onClick={onPrevious} variant="secondary">
          {translate('previous')}
        </Button>
        <Button onClick={handleNext} disabled={!isViewMode && formData.appliedInResidenceCountry === undefined}>
          {translate('next')}
        </Button>
      </div>

      {!isViewMode && (
        <Modal
            isOpen={showApplyFirstModal}
            onClose={handleModalClose}
            title={translate('applicationRequirementTitle')}
            showOkButton={true}
            okText={translate('close')}
            onOk={handleModalClose}
        >
            <p>{translate('step3ApplyFirstMessage')}</p>
        </Modal>
      )}
    </div>
  );
};

export default Step3_AppliedInResidence;