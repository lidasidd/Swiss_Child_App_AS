
import React, { useState } from 'react';
import { ApplicationData, OtherEmployer, IncomeComparison } from '../../../types';
import FormField from '../../ui/FormField';
import Button from '../../ui/Button';
import Modal from '../../ui/Modal';
import { INCOME_COMPARISON_OPTIONS } from '../../../constants';
import { useAppContext } from '../../../hooks/useAppContext';

interface Step6OtherEmployerDetailsProps {
  formData: ApplicationData;
  onDataChange: (field: keyof ApplicationData, value: any) => void;
  onNext: () => void;
  onPrevious: () => void;
  isViewMode?: boolean; // Added
}

const Step6_OtherEmployerDetails: React.FC<Step6OtherEmployerDetailsProps> = ({ formData, onDataChange, onNext, onPrevious, isViewMode }) => {
  const { translate, theme } = useAppContext();
  const [showIncomeRuleModal, setShowIncomeRuleModal] = useState(false);

  const handleEmployerChange = (index: number, field: keyof OtherEmployer, value: any) => {
    const updatedEmployers = [...formData.otherEmployers];
    updatedEmployers[index] = { ...updatedEmployers[index], [field]: value };
    onDataChange('otherEmployers', updatedEmployers);

    if (!isViewMode && field === 'incomeComparedToViking' && value === IncomeComparison.HIGHER) {
      setShowIncomeRuleModal(true);
    }
  };

  const addEmployer = () => {
    if (isViewMode) return;
    const newEmployer: OtherEmployer = {
      id: `otherEmployer-${Date.now()}`,
      name: '',
      address: '',
      incomeComparedToViking: undefined,
    };
    onDataChange('otherEmployers', [...formData.otherEmployers, newEmployer]);
  };

  const removeEmployer = (index: number) => {
    if (isViewMode) return;
    const updatedEmployers = formData.otherEmployers.filter((_, i) => i !== index);
    onDataChange('otherEmployers', updatedEmployers);
  };

  const isNextDisabledInEditMode = formData.otherEmployers.some(emp => !emp.name || !emp.address || emp.incomeComparedToViking === undefined) || formData.otherEmployers.length === 0;
  
  const canProceedInEditMode = !formData.otherEmployers.some(emp => emp.incomeComparedToViking === IncomeComparison.HIGHER);
  
  const isNextDisabled = !isViewMode && (isNextDisabledInEditMode || !canProceedInEditMode);


  const handleModalClose = () => {
    setShowIncomeRuleModal(false);
  };
  
  let employerCardBg = 'bg-gray-50';
  let employerCardBorder = 'border-gray-200';

  if (theme === 'theme2') {
    employerCardBg = 'bg-theme2-accent1/30';
    employerCardBorder = 'border-theme2-accent3/50';
  } else if (theme === 'theme3') {
    employerCardBg = 'bg-slate-100';
    employerCardBorder = 'border-slate-300';
  } else if (theme === 'theme4') {
    employerCardBg = 'bg-theme4-secondary-bg/70'; 
    employerCardBorder = 'border-theme4-border';
  }


  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">{translate('step6Title')}</h2>
      <p className="mb-4 text-sm">{translate('step6Instruction')}</p>

      {formData.otherEmployers.map((employer, index) => (
        <div key={employer.id} className={`p-4 border rounded-md mb-4 shadow-sm relative ${employerCardBg} ${employerCardBorder}`}>
          <h3 className="text-lg font-medium mb-2">{translate('employer')} {index + 1}</h3>
           {!isViewMode && (
            <Button
                variant="danger"
                size="sm"
                onClick={() => removeEmployer(index)}
                className="absolute top-2 right-2 px-2 py-1"
            >
                X
            </Button>
           )}
          <FormField
            id={`employerName-${index}`}
            label={translate('employerName')}
            value={employer.name}
            onChange={(e) => handleEmployerChange(index, 'name', e.target.value)}
            required={!isViewMode}
            disabled={isViewMode}
          />
          <FormField
            id={`employerAddress-${index}`}
            label={translate('employerAddress')}
            value={employer.address}
            onChange={(e) => handleEmployerChange(index, 'address', e.target.value)}
            required={!isViewMode}
            disabled={isViewMode}
          />
          <FormField
            id={`incomeCompared-${index}`}
            label={translate('incomeAtOtherEmployer')}
            as="select"
            options={INCOME_COMPARISON_OPTIONS}
            value={employer.incomeComparedToViking || ''}
            onChange={(e) => handleEmployerChange(index, 'incomeComparedToViking', e.target.value as IncomeComparison)}
            required={!isViewMode}
            placeholder={translate('pleaseSelect')}
            disabled={isViewMode}
          />
        </div>
      ))}

      {!isViewMode && (
        <Button onClick={addEmployer} variant="secondary" className="mb-6">
            {translate('addAnotherEmployer')}
        </Button>
      )}
      {isViewMode && formData.otherEmployers.length === 0 && (
        <p className={`italic ${theme === 'theme4' ? 'text-theme4-text-on-dark' : 'text-gray-600'}`}>{translate('notProvided')}</p>
      )}


      <div className="mt-6 flex justify-between">
        <Button onClick={onPrevious} variant="secondary">
          {translate('previous')}
        </Button>
        <Button onClick={onNext} disabled={isNextDisabled}>
          {translate('next')}
        </Button>
      </div>
      
      {!isViewMode && (
        <Modal
            isOpen={showIncomeRuleModal}
            onClose={handleModalClose}
            title={translate('importantNotice')}
            showOkButton={true}
            okText={translate('close')}
            onOk={handleModalClose}
        >
            <p>{translate('highestSalaryRule')}</p>
        </Modal>
      )}
    </div>
  );
};

export default Step6_OtherEmployerDetails;