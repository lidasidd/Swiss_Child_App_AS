
import React from 'react';
import { ApplicationData } from '../../../types';
import FormField from '../../ui/FormField';
import Button from '../../ui/Button';
import { YES_NO_OPTIONS, SWISS_CANTONS } from '../../../constants';
import { useAppContext } from '../../../hooks/useAppContext';

interface Step17PreviousAllowancesProps {
  formData: ApplicationData;
  onDataChange: (field: keyof ApplicationData, value: any) => void;
  onNext: () => void;
  onPrevious: () => void;
  isViewMode?: boolean; // Added
}

const Step17_PreviousAllowances: React.FC<Step17PreviousAllowancesProps> = ({ formData, onDataChange, onNext, onPrevious, isViewMode }) => {
  const { translate, theme } = useAppContext();

  const handleYesNoChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value === "yes" ? true : e.target.value === "no" ? false : undefined;
    onDataChange('receivedSwissChildAllowancesBefore', value);
    if (value === false) { 
        onDataChange('previousAllowanceCanton', '');
        onDataChange('previousAllowanceUntilDate', '');
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    onDataChange(e.target.name as keyof ApplicationData, e.target.value);
  };
  
  const valueForSelect = formData.receivedSwissChildAllowancesBefore === true ? "yes" : formData.receivedSwissChildAllowancesBefore === false ? "no" : "";

  const isNextDisabledInEditMode = formData.receivedSwissChildAllowancesBefore === undefined ||
                        (formData.receivedSwissChildAllowancesBefore === true && (!formData.previousAllowanceCanton || !formData.previousAllowanceUntilDate));
  const isNextDisabled = !isViewMode && isNextDisabledInEditMode;

  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">{translate('step17Title')}</h2>
      <FormField
        id="receivedSwissChildAllowancesBefore"
        label={translate('step17Question')}
        as="select"
        options={YES_NO_OPTIONS}
        value={valueForSelect}
        onChange={handleYesNoChange}
        required={!isViewMode}
        placeholder={translate('pleaseSelect')}
        disabled={isViewMode} // Added
      />

      {formData.receivedSwissChildAllowancesBefore && (
        <div className="mt-4 pt-4 border-t">
          <FormField
            id="previousAllowanceCanton"
            name="previousAllowanceCanton"
            label={translate('whichCanton')}
            as="select"
            options={SWISS_CANTONS} 
            value={formData.previousAllowanceCanton || ''}
            onChange={handleChange}
            required={!isViewMode && formData.receivedSwissChildAllowancesBefore}
            placeholder={translate('selectCanton')}
            disabled={isViewMode} // Added
          />
          <FormField
            id="previousAllowanceUntilDate"
            name="previousAllowanceUntilDate"
            label={translate('untilWhen')}
            type="date"
            value={formData.previousAllowanceUntilDate || ''}
            onChange={handleChange}
            required={!isViewMode && formData.receivedSwissChildAllowancesBefore}
            disabled={isViewMode} // Added
          />
        </div>
      )}
      {isViewMode && !formData.receivedSwissChildAllowancesBefore && (
         <p className={`italic mt-4 ${theme === 'theme4' ? 'text-theme4-text-on-dark' : 'text-gray-600'}`}>{translate('notProvided')}</p>
      )}

      <div className="mt-6 flex justify-between">
        <Button onClick={onPrevious} variant="secondary">
          {translate('previous')}
        </Button>
        <Button onClick={onNext} disabled={isNextDisabled}>
          {translate('next')}
        </Button>
      </div>
    </div>
  );
};

export default Step17_PreviousAllowances;