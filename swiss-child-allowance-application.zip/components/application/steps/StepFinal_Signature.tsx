
import React from 'react';
import { ApplicationData } from '../../../types';
import FormField from '../../ui/FormField';
import Button from '../../ui/Button';
import { useAppContext } from '../../../hooks/useAppContext';

interface StepFinalSignatureProps {
  formData: ApplicationData;
  onDataChange: (field: keyof ApplicationData, value: any) => void;
  onSubmit: () => void;
  onPrevious: () => void;
  isViewMode?: boolean; // Added
}

const StepFinal_Signature: React.FC<StepFinalSignatureProps> = ({ formData, onDataChange, onSubmit, onPrevious, isViewMode }) => {
  const { translate, user, theme } = useAppContext();

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onDataChange(e.target.name as keyof ApplicationData, e.target.value);
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onDataChange('informationConfirmed', e.target.checked);
  };

  React.useEffect(() => {
    if (!isViewMode && user && !formData.signatureName) {
      onDataChange('signatureName', user.name);
    }
    if (!isViewMode && !formData.signatureDate) {
      onDataChange('signatureDate', new Date().toISOString().split('T')[0]); 
    }
  }, [user, formData.signatureName, formData.signatureDate, onDataChange, isViewMode]);
  
  const isSubmitDisabled = !isViewMode && (!formData.signatureName || !formData.signatureDate || !formData.informationConfirmed);
  
  let checkboxLabelColor = 'text-gray-700'; 
  if (theme === 'theme2') checkboxLabelColor = 'text-theme2-text';
  else if (theme === 'theme3') checkboxLabelColor = 'text-theme3-text-on-light';
  else if (theme === 'theme4') checkboxLabelColor = 'text-theme4-text-on-dark';


  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">{translate('step20Title')}</h2>
      <p className="mb-4 text-sm">
        {translate('step20Instruction')}
      </p>
      
      <FormField
        id="signatureName"
        name="signatureName"
        label={translate('signatureName')}
        value={formData.signatureName || ''}
        onChange={handleInputChange}
        required={!isViewMode}
        helpText={translate('signatureNameHelp')}
        disabled={isViewMode} // Added
      />
      <FormField
        id="signatureDate"
        name="signatureDate"
        label={translate('signatureDate')}
        type="date"
        value={formData.signatureDate || ''}
        onChange={handleInputChange}
        required={!isViewMode}
        helpText={translate('signatureDateHelp')}
        disabled={isViewMode} // Added
      />

      <div className="mt-6 mb-4">
        <label htmlFor="informationConfirmed" className="flex items-center">
          <input
            type="checkbox"
            id="informationConfirmed"
            name="informationConfirmed"
            checked={!!formData.informationConfirmed}
            onChange={handleCheckboxChange}
            className={`h-4 w-4 rounded border-gray-300 ${theme === 'theme4' ? 'bg-slate-600 border-slate-500 checked:bg-theme4-primary focus:ring-theme4-primary' : 'text-indigo-600 focus:ring-indigo-500'}`}
            disabled={isViewMode} // Added
          />
          <span className={`ml-2 text-sm ${checkboxLabelColor}`}>
            {translate('informationConfirmationLabel')}
          </span>
        </label>
      </div>


      <div className="mt-8 flex justify-between">
        <Button onClick={onPrevious} variant="secondary">
          {translate('previous')}
        </Button>
        {!isViewMode && (
          <Button onClick={onSubmit} variant="primary" isLoading={false} disabled={isSubmitDisabled}>
            {translate('submit')}
          </Button>
        )}
      </div>
    </div>
  );
};

export default StepFinal_Signature;