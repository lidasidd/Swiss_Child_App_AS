
import React from 'react';
import { ApplicationData, ChildDetails, Gender, RelationshipToApplicant } from '../../../types';
import FormField from '../../ui/FormField';
import Button from '../../ui/Button';
import { GENDER_OPTIONS, RELATIONSHIP_OPTIONS } from '../../../constants';
import { useAppContext } from '../../../hooks/useAppContext';

interface Step13ChildrenDetailsProps {
  formData: ApplicationData;
  onDataChange: (field: keyof ApplicationData, value: any) => void;
  onNext: () => void;
  onPrevious: () => void;
  isViewMode?: boolean; // Added
}

const Step13_ChildrenDetails: React.FC<Step13ChildrenDetailsProps> = ({ formData, onDataChange, onNext, onPrevious, isViewMode }) => {
  const { translate, theme } = useAppContext();

  const handleChildChange = (index: number, field: keyof ChildDetails, value: any) => {
    const updatedChildren = [...formData.children];
    updatedChildren[index] = { ...updatedChildren[index], [field]: value };
    onDataChange('children', updatedChildren);
  };

  const addChild = () => {
    if (isViewMode) return;
    const newChild: ChildDetails = {
      id: `child-${Date.now()}`,
      lastName: '',
      firstName: '',
      dateOfBirth: '',
      gender: Gender.FEMALE, 
      address: '',
      placeOfResidence: '',
      relationshipToApplicant: RelationshipToApplicant.OWN_OR_ADOPTED, 
    };
    onDataChange('children', [...formData.children, newChild]);
  };

  const removeChild = (index: number) => {
    if (isViewMode) return;
    const updatedChildren = formData.children.filter((_, i) => i !== index);
    onDataChange('children', updatedChildren);
  };

  const areChildrenDetailsValid = () => {
    if (formData.children.length === 0) return false; 
    return formData.children.every(child => 
      child.firstName && child.lastName && child.dateOfBirth && child.address && child.placeOfResidence && child.relationshipToApplicant
    );
  };
  
  const isNextDisabled = !isViewMode && !areChildrenDetailsValid();

  let childCardBg = 'bg-gray-50';
  let childCardBorder = 'border-gray-200';

  if (theme === 'theme2') {
    childCardBg = 'bg-theme2-accent1/30';
    childCardBorder = 'border-theme2-accent3/50';
  } else if (theme === 'theme3') {
    childCardBg = 'bg-slate-100'; 
    childCardBorder = 'border-slate-300';
  } else if (theme === 'theme4') {
    childCardBg = 'bg-theme4-secondary-bg/70'; 
    childCardBorder = 'border-theme4-border';
  }


  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">{translate('step13Title')}</h2>
      <p className="mb-4 text-sm">{translate('step13Instruction')}</p>

      {formData.children.map((child, index) => (
        <div key={child.id} className={`p-4 border rounded-md mb-4 shadow-sm relative ${childCardBg} ${childCardBorder}`}>
          <h3 className="text-lg font-medium mb-2">{translate('child')} {index + 1}</h3>
          {!isViewMode && formData.children.length > 0 && ( 
            <Button
              variant="danger"
              size="sm"
              onClick={() => removeChild(index)}
              className="absolute top-2 right-2 px-2 py-1"
              disabled={isViewMode}
            >
              X
            </Button>
          )}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4">
            <FormField
              id={`childLastName-${index}`}
              label={translate('lastName')}
              value={child.lastName}
              onChange={(e) => handleChildChange(index, 'lastName', e.target.value)}
              required={!isViewMode}
              disabled={isViewMode}
            />
            <FormField
              id={`childFirstName-${index}`}
              label={translate('firstName')}
              value={child.firstName}
              onChange={(e) => handleChildChange(index, 'firstName', e.target.value)}
              required={!isViewMode}
              disabled={isViewMode}
            />
            <FormField
              id={`childDob-${index}`}
              label={translate('dateOfBirth')}
              type="date"
              value={child.dateOfBirth}
              onChange={(e) => handleChildChange(index, 'dateOfBirth', e.target.value)}
              required={!isViewMode}
              disabled={isViewMode}
            />
            <FormField
              id={`childGender-${index}`}
              label={translate('gender')}
              as="select"
              options={GENDER_OPTIONS}
              value={child.gender}
              onChange={(e) => handleChildChange(index, 'gender', e.target.value as Gender)}
              required={!isViewMode}
              disabled={isViewMode}
            />
            <FormField
              id={`childAddress-${index}`}
              label={translate('address')}
              value={child.address}
              onChange={(e) => handleChildChange(index, 'address', e.target.value)}
              required={!isViewMode}
              helpText={translate('childAddressHelp')}
              disabled={isViewMode}
            />
            <FormField
              id={`childPlaceOfResidence-${index}`}
              label={translate('placeOfResidence')}
              value={child.placeOfResidence}
              onChange={(e) => handleChildChange(index, 'placeOfResidence', e.target.value)}
              required={!isViewMode}
              helpText={translate('childPlaceHelp')}
              disabled={isViewMode}
            />
             <FormField
              id={`childRelationship-${index}`}
              label={translate('relationshipToApplicant')}
              as="select"
              options={RELATIONSHIP_OPTIONS}
              value={child.relationshipToApplicant}
              onChange={(e) => handleChildChange(index, 'relationshipToApplicant', e.target.value as RelationshipToApplicant)}
              required={!isViewMode}
              disabled={isViewMode}
            />
          </div>
        </div>
      ))}

      {!isViewMode && (
        <Button onClick={addChild} variant="secondary" className="mb-6" disabled={isViewMode}>
            {translate('addChildButton')}
        </Button>
      )}
      {isViewMode && formData.children.length === 0 && (
         <p className={`italic ${theme === 'theme4' ? 'text-theme4-text-on-dark' : 'text-gray-600'}`}>{translate('notProvided')}</p>
      )}
      
      {!isViewMode && <p className="mb-4 text-sm font-medium">{translate('allChildrenEnteredQuery')}</p>}


      <div className="mt-6 flex justify-between">
        <Button onClick={onPrevious} variant="secondary">
          {translate('previous')}
        </Button>
        <Button onClick={onNext} disabled={isNextDisabled}>
          {translate('next')}
        </Button>
      </div>
    </div>
  );
};

export default Step13_ChildrenDetails;