
import React from 'react';
import { ApplicationData } from '../../../types';
import FormField from '../../ui/FormField';
import Button from '../../ui/Button';
import { YES_NO_OPTIONS } from '../../../constants';
import { useAppContext } from '../../../hooks/useAppContext';

interface Step18ChildAgeQueryProps {
  formData: ApplicationData;
  onDataChange: (field: keyof ApplicationData, value: any) => void;
  onNext: () => void;
  onPrevious: () => void;
  isViewMode?: boolean; // Added
}

const Step18_ChildAgeQuery: React.FC<Step18ChildAgeQueryProps> = ({ formData, onDataChange, onNext, onPrevious, isViewMode }) => {
  const { translate } = useAppContext();

  const handleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value === "yes" ? true : e.target.value === "no" ? false : undefined;
    onDataChange('confirmChildOver15', value);
  };
  
  const valueForSelect = formData.confirmChildOver15 === true ? "yes" : formData.confirmChildOver15 === false ? "no" : "";

  const isNextDisabled = !isViewMode && formData.confirmChildOver15 === undefined;

  const showWarning = formData.confirmChildOver15 === false && formData.children.some(child => {
        if (!child.dateOfBirth) return false;
        const birthDate = new Date(child.dateOfBirth);
        const today = new Date();
        let age = today.getFullYear() - birthDate.getFullYear();
        const m = today.getMonth() - birthDate.getMonth();
        if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
            age--;
        }
        return age >= 15;
    });

  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">{translate('step18Title')}</h2>
      <FormField
        id="confirmChildOver15"
        label={translate('step18Question')}
        as="select"
        options={YES_NO_OPTIONS}
        value={valueForSelect}
        onChange={handleChange}
        required={!isViewMode}
        placeholder={translate('pleaseSelect')}
        disabled={isViewMode} // Added
      />
      {formData.confirmChildOver15 === true && (
          <p className="mt-2 text-sm text-blue-600 bg-blue-50 p-3 rounded-md border border-blue-200">{translate('step18Info')}</p>
      )}
       {showWarning && (
          <p className="mt-2 text-sm text-yellow-600 bg-yellow-50 p-3 rounded-md border border-yellow-200">
            {translate('childOver15Warning')}
          </p>
        )}


      <div className="mt-6 flex justify-between">
        <Button onClick={onPrevious} variant="secondary">
          {translate('previous')}
        </Button>
        <Button onClick={onNext} disabled={isNextDisabled}>
          {translate('next')}
        </Button>
      </div>
    </div>
  );
};

export default Step18_ChildAgeQuery;