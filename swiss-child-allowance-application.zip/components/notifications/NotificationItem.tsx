import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Notification, NotificationType } from '../../types';
import { useAppContext } from '../../hooks/useAppContext';

interface NotificationItemProps {
  notification: Notification;
  onRead: () => void; // Callback to close panel after read (optional)
}

// SVG Icons
const InfoIcon: React.FC<{className?: string}> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M11.25 11.25l.041-.02a.75.75 0 011.063.852l-.708 2.836a.75.75 0 001.063.853l.041-.021M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9-3.75h.008v.008H12V8.25z" />
  </svg>
);

const AlertIcon: React.FC<{className?: string}> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.008v.008H12v-.008z" />
  </svg>
);

const SuccessIcon: React.FC<{className?: string}> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

const UpdateIcon: React.FC<{className?: string}> = ({ className }) => (
 <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
  <path strokeLinecap="round" strokeLinejoin="round" d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0l3.181 3.183a8.25 8.25 0 0013.803-3.7M4.031 9.865a8.25 8.25 0 0113.803-3.7l3.181 3.182m0-4.991v4.99" />
</svg>
);

const SystemIcon: React.FC<{className?: string}> = ({ className }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" d="M10.343 3.94c.09-.542.56-.94 1.11-.94h1.093c.55 0 1.02.398 1.11.94l.149.894c.07.424.384.764.78.93.398.164.855.142 1.205-.108l.737-.527a1.125 1.125 0 011.45.12l.773.774c.39.389.39 1.024 0 1.414l-.527.737c-.25.35-.272.806-.107 1.204.165.397.505.71.93.78l.893.15c.543.09.94.56.94 1.11v1.093c0 .55-.397 1.02-.94 1.11l-.893.149c-.425.07-.765.383-.93.78-.165.398-.143.854.107 1.204l.527.738c.39.39.39 1.024 0 1.414l-.773.774a1.125 1.125 0 01-1.449.12l-.738-.527c-.35-.25-.806-.272-1.203-.107-.398.165-.71.505-.78.93l-.15.894c-.09.542-.56.94-1.11.94h-1.094c-.55 0-1.019-.398-1.11-.94l-.149-.894c-.07-.424-.384-.764-.78-.93-.398-.164-.854-.142-1.204.108l-.738.527a1.125 1.125 0 01-1.45-.12l-.773-.774a1.125 1.125 0 010-1.414l.527-.737c.25-.35.273-.806.108-1.204-.165-.397-.506-.71-.93-.78l-.894-.15c-.542-.09-.94-.56-.94-1.11v-1.094c0-.55.398-1.02.94-1.11l.894-.149c.424-.07.765-.383.93-.78.165-.398.143-.854-.108-1.204l-.526-.738a1.125 1.125 0 01.12-1.45l.773-.774a1.125 1.125 0 011.45-.12l.737.527c.35.25.807.272 1.204.107.397-.165.71-.505.78-.93l.15-.894z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
  </svg>
);


const NotificationItem: React.FC<NotificationItemProps> = ({ notification, onRead }) => {
  const { markNotificationAsRead, translate, theme } = useAppContext();
  const navigate = useNavigate();

  const handleNotificationClick = () => {
    markNotificationAsRead(notification.id);
    if (notification.link) {
      navigate(notification.link, { state: notification.linkState });
    }
    onRead(); // Close panel after action
  };

  const timeSince = (dateString: string): string => {
    const date = new Date(dateString);
    const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000);
    if (seconds < 5) return "just now";
    let interval = seconds / 31536000;
    if (interval > 1) return Math.floor(interval) + "y ago";
    interval = seconds / 2592000;
    if (interval > 1) return Math.floor(interval) + "mo ago";
    interval = seconds / 86400;
    if (interval > 1) return Math.floor(interval) + "d ago";
    interval = seconds / 3600;
    if (interval > 1) return Math.floor(interval) + "h ago";
    interval = seconds / 60;
    if (interval > 1) return Math.floor(interval) + "m ago";
    return Math.floor(seconds) + "s ago";
  };
  
  let itemHoverBg = 'hover:bg-gray-50';
  let messageColor = 'text-gray-700';
  let timestampColor = 'text-gray-500';
  let linkColor = 'text-blue-600 hover:text-blue-700';
  let iconColor = 'text-gray-400';

  if (theme === 'theme2') {
    itemHoverBg = 'hover:bg-theme2-accent1/40';
    messageColor = 'text-theme2-text';
    timestampColor = 'text-theme2-text/70';
    linkColor = 'text-theme2-primary hover:text-blue-600';
    iconColor = 'text-theme2-primary';
  } else if (theme === 'theme3') {
    itemHoverBg = 'hover:bg-theme3-accent/20';
    messageColor = 'text-theme3-text-on-light';
    timestampColor = 'text-theme3-text-on-light/70';
    linkColor = 'text-blue-400 hover:text-blue-300';
    iconColor = 'text-theme3-accent';
  } else if (theme === 'theme4') {
    itemHoverBg = 'hover:bg-theme4-accent/20';
    messageColor = 'text-theme4-text-on-dark';
    timestampColor = 'text-theme4-text-on-dark/60';
    linkColor = 'text-theme4-primary hover:sky-400';
    iconColor = 'text-theme4-primary';
  }

  const getIcon = (type: NotificationType) => {
    const iconBaseClass = `w-5 h-5 mr-3 flex-shrink-0 ${iconColor}`;
    switch (type) {
      case 'info': return <InfoIcon className={iconBaseClass} />;
      case 'alert': return <AlertIcon className={`${iconBaseClass} ${theme === 'theme2' ? 'text-orange-500' : theme === 'theme3' ? 'text-yellow-400' : 'text-yellow-500'}`} />;
      case 'success': return <SuccessIcon className={`${iconBaseClass} ${theme === 'theme2' ? 'text-green-500' : theme === 'theme3' ? 'text-emerald-400' :'text-green-500'}`} />;
      case 'update': return <UpdateIcon className={iconBaseClass} />;
      case 'system': return <SystemIcon className={iconBaseClass} />;
      default: return <InfoIcon className={iconBaseClass} />;
    }
  };


  return (
    <li
      className={`p-3.5 cursor-pointer transition-colors duration-150 ${itemHoverBg} flex items-start`}
      onClick={handleNotificationClick}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') handleNotificationClick();}}
      aria-label={`${translate(notification.messageKey, notification.defaultMessage)} - ${timeSince(notification.timestamp)}`}
    >
      {getIcon(notification.type)}
      <div className="flex-grow">
        <p className={`text-sm ${messageColor} leading-snug`}>
          {translate(notification.messageKey, notification.defaultMessage)}
        </p>
        {notification.link && (
          <span className={`text-xs font-medium ${linkColor} hover:underline mt-1 inline-block`}>
            {translate('viewApplicationLinkText', 'View Details')}
          </span>
        )}
        <p className={`text-xs ${timestampColor} mt-1`}>{timeSince(notification.timestamp)}</p>
      </div>
    </li>
  );
};

export default NotificationItem;