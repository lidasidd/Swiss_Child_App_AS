import React, { useState, useEffect, useRef } from 'react';
import { useAppContext } from '../../hooks/useAppContext';
import { Notification } from '../../types';
import NotificationItem from './NotificationItem';
// Removed Button import as we'll use a styled text link or icon button

const NotificationBell: React.FC = () => {
  const { notifications, markAllNotificationsAsRead, translate, theme } = useAppContext();
  const [isOpen, setIsOpen] = useState(false);
  const notificationRef = useRef<HTMLDivElement>(null);

  const unreadNotifications = notifications.filter(n => !n.isRead);
  const unreadCount = unreadNotifications.length;

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (notificationRef.current && !notificationRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const togglePanel = () => setIsOpen(!isOpen);

  let bellColor = 'text-gray-500 hover:text-gray-700';
  let badgeBg = 'bg-red-500';
  let badgeTextColor = 'text-white';
  let panelBg = 'bg-white';
  let panelBorder = 'border-gray-200';
  let panelHeaderTextColor = 'text-gray-800';
  let markAllReadColor = 'text-blue-600 hover:text-blue-800';
  let focusRingColor = 'focus:ring-indigo-500';

  if (theme === 'theme2') {
    bellColor = 'text-white hover:text-gray-200 transition-colors duration-150';
    badgeBg = 'bg-red-500'; 
    panelBg = 'bg-theme2-secondary-bg';
    panelBorder = 'border-theme2-primary/30';
    panelHeaderTextColor = 'text-theme2-primary';
    markAllReadColor = 'text-theme2-primary hover:text-blue-700';
    focusRingColor = 'focus:ring-white';
  } else if (theme === 'theme3') {
    bellColor = 'text-theme3-text-on-dark hover:text-theme3-accent-light transition-colors duration-150';
    badgeBg = 'bg-red-500';
    panelBg = 'bg-theme3-secondary-bg';
    panelBorder = 'border-theme3-accent/50';
    panelHeaderTextColor = 'text-theme3-primary';
    markAllReadColor = 'text-theme3-accent hover:text-theme3-accent-light';
    focusRingColor = 'focus:ring-theme3-accent-light';
  } else if (theme === 'theme4') {
    bellColor = 'text-theme4-text-on-dark hover:text-theme4-primary transition-colors duration-150';
    badgeBg = 'bg-red-500';
    panelBg = 'bg-theme4-secondary-bg';
    panelBorder = 'border-theme4-border';
    panelHeaderTextColor = 'text-theme4-primary';
    markAllReadColor = 'text-theme4-primary hover:sky-400';
    focusRingColor = 'focus:ring-theme4-primary';
  }

  return (
    <div className="relative" ref={notificationRef}>
      <button
        onClick={togglePanel}
        className={`relative p-2 rounded-full focus:outline-none focus:ring-2 focus:ring-offset-2 
                    ${theme === 'theme2' ? `focus:ring-offset-theme2-primary ${focusRingColor}` : 
                      theme === 'theme3' ? `focus:ring-offset-theme3-primary ${focusRingColor}` : 
                      `focus:ring-offset-theme4-secondary-bg ${focusRingColor}`}`}
        aria-label={translate('notificationsTitle', 'Notifications')}
        aria-haspopup="true"
        aria-expanded={isOpen}
      >
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={`w-6 h-6 ${bellColor}`}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M14.857 17.082a23.848 23.848 0 005.454-1.31A8.967 8.967 0 0118 9.75v-.7V9A6 6 0 006 9v.75a8.967 8.967 0 01-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 01-5.714 0m5.714 0a3 3 0 11-5.714 0" />
        </svg>
        {unreadCount > 0 && (
          <span 
            className={`absolute top-1.5 right-1.5 flex items-center justify-center h-4 w-4 rounded-full text-xs font-semibold 
                       ${badgeBg} ${badgeTextColor} ring-1 ${theme === 'theme2' || theme === 'theme3' ? 'ring-white' : 'ring-theme4-secondary-bg' }`}
          >
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      {isOpen && (
        <div 
            className={`absolute right-0 mt-3 w-80 sm:w-96 max-h-[70vh] overflow-y-auto rounded-lg shadow-xl z-50 border ${panelBg} ${panelBorder} flex flex-col`}
            role="dialog"
            aria-modal="true"
            aria-labelledby="notifications-panel-title"
        >
          <div className={`p-4 border-b ${panelBorder} flex justify-between items-center sticky top-0 ${panelBg} z-10`}>
            <h3 id="notifications-panel-title" className={`text-lg font-semibold ${panelHeaderTextColor}`}>{translate('notificationsTitle')}</h3>
            {unreadCount > 0 && (
                <button 
                  onClick={() => { markAllNotificationsAsRead(); setIsOpen(false); }} 
                  className={`text-xs font-medium ${markAllReadColor} focus:outline-none focus:underline`}
                >
                 {translate('markAllAsRead')}
                </button>
            )}
          </div>
          {unreadCount > 0 ? (
            <ul className={`flex-grow divide-y ${theme === 'theme4' ? 'divide-theme4-border/50' : 'divide-gray-200/70'}`}>
              {unreadNotifications.sort((a,b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()).map(notification => (
                <NotificationItem key={notification.id} notification={notification} onRead={() => setIsOpen(false)} />
              ))}
            </ul>
          ) : (
            <div className="flex-grow flex items-center justify-center p-6">
              <p className={`text-sm text-center ${theme === 'theme4' ? 'text-theme4-text-on-dark/70' : 'text-gray-500'}`}>
                {translate('noNotifications')}
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default NotificationBell;