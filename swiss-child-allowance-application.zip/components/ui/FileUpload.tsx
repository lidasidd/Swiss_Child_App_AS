
import React, { useState, useCallback, ChangeEvent, useEffect } from 'react';
import { UploadedFile } from '../../types';
import { MAX_FILE_SIZE_MB, ALLOWED_FILE_TYPES, ALLOWED_QUESTIONNAIRE_FILE_TYPES } from '../../constants'; // Assuming ALLOWED_QUESTIONNAIRE_FILE_TYPES might be used if context provided
import Button from './Button';
import { useAppContext } from '../../hooks/useAppContext';

interface FileUploadProps {
  onFilesChange: (files: UploadedFile[]) => void;
  label: string;
  id: string;
  helpText?: string;
  multiple?: boolean;
  required?: boolean;
  existingFiles?: UploadedFile[];
  disabled?: boolean;
  allowedFileTypes?: string[]; // Prop to specify allowed types, defaults to general image/pdf
}

const FileUpload: React.FC<FileUploadProps> = ({
  onFilesChange,
  label,
  id,
  helpText,
  multiple = false,
  required = false,
  existingFiles = [],
  disabled = false,
  allowedFileTypes = ALLOWED_FILE_TYPES, // Default to general types
}) => {
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>(existingFiles);
  const [error, setError] = useState<string | null>(null);
  const { theme, translate } = useAppContext();

  const handleFileChange = useCallback(async (event: ChangeEvent<HTMLInputElement>) => {
    if (disabled) return;
    const files = event.target.files;
    if (!files) return;

    setError(null);
    let newFilesArray: UploadedFile[] = multiple ? [...uploadedFiles] : [];
    
    const readFileAsBase64 = (file: File): Promise<string> => {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => {
                if (typeof reader.result === 'string') {
                    resolve(reader.result.split(',')[1]); // Get base64 part
                } else {
                    reject(new Error('Failed to read file as base64 string.'));
                }
            };
            reader.onerror = (error) => reject(error);
            reader.readAsDataURL(file);
        });
    };


    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      if (file.size > MAX_FILE_SIZE_MB * 1024 * 1024) {
        setError(translate('fileTooLargeError', '{fileName} is too large. Max size is {maxSize}MB.')
          .replace('{fileName}', file.name)
          .replace('{maxSize}', MAX_FILE_SIZE_MB.toString())
        );
        continue;
      }
      if (!allowedFileTypes.includes(file.type)) {
        setError(translate('unsupportedFileTypeError', '{fileName} has an unsupported file type. Allowed: {types}.')
          .replace('{fileName}', file.name)
          .replace('{types}', allowedFileTypes.map(t => t.split('/')[1].toUpperCase()).join(', '))
        );
        continue;
      }

      try {
        const base64String = await readFileAsBase64(file);
        const newFile: UploadedFile = {
            id: `${file.name}-${Date.now()}`,
            name: file.name,
            type: file.type,
            size: file.size,
            base64: base64String, // Include base64 data
        };
        
        if (multiple) {
            newFilesArray.push(newFile);
        } else {
            newFilesArray = [newFile]; 
        }
      } catch (readError) {
        console.error("Error reading file:", readError);
        setError(`Failed to process file ${file.name}.`);
        continue; // Skip this file
      }
    }
    
    setUploadedFiles(newFilesArray);
    onFilesChange(newFilesArray);
    if (event.target) {
        event.target.value = ''; 
    }

  }, [multiple, onFilesChange, uploadedFiles, translate, disabled, allowedFileTypes]);

  const removeFile = (fileIdToRemove: string) => {
    if (disabled) return;
    const updatedFiles = uploadedFiles.filter(file => file.id !== fileIdToRemove);
    setUploadedFiles(updatedFiles);
    onFilesChange(updatedFiles);
  };
  
  useEffect(() => {
    setUploadedFiles(existingFiles);
  }, [existingFiles]);


  let labelColorClass = '';
  let helpTextColorClass = '';
  let borderColorClass = 'border-gray-300';
  let buttonLikeLabelStyles = '';
  let uploadedFileBgClass = 'bg-gray-50';
  let uploadedFileTextColor = 'text-gray-700';


  if (theme === 'theme2') {
    labelColorClass = 'text-theme2-text';
    helpTextColorClass = 'text-gray-500';
    borderColorClass = 'border-gray-200';
    buttonLikeLabelStyles = 'bg-theme2-primary hover:bg-blue-700 text-white px-4 py-2 rounded-md font-semibold';
    uploadedFileBgClass = 'bg-gray-50';
    uploadedFileTextColor = 'text-theme2-text';
  } else if (theme === 'theme3') {
    labelColorClass = 'text-theme3-text-on-light';
    helpTextColorClass = 'text-gray-500';
    borderColorClass = 'border-gray-400';
    buttonLikeLabelStyles = 'bg-theme3-primary hover:bg-slate-700 text-theme3-text-on-dark px-4 py-2 rounded-md font-semibold';
    uploadedFileBgClass = 'bg-slate-100';
    uploadedFileTextColor = 'text-theme3-text-on-light';
  } else if (theme === 'theme4') {
    labelColorClass = 'text-theme4-text-on-dark';
    helpTextColorClass = 'text-slate-400';
    borderColorClass = 'border-theme4-border';
    buttonLikeLabelStyles = 'bg-theme4-primary hover:bg-theme4-accent-dark text-white px-4 py-2 rounded-md font-semibold';
    uploadedFileBgClass = 'bg-theme4-secondary-bg-hover'; 
    uploadedFileTextColor = 'text-theme4-text-on-dark';
  }


  const fileTypeDisplay = allowedFileTypes.map(type => type.split('/')[1].toUpperCase()).join(', ');
  const sizeDisplay = MAX_FILE_SIZE_MB.toString();
  const fileHintText = translate('fileTypesAndSize', "{types} up to {size}MB")
    .replace('{types}', fileTypeDisplay)
    .replace('{size}', sizeDisplay);

  return (
    <div className="mb-4">
      <label htmlFor={id} className={`block text-sm font-medium mb-1 ${labelColorClass}`}>
        {label} {required && !disabled && <span className="text-red-500">*</span>}
      </label>
      {!disabled && (
        <div className={`mt-1 p-4 border rounded-md ${borderColorClass} ${theme === 'theme4' ? 'bg-theme4-secondary-bg' : '' }`}>
          <div className="flex flex-col items-start">
              <label
                htmlFor={id}
                className={`relative cursor-pointer inline-block ${buttonLikeLabelStyles} focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 
                  ${theme === 'theme2' ? 'focus-within:ring-theme2-primary' : 
                    theme === 'theme3' ? 'focus-within:ring-theme3-accent' : 
                    'focus-within:ring-theme4-primary focus-within:ring-offset-theme4-bg'}`}
              >
                <span>{translate('uploadAFileButton')}</span>
                <input id={id} name={id} type="file" className="sr-only" onChange={handleFileChange} multiple={multiple} accept={allowedFileTypes.join(',')} disabled={disabled} />
              </label>
              <p className={`mt-2 text-xs ${helpTextColorClass}`}>{fileHintText}</p>
              <p className={`mt-1 text-xs ${helpTextColorClass}`}>{translate('dragAndDrop')} {translate('dragAndDropHint', '(Optional: you can also drag files here)')}</p>
          </div>
        </div>
      )}
      {helpText && <p className={`mt-1 text-xs ${helpTextColorClass}`}>{helpText}</p>}
      {error && <p className="mt-1 text-xs text-red-500">{error}</p>}
      
      {uploadedFiles.length > 0 && (
        <div className="mt-4">
          <h4 className={`text-sm font-medium ${labelColorClass}`}>{translate('uploadedFilesTitle')}</h4>
          <ul className="mt-2 space-y-2">
            {uploadedFiles.map((file) => (
              <li key={file.id} className={`flex items-center justify-between p-2 border rounded-md ${borderColorClass} ${uploadedFileBgClass}`}>
                <span className={`text-sm truncate ${uploadedFileTextColor}`}>{file.name} ({(file.size / 1024 / 1024).toFixed(2)} MB)</span>
                {!disabled && (
                  <Button variant="ghost" size="sm" onClick={() => removeFile(file.id)} className="text-red-500 hover:text-red-700">
                    {translate('removeFile')}
                  </Button>
                )}
              </li>
            ))}
          </ul>
        </div>
      )}
       {disabled && uploadedFiles.length === 0 && (
         <p className={`mt-2 text-sm italic ${helpTextColorClass}`}>{translate('noDocumentsUploaded', 'No documents were uploaded for this part.')}</p>
       )}
    </div>
  );
};

export default FileUpload;
