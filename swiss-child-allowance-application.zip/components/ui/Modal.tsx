
import React, { ReactNode } from 'react';
import Button from './Button';
import { useAppContext } from '../../hooks/useAppContext';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  showOkButton?: boolean;
  okText?: string;
  onOk?: () => void;
  showCancelButton?: boolean;
  cancelText?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

const Modal: React.FC<ModalProps> = ({
  isOpen,
  onClose,
  title,
  children,
  showOkButton = true,
  okText = 'OK',
  onOk,
  showCancelButton = false,
  cancelText = 'Cancel',
  size = 'md',
}) => {
  const { theme } = useAppContext();

  if (!isOpen) return null;

  const sizeClasses = {
    sm: 'max-w-sm',
    md: 'max-w-md',
    lg: 'max-w-lg',
    xl: 'max-w-xl',
  };

  let modalBgColor = 'bg-white';
  let titleColor = 'text-gray-900';
  let contentColor = 'text-gray-700';
  let closeButtonHoverBg = 'hover:bg-gray-200';
  let closeButtonColor = 'text-gray-600';


  if (theme === 'theme2') {
    modalBgColor = 'bg-theme2-secondary-bg';
    titleColor = 'text-theme2-text';
    contentColor = 'text-theme2-text/90';
    closeButtonHoverBg = 'hover:bg-gray-200'; // Default gray hover for light themes
    closeButtonColor = 'text-gray-600';
  } else if (theme === 'theme3') {
    modalBgColor = 'bg-theme3-secondary-bg'; 
    titleColor = 'text-theme3-text-on-light'; 
    contentColor = 'text-theme3-text-on-light/90';
    closeButtonHoverBg = 'hover:bg-gray-700'; // Darker hover for theme3 if its base is dark
    closeButtonColor = 'text-theme3-text-on-light';
  } else if (theme === 'theme4') {
    modalBgColor = 'bg-theme4-secondary-bg';
    titleColor = 'text-theme4-text-on-dark';
    contentColor = 'text-theme4-text-on-dark/90';
    closeButtonHoverBg = 'hover:bg-slate-600';
    closeButtonColor = 'text-theme4-text-on-dark';
  }


  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black bg-opacity-50 transition-opacity duration-300 ease-in-out">
      <div className={`rounded-lg shadow-xl w-full p-6 space-y-4 ${sizeClasses[size]} ${modalBgColor}`}>
        <div className="flex justify-between items-center">
          <h3 className={`text-xl font-semibold ${titleColor}`}>{title}</h3>
          <button
            onClick={onClose}
            className={`p-1 rounded-full ${closeButtonHoverBg} ${closeButtonColor}`}
            aria-label="Close modal"
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        <div className={`text-sm ${contentColor}`}>
          {children}
        </div>
        {(showOkButton || showCancelButton) && (
          <div className="flex justify-end space-x-3 pt-2">
            {showCancelButton && (
              <Button variant="secondary" onClick={onClose}>
                {cancelText}
              </Button>
            )}
            {showOkButton && onOk && (
              <Button variant="primary" onClick={onOk}>
                {okText}
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default Modal;