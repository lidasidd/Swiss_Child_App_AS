
import React from 'react';
import { SelectOption } from '../../types';
import { useAppContext } from '../../hooks/useAppContext';

interface FormFieldProps {
  id: string;
  name?: string; // Added name prop
  label: string;
  type?: 'text' | 'email' | 'date' | 'number' | 'password' | 'tel';
  value: string | number;
  onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
  onBlur?: (e: React.FocusEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => void;
  placeholder?: string;
  error?: string;
  helpText?: string;
  options?: SelectOption[]; // For select type
  as?: 'input' | 'select' | 'textarea';
  required?: boolean;
  disabled?: boolean;
  rows?: number; // For textarea
  className?: string; // Additional classes for the wrapper or input
}

const FormField: React.FC<FormFieldProps> = ({
  id,
  name, // Destructure name
  label,
  type = 'text',
  value,
  onChange,
  onBlur,
  placeholder,
  error,
  helpText,
  options,
  as = 'input',
  required = false,
  disabled = false,
  rows = 3,
  className = '',
}) => {
  const { theme, translate } = useAppContext();
  const commonInputStyles = `w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-2 sm:text-sm disabled:bg-gray-100 disabled:cursor-not-allowed`;
  
  let themeSpecificStyles = '';
  let labelColorClass = '';
  let helpTextColorClass = '';

  if (theme === 'theme2') {
    themeSpecificStyles = `bg-theme2-secondary-bg border-gray-300 focus:ring-theme2-primary text-theme2-text placeholder-gray-400`;
    labelColorClass = 'text-theme2-text';
    helpTextColorClass = 'text-gray-500';
  } else if (theme === 'theme3') {
    themeSpecificStyles = `bg-theme3-secondary-bg border-gray-300 focus:ring-theme3-primary text-theme3-text-on-light placeholder-gray-400`;
    labelColorClass = 'text-theme3-text-on-light';
    helpTextColorClass = 'text-gray-500';
  } else if (theme === 'theme4') {
    themeSpecificStyles = `bg-theme4-secondary-bg border-theme4-border focus:ring-theme4-primary text-theme4-text-on-dark placeholder-slate-400 disabled:bg-slate-700 disabled:text-slate-400`;
    labelColorClass = 'text-theme4-text-on-dark';
    helpTextColorClass = 'text-slate-400';
  }
  
  const errorStyles = error ? 'border-red-500 focus:ring-red-500' : (themeSpecificStyles.match(/border-\S+/)?.[0] || 'border-gray-300');
  const finalInputStyles = `${commonInputStyles} ${themeSpecificStyles.replace(/border-\S+/, errorStyles)} ${className}`;


  const renderInput = () => {
    const elementName = name || id; // Use provided name, fallback to id
    if (as === 'select') {
      return (
        <select
          id={id}
          name={elementName}
          value={value}
          onChange={onChange}
          onBlur={onBlur}
          required={required}
          disabled={disabled}
          className={finalInputStyles}
        >
          {placeholder && <option value="">{placeholder}</option>}
          {options?.map(option => (
            <option key={option.value} value={option.value}>
              {option.labelKey ? translate(option.labelKey, option.label || option.value) : (option.label || option.value)}
            </option>
          ))}
        </select>
      );
    }
    if (as === 'textarea') {
      return (
        <textarea
          id={id}
          name={elementName}
          value={value}
          onChange={onChange}
          onBlur={onBlur}
          placeholder={placeholder}
          required={required}
          disabled={disabled}
          rows={rows}
          className={finalInputStyles}
        />
      );
    }
    return (
      <input
        id={id}
        name={elementName}
        type={type}
        value={value}
        onChange={onChange}
        onBlur={onBlur}
        placeholder={placeholder}
        required={required}
        disabled={disabled}
        className={finalInputStyles}
      />
    );
  };

  return (
    <div className="mb-4">
      <label htmlFor={id} className={`block text-sm font-medium mb-1 ${labelColorClass}`}>
        {label} {required && <span className="text-red-500">*</span>}
      </label>
      {renderInput()}
      {helpText && <p className={`mt-1 text-xs ${helpTextColorClass}`}>{helpText}</p>}
      {error && <p className="mt-1 text-xs text-red-500">{error}</p>}
    </div>
  );
};

export default FormField;