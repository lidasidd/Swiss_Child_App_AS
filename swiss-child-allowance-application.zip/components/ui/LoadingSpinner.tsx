
import React from 'react';
import { useAppContext } from '../../hooks/useAppContext';

interface LoadingSpinnerProps {
  text?: string;
  size?: 'sm' | 'md' | 'lg';
}

const LoadingSpinner: React.FC<LoadingSpinnerProps> = ({ text, size = 'md' }) => {
  const { theme } = useAppContext();

  const sizeClasses = {
    sm: 'w-6 h-6',
    md: 'w-10 h-10',
    lg: 'w-16 h-16',
  };

  let spinnerColor = 'text-blue-600'; 
  let textColor = 'text-gray-700';

  if (theme === 'theme2') {
    spinnerColor = 'text-theme2-primary';
    textColor = 'text-theme2-text';
  } else if (theme === 'theme3') {
    spinnerColor = 'text-theme3-primary';
    textColor = 'text-theme3-text-on-light';
  } else if (theme === 'theme4') {
    spinnerColor = 'text-theme4-primary';
    textColor = 'text-theme4-text-on-dark';
  }
  

  return (
    <div className="flex flex-col items-center justify-center min-h-[200px] text-center">
      <svg
        className={`animate-spin ${sizeClasses[size]} ${spinnerColor} mb-3`}
        xmlns="http://www.w3.org/2000/svg"
        fill="none"
        viewBox="0 0 24 24"
      >
        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
        <path
          className="opacity-75"
          fill="currentColor"
          d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
        ></path>
      </svg>
      {text && <p className={`text-lg font-medium ${textColor}`}>{text}</p>}
    </div>
  );
};

export default LoadingSpinner;