import React from 'react';
import { UserQuestionnaire, UserQuestionnaireStatus } from '../../types';
import Button from '../ui/Button';
import { useAppContext } from '../../hooks/useAppContext';
import { translateUserQuestionnaireStatus } from '../../constants';

interface UserQuestionnaireListItemProps {
  questionnaire: UserQuestionnaire;
  onOpenModal: (questionnaire: UserQuestionnaire) => void;
}

const UserQuestionnaireListItem: React.FC<UserQuestionnaireListItemProps> = ({ questionnaire, onOpenModal }) => {
  const { translate, theme } = useAppContext();

  const getStatusBadgeStyle = (status: UserQuestionnaireStatus) => {
    let bg = ''; let text = '';
    // Define theme-specific badge colors
    if (theme === 'theme4') { // Dark Theme
        bg = 'bg-slate-600'; text = 'text-slate-300';
        switch (status) {
            case UserQuestionnaireStatus.PENDING_EMPLOYEE_RESPONSE: bg = 'bg-yellow-700/80'; text = 'text-yellow-200'; break;
            case UserQuestionnaireStatus.SUBMITTED_BY_EMPLOYEE: bg = 'bg-blue-700/80'; text = 'text-blue-200'; break;
            case UserQuestionnaireStatus.APPROVED_BY_ADMIN: bg = 'bg-green-700/80'; text = 'text-green-200'; break;
            case UserQuestionnaireStatus.REJECTED_BY_ADMIN: bg = 'bg-red-700/80'; text = 'text-red-200'; break;
        }
    } else if (theme === 'theme3') { // Moody Blue
        bg = 'bg-slate-200'; text = 'text-slate-700';
         switch (status) {
            case UserQuestionnaireStatus.PENDING_EMPLOYEE_RESPONSE: bg = 'bg-amber-200'; text = 'text-amber-800'; break;
            case UserQuestionnaireStatus.SUBMITTED_BY_EMPLOYEE: bg = 'bg-sky-200'; text = 'text-sky-800'; break;
            case UserQuestionnaireStatus.APPROVED_BY_ADMIN: bg = 'bg-emerald-200'; text = 'text-emerald-800'; break;
            case UserQuestionnaireStatus.REJECTED_BY_ADMIN: bg = 'bg-red-200'; text = 'text-red-800'; break;
        }
    } else { // Theme2 (Default Bright)
        bg = 'bg-gray-100'; text = 'text-gray-700';
        switch (status) {
            case UserQuestionnaireStatus.PENDING_EMPLOYEE_RESPONSE: bg = 'bg-yellow-100'; text = 'text-yellow-800'; break;
            case UserQuestionnaireStatus.SUBMITTED_BY_EMPLOYEE: bg = 'bg-blue-100'; text = 'text-blue-800'; break;
            case UserQuestionnaireStatus.APPROVED_BY_ADMIN: bg = 'bg-green-100'; text = 'text-green-800'; break;
            case UserQuestionnaireStatus.REJECTED_BY_ADMIN: bg = 'bg-red-100'; text = 'text-red-800'; break;
        }
    }
    return `${bg} ${text}`;
  };

  const statusBadgeStyle = getStatusBadgeStyle(questionnaire.status);

  let itemBgClass = 'bg-white';
  let textColorClass = 'text-gray-700';
  let headingColorClass = 'text-gray-900';
  let borderColorClass = 'border-gray-200';

  if (theme === 'theme2') {
    itemBgClass = 'bg-theme2-secondary-bg';
    textColorClass = 'text-theme2-text';
    headingColorClass = 'text-theme2-text';
    borderColorClass = 'border-theme2-accent1/70';
  } else if (theme === 'theme3') {
    itemBgClass = 'bg-theme3-secondary-bg';
    textColorClass = 'text-theme3-text-on-light';
    headingColorClass = 'text-theme3-text-on-light';
    borderColorClass = 'border-slate-300';
  } else if (theme === 'theme4') {
    itemBgClass = 'bg-theme4-secondary-bg';
    textColorClass = 'text-theme4-text-on-dark';
    headingColorClass = 'text-theme4-text-on-dark';
    borderColorClass = 'border-theme4-border';
  }
  
  const relevantComment = questionnaire.status === UserQuestionnaireStatus.PENDING_EMPLOYEE_RESPONSE 
                            ? questionnaire.adminComments 
                            : questionnaire.status === UserQuestionnaireStatus.REJECTED_BY_ADMIN 
                            ? questionnaire.adminReviewComments 
                            : null;
  const commentLabel = questionnaire.status === UserQuestionnaireStatus.PENDING_EMPLOYEE_RESPONSE 
                        ? translate('questionnaireCommentsByAdmin')
                        : questionnaire.status === UserQuestionnaireStatus.REJECTED_BY_ADMIN
                        ? translate('questionnaireAdminReviewCommentsDisplay')
                        : null;

  return (
    <div className={`p-4 rounded-lg shadow-md border ${borderColorClass} ${itemBgClass} mb-4`}>
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4 items-start">
        {/* Column 1: Questionnaire ID */}
        <div>
          <p className={`text-sm font-medium ${headingColorClass}`}>{translate('questionnaireIdDisplay')}</p>
          <p className={`text-sm ${textColorClass}`}>{questionnaire.id.substring(0,12)}...</p>
        </div>
        {/* Column 2: Title */}
        <div>
          <p className={`text-sm font-medium ${headingColorClass}`}>{translate('questionnaireTitleDisplay')}</p>
          <p className={`text-sm ${textColorClass} truncate`}>{questionnaire.title}</p>
        </div>
        {/* Column 3: Status & Comments */}
        <div>
          <p className={`text-sm font-medium ${headingColorClass} mb-1`}>{translate('questionnaireStatusDisplay')}</p>
          <span className={`px-2.5 py-0.5 inline-flex text-xs leading-5 font-semibold rounded-full ${statusBadgeStyle}`}>
            {translateUserQuestionnaireStatus(questionnaire.status, translate)}
          </span>
          {relevantComment && commentLabel && (
             <p className={`text-xs mt-1 ${textColorClass} break-words whitespace-pre-wrap`}>
                <strong>{commentLabel}:</strong> {relevantComment}
            </p>
          )}
        </div>
        {/* Column 4: Dates */}
        <div>
          <p className={`text-sm font-medium ${headingColorClass}`}>{translate('questionnaireSentOnDisplay')}</p>
          <p className={`text-sm ${textColorClass}`}>{new Date(questionnaire.sentDate).toLocaleDateString()}</p>
          <p className={`text-sm font-medium ${headingColorClass} mt-1`}>{translate('questionnaireRespondedOnDisplay')}</p>
          <p className={`text-sm ${textColorClass}`}>{questionnaire.employeeSubmissionDate ? new Date(questionnaire.employeeSubmissionDate).toLocaleDateString() : translate('na', 'N/A')}</p>
        </div>
        {/* Column 5: Action Button */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-end space-y-2 md:space-y-0 md:space-x-2">
          <Button
            variant="secondary"
            size="sm"
            onClick={() => onOpenModal(questionnaire)}
          >
            {questionnaire.status === UserQuestionnaireStatus.PENDING_EMPLOYEE_RESPONSE ? translate('respond') : translate('viewDetails')}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default UserQuestionnaireListItem;
