export enum ApplicationStatus {
  DRAFT = 'Draft',
  SUBMITTED = 'Submitted',
  UNDER_REVIEW = 'Under Review',
  PENDING_EMPLOYEE_ACTION = 'Pending Employee Action',
  COMPLETED = 'Completed',
  REJECTED = 'Rejected',
}

export enum MaritalStatus {
  SINGLE = 'Single',
  MARRIED = 'Married',
  WIDOWED = 'Widowed',
  SEPARATED = 'Separated',
  DIVORCED = 'Divorced',
}

export enum Gender {
  MALE = 'Male',
  FEMALE = 'Female',
}

export enum RelationshipToApplicant {
  OWN_OR_ADOPTED = 'Own or Adopted child',
  STEPCHILD = 'Stepchild',
  FOSTER_CHILD = 'Foster child',
  SIBLING = 'Sibling',
  GRANDCHILD = 'Grandchild',
}

export enum SpouseEmploymentStatus {
    HOUSEWIFE_HOUSEHUSBAND = 'Housewife/House husband',
    UNEMPLOYED = 'Unemployed',
    CHILD_RAISING_LEAVE = 'Child-raising leave',
    INVALID = 'Invalid',
}

export enum LegalParentEmploymentStatus {
    EMPLOYED = 'Employed',
    SELF_EMPLOYED = 'Self-Employed',
    NOT_GAINFULLY_EMPLOYED = 'Not gainfully employed',
}

export enum IncomeComparison {
    HIGHER = 'Higher',
    LOWER = 'Lower',
}

export enum CarerRelationshipType {
  FOSTER_PARENT = 'Foster parent',
  CHILDS_CUSTODIAN = "Child's custodian",
  GRANDPARENT = 'Grandparent',
  SIBLING = 'Sibling',
  OTHER = 'Other',
}


export interface SFUserData {
  firstName: string;
  lastName: string;
  dateOfBirth: string; // YYYY-MM-DD
  employeeId: string;
  ahvNumber?: string; // Swiss social security number
  companyName: string; // "Viking Contract Name"
  contractStartDate?: string; // YYYY-MM-DD
  contractEndDate?: string; // YYYY-MM-DD
  hrManagerName: string;
  email?: string; // Employee email from SF
  // Potentially pre-filled partner/children if available in SF
  partnerName?: string; 
  children?: ChildDataSF[];
}

export interface ChildDataSF {
  firstName: string;
  lastName: string;
  dateOfBirth: string; // YYYY-MM-DD
}

export interface UploadedFile {
  name: string;
  type: string;
  size: number;
  base64?: string; // For simplicity, storing base64; in reality, use FormData for uploads
  id: string; // For tracking
}

export interface OtherEmployer {
  id: string;
  name: string;
  address: string;
  incomeComparedToViking?: IncomeComparison;
}

export interface ChildDetails {
  id: string;
  lastName: string;
  firstName: string;
  dateOfBirth: string;
  gender: Gender;
  address: string; // full address
  placeOfResidence: string;
  relationshipToApplicant: RelationshipToApplicant;
  birthCertificate?: UploadedFile; // Moved here - one per child
}

export interface ApplicationData {
  id: string; // Unique ID for the application
  userId: string; // Employee ID
  status: ApplicationStatus;
  submissionDate?: string; // YYYY-MM-DD
  lastModifiedDate: string; // YYYY-MM-DD

  // Step 1
  residencyCountry?: string;

  // Step 2 (Pre-filled from SF, but now editable)
  employeeFirstName?: string;
  employeeLastName?: string;
  employeeDateOfBirth?: string;
  employeeEmployeeId?: string; // This should ideally not change from SF id.
  employeeAhvNumber?: string;
  employeeCompanyName?: string;
  employeeContractStartDate?: string;
  employeeContractEndDate?: string;
  
  // Step 3
  appliedInResidenceCountry?: boolean;

  // Step 4: Personal Details
  addressStreet?: string;
  addressStreetNo?: string;
  addressPostCode?: string;
  addressTown?: string;
  addressCity?: string; 
  telephone?: string;
  email?: string; 
  maritalStatus?: MaritalStatus;
  maritalStatusSince?: string; // YYYY-MM-DD

  // Step 5 & 6: Other Employers
  hasOtherEmployers?: boolean;
  otherEmployers: OtherEmployer[];

  // Step 7: Cash Benefits (Employee)
  receivingCashBenefits?: boolean;
  benefitType?: string;
  benefitReceivedSince?: string; // YYYY-MM-DD
  benefitPaymentOffice?: string;

  // Step 8: Spouse/Partner Details
  spouseLastName?: string;
  spouseFirstName?: string;
  spouseDateOfBirth?: string; // YYYY-MM-DD
  spousePersonalId?: string; // AHV or home country ID
  spouseMaritalStatus?: MaritalStatus;

  // Step 9: Spouse Employment Status
  isSpouseGainfullyEmployed?: boolean;
  spouseEmploymentStatus?: SpouseEmploymentStatus; // if not gainfully employed

  // Step 10 & 11: Spouse Cash Benefits
  spouseReceivingCashBenefits?: boolean;
  spouseBenefitType?: string;
  spouseBenefitReceivedSince?: string; // YYYY-MM-DD
  spouseBenefitPaymentOffice?: string;

  // Step 12: Spouse Employer Details (if employed)
  spouseEmployerName?: string;
  spouseEmployerAddress?: string;
  spouseEmployerCantonCountry?: string;
  spouseEmploymentExtent?: number; // 1-100%
  spouseIncomeComparedToApplicant?: IncomeComparison;

  // Step 13: Children Details
  children: ChildDetails[]; 

  // Step 14: Legal Parent Details (if different)
  hasDifferentLegalParent?: boolean; 
  legalParentAppliesToAllChildren?: boolean;
  legalParentAppliesToChildIds?: string[];
  legalParentLastName?: string;
  legalParentFirstName?: string;
  legalParentDateOfBirth?: string;
  legalParentMaritalStatus?: MaritalStatus;
  legalParentAddress?: string;
  legalParentTelephone?: string;
  legalParentEmploymentDetail?: LegalParentEmploymentStatus;
  legalParentEmployerName?: string; 
  legalParentEmployerAddress?: string; 
  legalParentEmployerCantonCountry?: string; 
  legalParentSelfEmployedCantonCountry?: string; 
  
  // Step 15 & 16: Child Carer Details
  childLivesWithOtherCarer?: boolean; 
  carerAppliesToAllChildren?: boolean;
  carerAppliesToChildIds?: string[];
  carerLastName?: string;
  carerFirstName?: string;
  carerTelephone?: string;
  carerRelationship?: CarerRelationshipType | string; 
  carerRelationshipOtherText?: string; 

  // Step 17: Previous Allowances
  receivedSwissChildAllowancesBefore?: boolean;
  previousAllowanceCanton?: string;
  previousAllowanceUntilDate?: string; // YYYY-MM-DD

  // Field for the now-unused Step 18 (ChildAgeQuery)
  confirmChildOver15?: boolean;

  // Step 18 (formerly 19/20): Documents
  marriageCertificate?: UploadedFile; 
  divorceDecree?: UploadedFile; 
  educationConfirmations?: UploadedFile[]; 

  // Step 19 (formerly 21): Signature
  signatureName?: string;
  signatureDate?: string; // YYYY-MM-DD
  informationConfirmed?: boolean; // New checkbox
  
  adminComments?: string; // For admin feedback

  currentStep: number; 
}

export interface User {
  id: string; // employeeId
  name: string;
  role: 'employee' | 'admin' | 'hr'; // Simplified roles
  hrManagerName?: string;
}

// For i18n
export type Language = 'en' | 'de' | 'fr' | 'it';
export type Translations = {
  [key: string]: {
    [lang in Language]: string;
  };
};

export type Theme = 'theme1' | 'theme2' | 'theme3' | 'theme4';

export interface Questionnaire {
  id: string;
  title: string;
  deadline: string;
  instructions: string;
  status: 'Pending' | 'Completed';
}

// For dropdown options
export interface SelectOption {
  value: string;
  label?: string; // Original label, can be fallback
  labelKey?: string; // Key for translation
}

export type NotificationType = 'info' | 'alert' | 'success' | 'update' | 'system';

export interface Notification {
  id: string;
  type: NotificationType; // Added type
  messageKey: string;
  defaultMessage: string;
  timestamp: string; // ISO string
  isRead: boolean;
  link?: string; // Optional: to navigate to a specific page or application
  linkState?: any; // Optional state for navigation (e.g. fromAdmin)
}