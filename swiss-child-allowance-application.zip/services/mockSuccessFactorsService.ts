
import { SFUserData, ChildDataSF } from '../types';

// Mock database of SF users
const mockSFDatabase: { [employeeId: string]: SFUserData } = {
  'employee123': {
    firstName: 'Max',
    lastName: 'Muster',
    dateOfBirth: '1985-06-15',
    employeeId: 'employee123',
    ahvNumber: '756.1234.5678.90',
    companyName: 'Viking Global Inc.',
    contractStartDate: '2020-01-01',
    hrManagerName: 'Erika Mustermann',
    children: [
      { firstName: 'Anna', lastName: 'Muster', dateOfBirth: '2015-03-10' },
      { firstName: 'Paul', lastName: 'Muster', dateOfBirth: '2018-07-22' },
    ]
  },
  'employee456': {
    firstName: 'Maria',
    lastName: 'Schmidt',
    dateOfBirth: '1990-11-20',
    employeeId: 'employee456',
    ahvNumber: '756.9876.5432.10',
    companyName: 'Viking Solutions AG',
    contractStartDate: '2019-05-15',
    hrManagerName: 'Hans Meier',
    partnerName: 'Peter Schmidt',
    children: [
      { firstName: 'Leo', lastName: 'Schmidt', dateOfBirth: '2022-01-05' },
    ]
  },
};

export const getMockSFUserData = (employeeId: string): SFUserData | null => {
  // Simulate API call delay
  // await new Promise(resolve => setTimeout(resolve, 500)); 
  // This function is synchronous as per current app structure. Make async if needed.
  return mockSFDatabase[employeeId] || null;
};
