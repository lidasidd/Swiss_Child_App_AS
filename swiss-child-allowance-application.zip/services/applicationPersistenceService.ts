import { ApplicationData, ApplicationStatus, SFUserData, ChildDetails, Gender, RelationshipToApplicant, UploadedFile } from '../types';

const LOCAL_STORAGE_KEY = 'childAllowanceApplications';

const getApplicationsFromStorage = (): ApplicationData[] => {
  const stored = localStorage.getItem(LOCAL_STORAGE_KEY);
  return stored ? JSON.parse(stored) : [];
};

const saveApplicationsToStorage = (applications: ApplicationData[]) => {
  localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(applications));
};

export const getAllApplications = (userId: string): ApplicationData[] => {
  const allApps = getApplicationsFromStorage();
  return allApps.filter(app => app.userId === userId).sort((a,b) => new Date(b.lastModifiedDate).getTime() - new Date(a.lastModifiedDate).getTime());
};

export const getApplicationById = (applicationId: string): ApplicationData | null => {
  const allApps = getApplicationsFromStorage();
  return allApps.find(app => app.id === applicationId) || null;
};

export const saveApplication = (applicationData: ApplicationData): ApplicationData => {
  let allApps = getApplicationsFromStorage();
  const existingIndex = allApps.findIndex(app => app.id === applicationData.id);

  if (existingIndex > -1) {
    allApps[existingIndex] = applicationData;
  } else {
    allApps.push(applicationData);
  }
  saveApplicationsToStorage(allApps);
  return applicationData;
};

export const createNewApplication = (userId: string, sfData: SFUserData): ApplicationData => {
  const now = new Date().toISOString().split('T')[0];
  
  return {
    id: `app-${Date.now()}-${Math.random().toString(16).slice(2)}`,
    userId,
    status: ApplicationStatus.DRAFT,
    submissionDate: undefined,
    lastModifiedDate: now,
    currentStep: 1,
    
    // Step 1
    residencyCountry: undefined,
    // Step 2 - Editable employee details, pre-filled from SF
    employeeFirstName: sfData.firstName,
    employeeLastName: sfData.lastName,
    employeeDateOfBirth: sfData.dateOfBirth,
    employeeEmployeeId: sfData.employeeId,
    employeeAhvNumber: sfData.ahvNumber || '',
    employeeCompanyName: sfData.companyName,
    employeeContractStartDate: sfData.contractStartDate,
    employeeContractEndDate: sfData.contractEndDate,
    // Step 3
    appliedInResidenceCountry: undefined,
    // Step 4
    addressStreet: '',
    addressStreetNo: '',
    addressPostCode: '',
    addressTown: '',
    addressCity: '',
    telephone: '',
    email: sfData.email || '', 
    maritalStatus: undefined,
    maritalStatusSince: '',
    // Step 5 & 6
    hasOtherEmployers: undefined,
    otherEmployers: [],
    // Step 7
    receivingCashBenefits: undefined,
    benefitType: '',
    benefitReceivedSince: '',
    benefitPaymentOffice: '',
    // Step 8
    spouseLastName: '',
    spouseFirstName: '',
    spouseDateOfBirth: '',
    spousePersonalId: '',
    spouseMaritalStatus: undefined,
    // Step 9
    isSpouseGainfullyEmployed: undefined,
    spouseEmploymentStatus: undefined,
    // Step 10 & 11
    spouseReceivingCashBenefits: undefined,
    spouseBenefitType: '',
    spouseBenefitReceivedSince: '',
    spouseBenefitPaymentOffice: '',
    // Step 12
    spouseEmployerName: '',
    spouseEmployerAddress: '',
    spouseEmployerCantonCountry: '',
    spouseEmploymentExtent: undefined,
    spouseIncomeComparedToApplicant: undefined,
    // Step 13
    children: [], // Children are not pre-filled anymore
    // Step 14
    hasDifferentLegalParent: undefined,
    legalParentAppliesToAllChildren: undefined,
    legalParentAppliesToChildIds: [],
    legalParentLastName: '',
    legalParentFirstName: '',
    legalParentDateOfBirth: '',
    legalParentMaritalStatus: undefined,
    legalParentAddress: '',
    legalParentTelephone: '',
    legalParentEmploymentDetail: undefined,
    legalParentEmployerName: '',
    legalParentEmployerAddress: '',
    legalParentEmployerCantonCountry: '',
    legalParentSelfEmployedCantonCountry: '',
    // Step 15 & 16
    childLivesWithOtherCarer: undefined,
    carerAppliesToAllChildren: undefined,
    carerAppliesToChildIds: [],
    carerLastName: '',
    carerFirstName: '',
    carerTelephone: '',
    carerRelationship: undefined,
    carerRelationshipOtherText: '',
    // Step 17
    receivedSwissChildAllowancesBefore: undefined,
    previousAllowanceCanton: '',
    previousAllowanceUntilDate: '',
    // Field for the now-unused Step 18 (ChildAgeQuery)
    confirmChildOver15: undefined,
    // Step 18 (formerly 19/20) - Documents
    marriageCertificate: undefined, 
    divorceDecree: undefined, 
    educationConfirmations: [], 
    // Step 19 (formerly 21) - Signature
    signatureName: `${sfData.firstName} ${sfData.lastName}`.trim(),
    signatureDate: now,
    informationConfirmed: false, // New field
    adminComments: undefined, // New field
  };
};

export const deleteApplication = (applicationId: string): void => {
    let allApps = getApplicationsFromStorage();
    allApps = allApps.filter(app => app.id !== applicationId);
    saveApplicationsToStorage(allApps);
}