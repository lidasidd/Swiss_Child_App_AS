import { UserQuestionnaire } from '../types';

const LOCAL_STORAGE_KEY_QUESTIONNAIRES = 'userQuestionnaires';

const getQuestionnairesFromStorage = (): UserQuestionnaire[] => {
  const stored = localStorage.getItem(LOCAL_STORAGE_KEY_QUESTIONNAIRES);
  return stored ? JSON.parse(stored) : [];
};

const saveQuestionnairesToStorage = (questionnaires: UserQuestionnaire[]) => {
  localStorage.setItem(LOCAL_STORAGE_KEY_QUESTIONNAIRES, JSON.stringify(questionnaires));
};

export const getAllUserQuestionnairesForUser = (userId: string): UserQuestionnaire[] => {
  const allQuestionnaires = getQuestionnairesFromStorage();
  return allQuestionnaires
    .filter(q => q.recipientUserId === userId)
    .sort((a,b) => new Date(b.sentDate).getTime() - new Date(a.sentDate).getTime());
};

// New function to get questionnaires sent by an admin/HR
export const getQuestionnairesSentByAdmin = (senderUserId: string): UserQuestionnaire[] => {
  const allQuestionnaires = getQuestionnairesFromStorage();
  return allQuestionnaires
    .filter(q => q.senderUserId === senderUserId)
    .sort((a,b) => new Date(b.sentDate).getTime() - new Date(a.sentDate).getTime());
};


export const getAllUserQuestionnaires = (): UserQuestionnaire[] => {
  return getQuestionnairesFromStorage().sort((a,b) => new Date(b.sentDate).getTime() - new Date(a.sentDate).getTime());
};


export const getUserQuestionnaireById = (questionnaireId: string): UserQuestionnaire | null => {
  const allQuestionnaires = getQuestionnairesFromStorage();
  return allQuestionnaires.find(q => q.id === questionnaireId) || null;
};

export const saveUserQuestionnaire = (questionnaireData: UserQuestionnaire): UserQuestionnaire => {
  let allQuestionnaires = getQuestionnairesFromStorage();
  const existingIndex = allQuestionnaires.findIndex(q => q.id === questionnaireData.id);

  if (existingIndex > -1) {
    allQuestionnaires[existingIndex] = questionnaireData;
  } else {
    allQuestionnaires.push(questionnaireData);
  }
  saveQuestionnairesToStorage(allQuestionnaires);
  return questionnaireData;
};
